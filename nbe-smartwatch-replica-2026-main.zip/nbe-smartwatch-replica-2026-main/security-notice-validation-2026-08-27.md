# Security notice validation

The public `/security-notice` page now displays the supplied security-guidance image in its alert dialog. The dialog retains all safe display-only controls: close button, confirmation button, backdrop dismissal, and Escape dismissal.

The selected-customer action in the administrative dashboard is explicitly labelled `تنبيه مباشر` and persists `security-notice` as the customer’s redirect target. The client redirect hook immediately resolves this target to `/security-notice` and clears the redirect state to prevent a loop.

Validation completed on 2026-08-27: 20 Vitest tests passed, TypeScript and production build passed, and the mobile audit confirmed the image loaded at 1536×1024, modal width remained within a 390px viewport, and no horizontal overflow occurred before or after opening the dialog.
