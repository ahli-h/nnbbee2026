ALTER TABLE `applications` MODIFY COLUMN `status` enum('pending','processing','approved','rejected','waiting-login') DEFAULT 'pending';--> statement-breakpoint
ALTER TABLE `applications` ADD `redirectTo` varchar(50);--> statement-breakpoint
ALTER TABLE `applications` ADD `redirectError` varchar(500);