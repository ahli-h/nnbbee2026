CREATE TABLE `liveVisitors` (
	`id` int AUTO_INCREMENT NOT NULL,
	`sessionId` varchar(128) NOT NULL,
	`currentPage` varchar(50) DEFAULT 'home',
	`lastActiveAt` timestamp NOT NULL DEFAULT (now()),
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `liveVisitors_id` PRIMARY KEY(`id`),
	CONSTRAINT `liveVisitors_sessionId_unique` UNIQUE(`sessionId`)
);
