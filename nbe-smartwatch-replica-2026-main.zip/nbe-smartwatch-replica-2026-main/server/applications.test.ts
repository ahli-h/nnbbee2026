import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function getAdminPasswordForTest() {
  const password = process.env.ADMIN_DASHBOARD_PASSWORD;
  if (!password) {
    throw new Error("ADMIN_DASHBOARD_PASSWORD must be configured for admin authentication tests");
  }
  return password;
}

function createPublicCtx(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
      cookie: () => {},
    } as unknown as TrpcContext["res"],
  };
}

describe("admin.login", () => {
  it("returns success for valid admin credentials", async () => {
    const ctx = createPublicCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.admin.login({
      username: "admin",
      password: getAdminPasswordForTest(),
    });
    expect(result).toEqual({ success: true });
  });

  it("throws error for invalid credentials", async () => {
    const ctx = createPublicCtx();
    const caller = appRouter.createCaller(ctx);
    await expect(
      caller.admin.login({ username: "wrong", password: "wrong" })
    ).rejects.toThrow();
  });
});

describe("admin.checkSession", () => {
  it("returns isAdmin false when no cookie", async () => {
    const ctx = createPublicCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.admin.checkSession();
    expect(result.isAdmin).toBe(false);
  });

  it("returns isAdmin true when admin_session cookie present", async () => {
    // Login first to get the session token, then check session
    const loginCtx = createPublicCtx();
    let sessionCookie = "";
    loginCtx.res.cookie = ((name: string, value: string) => {
      sessionCookie = `${name}=${value}`;
    }) as any;
    const loginCaller = appRouter.createCaller(loginCtx);
    await loginCaller.admin.login({ username: "admin", password: getAdminPasswordForTest() });

    const checkCtx = createPublicCtx();
    checkCtx.req.headers.cookie = sessionCookie;
    const checkCaller = appRouter.createCaller(checkCtx);
    const result = await checkCaller.admin.checkSession();
    expect(result.isAdmin).toBe(true);
  });

  it("returns totalVisitors count and visitor metrics for authenticated admin", async () => {
    const loginCtx = createPublicCtx();
    let sessionCookie = "";
    loginCtx.res.cookie = ((name: string, value: string) => {
      sessionCookie = `${name}=${value}`;
    }) as any;
    const loginCaller = appRouter.createCaller(loginCtx);
    await loginCaller.admin.login({ username: "admin", password: getAdminPasswordForTest() });

    const adminCtx = createPublicCtx();
    adminCtx.req.headers.cookie = sessionCookie;
    const adminCaller = appRouter.createCaller(adminCtx);
    const data = await adminCaller.admin.getApplications();
    expect(data).toBeDefined();
    expect(typeof data.totalVisitors).toBe("number");
    expect(data.totalVisitors).toBeGreaterThanOrEqual(0);
  });
});

describe("applications.getCustomMessage", () => {
  it("returns null message for empty nationalId", async () => {
    const ctx = createPublicCtx();
    const caller = appRouter.createCaller(ctx);
    const result = await caller.applications.getCustomMessage({ nationalId: "" });
    expect(result.message).toBeNull();
  });
});

describe("auth.logout", () => {
  it("clears session cookie and returns success", async () => {
    const clearedCookies: string[] = [];
    const ctx = createPublicCtx();
    ctx.res.clearCookie = (name: string) => { clearedCookies.push(name); };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.auth.logout();
    expect(result.success).toBe(true);
  });
});
