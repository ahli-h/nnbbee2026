import type { Express } from "express";
import fs from "fs";
import path from "path";
import { ENV } from "./env";

const LEGACY_ASSET_ALIASES: Record<string, string> = {
  "nbe_logo_emblem_2026_f07b9ba6.webp": "nbe-official-logo_7734b82a.png",
  "nbe_banner_logo_2026_54973647.webp": "nbe-official-logo_7734b82a.png",
  "nbe-logo-official_52aeb96d.png": "nbe-official-logo_7734b82a.png",
  "nbe_hard_token_device_2026_f7a3bcfb.png": "nbe-hard-token-device_9092db02.png",
  "nbe_hard_token_device_2026_910c21fc.png": "nbe-hard-token-device_9092db02.png",
  "hard_token_device_4f2968d2.png": "nbe-hard-token-device_9092db02.png",
  "nbe-token-official_96828d3e.jpg": "nbe-hard-token-device_9092db02.png",
  "nbe_security_notice_user_2026_2fe1380e.png": "nbe-security-notice-guide_6f377b64.png",
  "nbe-security-notice-registration-2026_2e29fe0c.png": "nbe-security-notice-guide_6f377b64.png",
  "nbe-security-guide_b8ee15c0.jpg": "nbe-security-notice-guide_6f377b64.png",
};

export function resolveStorageKey(key: string) {
  return LEGACY_ASSET_ALIASES[key] ?? key;
}

export function registerStorageProxy(app: Express) {
  app.get("/manus-storage/*", async (req, res) => {
    const rawKey = (req.params as Record<string, string>)[0];
    if (!rawKey) {
      res.status(400).send("Missing storage key");
      return;
    }

    const key = resolveStorageKey(rawKey);

    // If file is available locally in project storage-local directory, stream it directly with no-cache!
    const localDir = "/home/ubuntu/webdev-static-assets/storage-local";
    const localPath = path.join(localDir, key);
    if (fs.existsSync(localPath)) {
      res.set("Cache-Control", "no-store, no-cache, must-revalidate");
      res.set("Content-Type", key.endsWith(".png") ? "image/png" : "image/jpeg");
      fs.createReadStream(localPath).pipe(res);
      return;
    }

    if (!ENV.forgeApiUrl || !ENV.forgeApiKey) {
      res.status(500).send("Storage proxy not configured");
      return;
    }
    try {
      const forgeUrl = new URL(
        "v1/storage/presign/get",
        ENV.forgeApiUrl.replace(/\/+$/, "") + "/",
      );
      forgeUrl.searchParams.set("path", key);
      const forgeResp = await fetch(forgeUrl, {
        headers: { Authorization: `Bearer ${ENV.forgeApiKey}` },
      });
      if (!forgeResp.ok) {
        const body = await forgeResp.text().catch(() => "");
        console.error(`[StorageProxy] forge error: ${forgeResp.status} ${body}`);
        res.status(502).send("Storage backend error");
        return;
      }
      const { url } = (await forgeResp.json()) as { url: string };
      if (!url) {
        res.status(502).send("Empty signed URL from backend");
        return;
      }
      res.set("Cache-Control", "no-store");
      res.redirect(307, url);
    } catch (err) {
      console.error("[StorageProxy] failed:", err);
      res.status(502).send("Storage proxy error");
    }
  });
}
