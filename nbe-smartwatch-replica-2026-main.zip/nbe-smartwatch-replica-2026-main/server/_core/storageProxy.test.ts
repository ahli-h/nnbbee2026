import { describe, expect, it } from "vitest";
import { resolveStorageKey } from "./storageProxy";

describe("resolveStorageKey", () => {
  it("routes legacy branding and security asset keys to the copy-owned storage assets", () => {
    expect(resolveStorageKey("nbe_logo_emblem_2026_f07b9ba6.webp")).toBe(
      "nbe-official-logo_7734b82a.png",
    );
    expect(resolveStorageKey("nbe_banner_logo_2026_54973647.webp")).toBe(
      "nbe-official-logo_7734b82a.png",
    );
    expect(resolveStorageKey("nbe_hard_token_device_2026_f7a3bcfb.png")).toBe(
      "nbe-hard-token-device_9092db02.png",
    );
    expect(resolveStorageKey("nbe_security_notice_user_2026_2fe1380e.png")).toBe(
      "nbe-security-notice-guide_6f377b64.png",
    );
  });

  it("keeps current-project storage keys unchanged", () => {
    expect(resolveStorageKey("watch-nbe-red-2026_9395e8b6.png")).toBe(
      "watch-nbe-red-2026_9395e8b6.png",
    );
  });
});
