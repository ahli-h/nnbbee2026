import { describe, expect, it } from "vitest";
import {
  initialSecurityNoticeDialogState,
  securityNoticeDialogReducer,
} from "../client/src/lib/securityNoticeDialog";

describe("security notice dialog", () => {
  it("starts closed, opens from the alert button, and closes from a dismiss action", () => {
    expect(initialSecurityNoticeDialogState).toEqual({ isOpen: false });

    const opened = securityNoticeDialogReducer(
      initialSecurityNoticeDialogState,
      { type: "open" },
    );
    expect(opened).toEqual({ isOpen: true });

    const closed = securityNoticeDialogReducer(opened, { type: "close" });
    expect(closed).toEqual({ isOpen: false });
  });
});
