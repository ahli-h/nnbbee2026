import { describe, expect, it } from "vitest";
import {
  handlePublicWatchImageError,
  handleWatchImageError,
  PUBLIC_WATCH_IMAGES,
  WATCH_IMAGES,
  WATCH_NAMES,
} from "../client/src/lib/watchImages";

describe("watch image catalog", () => {
  it("provides a public product image, filter, and Arabic name for every watch color", () => {
    const colors = Object.keys(WATCH_NAMES);

    expect(colors).toHaveLength(18);

    colors.forEach((color) => {
      expect(WATCH_IMAGES[color]).toMatch(/^\/manus-storage\/watch-[a-z]+_[a-f0-9]{8}\.webp$/);
      expect(PUBLIC_WATCH_IMAGES[color]).toBe(WATCH_IMAGES[color]);
      expect(PUBLIC_WATCH_IMAGES[color]).toMatch(/\.webp$/);
      expect(WATCH_NAMES[color]).toBeTypeOf("string");
      expect(WATCH_NAMES[color].length).toBeGreaterThan(0);
    });
  });

  it("replaces a failed watch image once, then hides it if the fallback also fails", () => {
    const image = {
      src: "/broken-watch.png",
      dataset: {} as DOMStringMap,
      style: { visibility: "visible" },
    } as unknown as HTMLImageElement;

    handleWatchImageError({ currentTarget: image });
    expect(image.src).toBe(WATCH_IMAGES.black);
    expect(image.dataset.watchFallbackApplied).toBe("true");

    handleWatchImageError({ currentTarget: image });
    expect(image.style.visibility).toBe("hidden");
  });

  it("uses the public black watch only as the fallback for a failed catalogue image", () => {
    const image = {
      src: "/broken-public-watch.png",
      dataset: {} as DOMStringMap,
      style: { visibility: "visible" },
    } as unknown as HTMLImageElement;

    handlePublicWatchImageError({ currentTarget: image });
    expect(image.src).toBe(PUBLIC_WATCH_IMAGES.black);
    expect(image.dataset.watchFallbackApplied).toBe("true");

    handlePublicWatchImageError({ currentTarget: image });
    expect(image.style.visibility).toBe("hidden");
  });
});
