import { describe, expect, it } from "vitest";
import { ENV } from "./_core/env";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

describe("admin dashboard password secret", () => {
  it("loads ADMIN_DASHBOARD_PASSWORD as a non-empty server-side secret", () => {
    expect(ENV.adminDashboardPassword).toBeTypeOf("string");
    expect(ENV.adminDashboardPassword.trim().length).toBeGreaterThan(0);
    expect(ENV.adminDashboardPassword).not.toBe("undefined");
  });

  it("authenticates successfully against the admin.login procedure with the secret", async () => {
    const setCookies: Array<{ name: string; val: string; opts: unknown }> = [];
    const ctx: TrpcContext = {
      user: null,
      req: { protocol: "https", headers: {} } as unknown as TrpcContext["req"],
      res: {
        cookie: (name: string, val: string, opts: unknown) => {
          setCookies.push({ name, val, opts });
        },
        clearCookie: () => {},
      } as unknown as TrpcContext["res"],
    };
    const caller = appRouter.createCaller(ctx);
    const result = await caller.admin.login({ username: "admin", password: ENV.adminDashboardPassword });
    expect(result.success).toBe(true);
    expect(setCookies.some((c) => c.name === "admin_session")).toBe(true);
  });
});
