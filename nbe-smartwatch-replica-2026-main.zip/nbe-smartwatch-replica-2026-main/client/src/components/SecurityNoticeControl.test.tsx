// @vitest-environment jsdom

import React from "react";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it } from "vitest";
import SecurityNoticeControl from "./SecurityNoticeControl";

afterEach(() => {
  cleanup();
  document.body.style.overflow = "";
});

async function openDashboardNotice() {
  await userEvent.click(screen.getByRole("button", { name: "عرض التنبيه" }));
  return screen.getByRole("dialog", { name: "تنبيه لوحة التحكم" });
}

describe("SecurityNoticeControl", () => {
  it("opens from the dashboard alert button and closes from X", async () => {
    render(<SecurityNoticeControl />);
    expect(screen.queryByRole("dialog")).toBeNull();

    await openDashboardNotice();
    await userEvent.click(screen.getByRole("button", { name: "إغلاق تنبيه لوحة التحكم" }));

    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("closes from the confirmation button", async () => {
    render(<SecurityNoticeControl />);
    await openDashboardNotice();

    await userEvent.click(screen.getByRole("button", { name: "حسناً" }));

    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("closes with Escape", async () => {
    render(<SecurityNoticeControl />);
    await openDashboardNotice();

    await userEvent.keyboard("{Escape}");

    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("closes when the backdrop is pressed", async () => {
    render(<SecurityNoticeControl />);
    const dialog = await openDashboardNotice();

    fireEvent.mouseDown(dialog);

    expect(screen.queryByRole("dialog")).toBeNull();
  });
});
