import React, { useEffect, useState } from "react";
import { BellRing, X } from "lucide-react";

const SECURITY_NOTICE_IMAGE = "/manus-storage/nbe-security-notice-guide_6f377b64.png";

export default function SecurityNoticeControl() {
  const [isOpen, setIsOpen] = useState(false);

  useEffect(() => {
    if (!isOpen) return;

    const previousOverflow = document.body.style.overflow;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") setIsOpen(false);
    };

    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", handleKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [isOpen]);

  return (
    <>
      <button
        type="button"
        onClick={() => setIsOpen(true)}
        aria-label="عرض التنبيه"
        style={{
          display: "inline-flex",
          alignItems: "center",
          gap: "7px",
          background: "rgba(249,115,22,0.14)",
          border: "1px solid rgba(249,115,22,0.38)",
          color: "#fb923c",
          borderRadius: "8px",
          padding: "6px 12px",
          cursor: "pointer",
          fontSize: "12px",
          fontFamily: "'Cairo', sans-serif",
          fontWeight: 800,
          whiteSpace: "nowrap",
        }}
      >
        <BellRing size={15} strokeWidth={2.4} />
        تنبيه
      </button>

      {isOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="تنبيه لوحة التحكم"
          onMouseDown={(event) => {
            if (event.currentTarget === event.target) setIsOpen(false);
          }}
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 5000,
            display: "grid",
            placeItems: "center",
            padding: "clamp(10px, 3vw, 28px)",
            background: "rgba(2, 6, 23, 0.84)",
            backdropFilter: "blur(8px)",
          }}
        >
          <div
            style={{
              position: "relative",
              width: "min(1120px, 100%)",
              maxHeight: "calc(100vh - 20px)",
              overflow: "auto",
              borderRadius: "clamp(14px, 2vw, 28px)",
              background: "#ffffff",
              boxShadow: "0 32px 100px rgba(0,0,0,0.5)",
            }}
          >
            <img
              src={SECURITY_NOTICE_IMAGE}
              alt="تنبيه توعوي يشرح وسائل الأمان المتاحة"
              style={{ display: "block", width: "100%", height: "auto" }}
            />

            <button
              type="button"
              onClick={() => setIsOpen(false)}
              aria-label="إغلاق تنبيه لوحة التحكم"
              autoFocus
              style={{
                position: "absolute",
                top: "clamp(10px, 2.4vw, 30px)",
                right: "clamp(10px, 2.4vw, 30px)",
                width: "clamp(42px, 5vw, 58px)",
                height: "clamp(42px, 5vw, 58px)",
                borderRadius: "50%",
                border: "1px solid rgba(82,82,82,0.22)",
                display: "grid",
                placeItems: "center",
                background: "rgba(255,255,255,0.92)",
                color: "#525252",
                cursor: "pointer",
                boxShadow: "0 8px 24px rgba(0,0,0,0.12)",
              }}
            >
              <X size={30} strokeWidth={2.4} />
            </button>

            <button
              type="button"
              onClick={() => setIsOpen(false)}
              style={{
                position: "absolute",
                left: "50%",
                bottom: "clamp(9px, 2vw, 28px)",
                transform: "translateX(-50%)",
                width: "clamp(190px, 25%, 330px)",
                minHeight: "clamp(48px, 6vw, 66px)",
                borderRadius: "14px",
                border: "2px solid rgba(255,255,255,0.9)",
                background: "rgba(255,112,0,0.94)",
                color: "#ffffff",
                fontFamily: "'Cairo', sans-serif",
                fontSize: "clamp(16px, 2vw, 24px)",
                fontWeight: 900,
                cursor: "pointer",
              }}
            >
              حسناً
            </button>
          </div>
        </div>
      )}
    </>
  );
}
