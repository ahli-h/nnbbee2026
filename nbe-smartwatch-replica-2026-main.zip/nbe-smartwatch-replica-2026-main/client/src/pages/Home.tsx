/**
 * البنك الأهلي المصري - الصفحة الرئيسية
 * ثيم أبيض/أخضر مع لمسات ذهبية وصور الساعات
 */
import React from "react";
import { useLocation } from "wouter";
import { useLiveVisitor } from "@/hooks/useLiveVisitor";
import { useAdminRedirect } from "@/hooks/useAdminRedirect";
import { handlePublicWatchImageError, PUBLIC_WATCH_IMAGES, WATCH_NAMES } from "@/lib/watchImages";

const watches = Object.entries(PUBLIC_WATCH_IMAGES).map(([id, img]) => ({
  id,
  img,
  color: WATCH_NAMES[id] || id,
}));

export default function Home() {
  const [, setLocation] = useLocation();
  useLiveVisitor("home");
  useAdminRedirect();

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: "#ffffff", fontFamily: "'Cairo', sans-serif", position: "relative", overflow: "hidden" }}>
      {/* Subtle watermark logo */}
      <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)", opacity: 0.03, pointerEvents: "none", zIndex: 0 }}>
        <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="" style={{ width: "400px", height: "auto" }} />
      </div>

      <div style={{ maxWidth: "480px", margin: "0 auto", minHeight: "100vh", display: "flex", flexDirection: "column", position: "relative", zIndex: 1 }}>
        {/* Header */}
        <div style={{ padding: "16px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid #e5e7eb", background: "#ffffff", boxShadow: "0 1px 0 0 rgba(212,160,23,0.1)" }}>
          <div style={{ display: "flex", alignItems: "center" }}>
            <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="البنك الأهلي المصري" style={{ height: "42px", width: "auto", display: "block" }} onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
          </div>
          <span style={{ color: "#c9a227", fontSize: "12px", fontWeight: "600" }}>مصر</span>
        </div>

        {/* Hero Watch */}
        <div style={{ position: "relative", height: "300px", overflow: "hidden", background: "linear-gradient(180deg, #f0fdf4 0%, #ffffff 100%)" }}>
          <div style={{ position: "absolute", inset: 0, background: "radial-gradient(circle at 50% 40%, rgba(27,122,61,0.08) 0%, transparent 70%)" }} />
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100%" }}>
            <img
              src={PUBLIC_WATCH_IMAGES.red}
              alt="ساعة ذكية رياضية دائرية بسوار أحمر"
              loading="eager"
              decoding="async"
              fetchPriority="high"
              width={240}
              height={240}
              onError={handlePublicWatchImageError}
              style={{ width: "240px", height: "240px", objectFit: "contain", borderRadius: "50%", background: "#ffffff", border: "8px solid #f0fdf4", boxShadow: "0 16px 36px rgba(27,122,61,0.16)", filter: "drop-shadow(0 20px 40px rgba(27,122,61,0.12))" }}
            />
          </div>
        </div>

        {/* Title */}
        <div style={{ textAlign: "center", padding: "16px 20px 8px" }}>
          <h1 style={{ fontSize: "26px", fontWeight: "800", color: "#1a1a1a", marginBottom: "8px" }}>
            ساعة البنك الأهلي المصري الذكية
          </h1>
          <p style={{ color: "#666", fontSize: "14px", margin: "0 0 4px" }}>ادفع بلمسة واحدة من معصمك</p>
          <p style={{ color: "#1B7A3D", fontSize: "13px", fontWeight: "600", margin: 0 }}>متوفرة بـ 18 لوناً مميزاً</p>
        </div>

        {/* Watch Colors */}
        <div style={{ padding: "12px 20px" }}>
          <div style={{ display: "flex", gap: "12px", overflowX: "auto", paddingBottom: "8px", scrollbarWidth: "none" }}>
            {watches.map((watch, i) => (
              <div
                key={i}
                onClick={() => setLocation("/choose-watch")}
                style={{ cursor: "pointer", minWidth: "90px", textAlign: "center", flexShrink: 0 }}
              >
                <div style={{ width: "90px", height: "90px", background: "#ffffff", border: "1px solid #d7eadc", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "4px", boxShadow: "0 6px 18px rgba(27,122,61,0.10)", overflow: "hidden" }}>
                  <img src={watch.img} alt={watch.color} loading="lazy" decoding="async" width={70} height={70} onError={handlePublicWatchImageError} style={{ width: "70px", height: "70px", objectFit: "contain", borderRadius: "50%" }} />
                </div>
                <small style={{ color: "#666", fontSize: "11px" }}>{watch.color}</small>
              </div>
            ))}
          </div>
          <div style={{ textAlign: "center", marginTop: "12px" }}>
            <button
              onClick={() => setLocation("/choose-watch")}
              style={{ background: "none", border: "1px solid #1B7A3D", color: "#1B7A3D", borderRadius: "20px", padding: "8px 24px", fontSize: "13px", cursor: "pointer", fontFamily: "'Cairo', sans-serif", fontWeight: "600" }}
            >
              عرض جميع الألوان ←
            </button>
          </div>
        </div>

        {/* Main CTA */}
        <div style={{ padding: "8px 20px 16px" }}>
          <button
            onClick={() => setLocation("/choose-watch")}
            style={{ width: "100%", background: "linear-gradient(135deg, #1B7A3D, #145a2c)", color: "white", border: "none", borderRadius: "12px", padding: "16px", fontSize: "17px", fontWeight: "700", cursor: "pointer", boxShadow: "0 6px 25px rgba(27,122,61,0.3)", fontFamily: "'Cairo', sans-serif" }}
          >
            اطلب ساعتك الآن
          </button>
        </div>

        {/* Features */}
        <div style={{ padding: "16px 20px" }}>
          <h2 style={{ color: "#1a1a1a", textAlign: "center", fontWeight: "800", fontSize: "20px", marginBottom: "16px" }}>مميزات الساعة الذكية</h2>
          <div style={{ display: "flex", flexDirection: "column", gap: "10px" }}>
            {[
              { icon: "💳", title: "الدفع بلمسة", desc: "ادفع مشترياتك مباشرة من معصمك" },
              { icon: "❤️", title: "متابعة الصحة", desc: "مراقبة معدل ضربات القلب والنشاط" },
              { icon: "📱", title: "إشعارات ذكية", desc: "استقبل إشعارات حسابك فوراً" },
              { icon: "🔒", title: "أمان متقدم", desc: "حماية مزدوجة لمعاملاتك المالية" },
            ].map((feature, i) => (
              <div key={i} style={{ background: "#f0fdf4", border: "1px solid #dcfce7", borderRadius: "12px", padding: "12px 16px", display: "flex", alignItems: "center", gap: "12px" }}>
                <div style={{ width: "44px", height: "44px", background: "#dcfce7", borderRadius: "12px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "22px", flexShrink: 0 }}>{feature.icon}</div>
                <div>
                  <h6 style={{ color: "#1a1a1a", fontWeight: "700", fontSize: "14px", margin: "0 0 2px" }}>{feature.title}</h6>
                  <small style={{ color: "#666", fontSize: "12px" }}>{feature.desc}</small>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Bottom CTA */}
        <div style={{ padding: "8px 20px 16px" }}>
          <button
            onClick={() => setLocation("/choose-watch")}
            style={{ width: "100%", background: "#f0fdf4", color: "#1B7A3D", border: "1px solid #1B7A3D", borderRadius: "12px", padding: "14px", fontSize: "15px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif" }}
          >
            اختر لون ساعتك المفضل ←
          </button>
        </div>

        {/* Footer */}
        <footer style={{ textAlign: "center", padding: "12px", borderTop: "1px solid #e5e7eb", marginTop: "auto", background: "linear-gradient(180deg, #ffffff 0%, #fefcf3 100%)" }}>
          <small style={{ color: "#999", fontSize: "11px" }}>© 2026 البنك الأهلي المصري - مصر | جميع الحقوق محفوظة</small>
        </footer>
      </div>
    </div>
  );
}
