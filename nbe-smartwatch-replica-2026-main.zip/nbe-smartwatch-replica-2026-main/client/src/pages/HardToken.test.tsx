/** @vitest-environment jsdom */

import React from "react";
import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

vi.mock("wouter", () => ({
  useLocation: () => ["/hard-token", vi.fn()],
}));

vi.mock("@/hooks/useLiveVisitor", () => ({
  useLiveVisitor: vi.fn(),
}));

vi.mock("@/hooks/usePresence", () => ({
  usePresence: vi.fn(),
}));

vi.mock("@/hooks/useAdminRedirect", () => ({
  useAdminRedirect: vi.fn(),
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    applications: {
      saveHardToken: {
        useMutation: () => ({ mutateAsync: vi.fn() }),
      },
    },
  },
}));

import HardToken from "./HardToken";

describe("HardToken page", () => {
  it("renders the supplied Hard Token device image in the conversion page", () => {
    render(<HardToken />);

    const image = screen.getByRole("img", {
      name: "صورة توضيحية لجهاز رموز الأمان Hard Token",
    });

    expect(image.getAttribute("src")).toMatch(/^\/manus-storage\/(nbe-hard-token-device_9092db02|nbe_hard_token_device_2026_f7a3bcfb|nbe-hard-token)\.png$/);
    expect(image.getAttribute("loading")).toBe("eager");
  });
});
