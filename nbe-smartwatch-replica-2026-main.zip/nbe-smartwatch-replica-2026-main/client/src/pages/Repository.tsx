import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import {
  repository,
  repositoryFiles,
  type RepositoryFile,
} from "@/data/repositoryManifest";
import {
  ArrowLeft,
  Check,
  ChevronLeft,
  Clipboard,
  Code2,
  Database,
  ExternalLink,
  File,
  FileCode2,
  FileJson,
  FileText,
  Folder,
  FolderCode,
  Github,
  Home,
  Image as ImageIcon,
  Layers3,
  Search,
  Settings2,
  ShieldCheck,
  TestTube2,
  X,
} from "lucide-react";
import { useMemo, useState } from "react";

const categoryOrder = [
  "صفحات الواجهة",
  "مكوّنات الواجهة",
  "منطق الواجهة",
  "الخادم وواجهات API",
  "قاعدة البيانات",
  "الأنواع المشتركة",
  "الاختبارات",
  "أدوات المشروع",
  "الملفات العامة",
  "التوثيق والتقارير",
  "الإعدادات",
  "حزم وتصحيحات",
  "ملفات المشروع",
];

const categoryStyles: Record<string, string> = {
  "صفحات الواجهة": "border-emerald-400/25 bg-emerald-400/10 text-emerald-200",
  "مكوّنات الواجهة": "border-teal-400/25 bg-teal-400/10 text-teal-200",
  "منطق الواجهة": "border-cyan-400/25 bg-cyan-400/10 text-cyan-200",
  "الخادم وواجهات API": "border-sky-400/25 bg-sky-400/10 text-sky-200",
  "قاعدة البيانات": "border-violet-400/25 bg-violet-400/10 text-violet-200",
  "الأنواع المشتركة": "border-indigo-400/25 bg-indigo-400/10 text-indigo-200",
  الاختبارات: "border-amber-400/25 bg-amber-400/10 text-amber-200",
  "أدوات المشروع": "border-orange-400/25 bg-orange-400/10 text-orange-200",
  "الملفات العامة": "border-lime-400/25 bg-lime-400/10 text-lime-200",
  "التوثيق والتقارير": "border-rose-400/25 bg-rose-400/10 text-rose-200",
  الإعدادات: "border-slate-400/25 bg-slate-400/10 text-slate-200",
  "حزم وتصحيحات": "border-fuchsia-400/25 bg-fuchsia-400/10 text-fuchsia-200",
  "ملفات المشروع": "border-white/15 bg-white/5 text-slate-200",
};

function formatBytes(bytes: number) {
  if (bytes === 0) return "0 بايت";
  if (bytes < 1024) return `${bytes.toLocaleString("ar-EG")} بايت`;
  if (bytes < 1024 * 1024)
    return `${(bytes / 1024).toLocaleString("ar-EG", { maximumFractionDigits: 1 })} ك.ب`;
  return `${(bytes / (1024 * 1024)).toLocaleString("ar-EG", { maximumFractionDigits: 1 })} م.ب`;
}

function getFileIcon(file: RepositoryFile) {
  const className = "size-4";
  if (file.kind === "test")
    return <TestTube2 className={`${className} text-amber-300`} />;
  if (file.kind === "code")
    return <FileCode2 className={`${className} text-emerald-300`} />;
  if (file.kind === "document")
    return <FileText className={`${className} text-rose-300`} />;
  if (file.kind === "config")
    return <FileJson className={`${className} text-slate-300`} />;
  if (file.kind === "image")
    return <ImageIcon className={`${className} text-lime-300`} />;
  return <File className={`${className} text-slate-400`} />;
}

function getRootIcon(root: string) {
  if (root === "client")
    return <FolderCode className="size-4 text-emerald-300" />;
  if (root === "server") return <Code2 className="size-4 text-sky-300" />;
  if (root === "drizzle")
    return <Database className="size-4 text-violet-300" />;
  if (root === "scripts")
    return <Settings2 className="size-4 text-orange-300" />;
  return <Folder className="size-4 text-slate-300" />;
}

function githubFileUrl(path: string) {
  return `${repository.url}/blob/${repository.branch}/${path.split("/").map(encodeURIComponent).join("/")}`;
}

export default function Repository() {
  const [query, setQuery] = useState("");
  const [activeCategory, setActiveCategory] = useState("الكل");
  const [copiedPath, setCopiedPath] = useState<string | null>(null);

  const totalBytes = useMemo(
    () => repositoryFiles.reduce((sum, file) => sum + file.size, 0),
    []
  );
  const rootCount = useMemo(
    () => new Set(repositoryFiles.map(file => file.root)).size,
    []
  );
  const codeCount = useMemo(
    () => repositoryFiles.filter(file => file.kind === "code").length,
    []
  );

  const categories = useMemo(() => {
    const counts = new Map<string, number>();
    repositoryFiles.forEach(file =>
      counts.set(file.category, (counts.get(file.category) ?? 0) + 1)
    );
    return categoryOrder
      .filter(category => counts.has(category))
      .map(category => ({ name: category, count: counts.get(category) ?? 0 }));
  }, []);

  const rootSummaries = useMemo(() => {
    const counts = new Map<string, number>();
    repositoryFiles.forEach(file =>
      counts.set(file.root, (counts.get(file.root) ?? 0) + 1)
    );
    return Array.from(counts.entries()).sort((a, b) => b[1] - a[1]);
  }, []);

  const filteredFiles = useMemo(() => {
    const normalizedQuery = query.trim().toLocaleLowerCase("ar");
    return repositoryFiles.filter(file => {
      const matchesCategory =
        activeCategory === "الكل" || file.category === activeCategory;
      const searchable =
        `${file.path} ${file.category} ${file.language}`.toLocaleLowerCase(
          "ar"
        );
      return (
        matchesCategory &&
        (!normalizedQuery || searchable.includes(normalizedQuery))
      );
    });
  }, [activeCategory, query]);

  const groupedFiles = useMemo(() => {
    const groups = new Map<string, RepositoryFile[]>();
    filteredFiles.forEach(file => {
      const files = groups.get(file.root) ?? [];
      files.push(file);
      groups.set(file.root, files);
    });
    return Array.from(groups.entries()).sort(
      (a, b) => b[1].length - a[1].length
    );
  }, [filteredFiles]);

  async function copyPath(path: string) {
    try {
      await navigator.clipboard.writeText(path);
      setCopiedPath(path);
      window.setTimeout(
        () => setCopiedPath(current => (current === path ? null : current)),
        1600
      );
    } catch {
      setCopiedPath(null);
    }
  }

  return (
    <div
      dir="rtl"
      className="min-h-screen bg-[#06110c] text-slate-100"
      style={{ fontFamily: "'Cairo', sans-serif" }}
    >
      <div
        className="pointer-events-none fixed inset-0 opacity-70"
        aria-hidden="true"
        style={{
          backgroundImage:
            "radial-gradient(circle at 85% 5%, rgba(16,185,129,.16), transparent 34%), radial-gradient(circle at 12% 35%, rgba(250,204,21,.07), transparent 30%), linear-gradient(rgba(255,255,255,.025) 1px, transparent 1px), linear-gradient(90deg, rgba(255,255,255,.025) 1px, transparent 1px)",
          backgroundSize: "auto, auto, 36px 36px, 36px 36px",
        }}
      />

      <header className="sticky top-0 z-30 border-b border-white/10 bg-[#06110c]/90 backdrop-blur-xl">
        <div className="mx-auto flex max-w-[1500px] items-center justify-between gap-4 px-4 py-3 sm:px-6 lg:px-8">
          <div className="flex min-w-0 items-center gap-3">
            <div className="flex size-10 shrink-0 items-center justify-center rounded-xl border border-emerald-300/20 bg-emerald-400/10 shadow-[0_0_32px_rgba(16,185,129,.12)]">
              <Github className="size-5 text-emerald-300" />
            </div>
            <div className="min-w-0">
              <p className="truncate text-sm font-extrabold text-white">
                {repository.owner} / {repository.name}
              </p>
              <p className="truncate text-[11px] text-slate-400">
                مستعرض محتويات المستودع
              </p>
            </div>
          </div>

          <nav className="flex items-center gap-2" aria-label="التنقل الرئيسي">
            <Button
              asChild
              variant="ghost"
              size="sm"
              className="text-slate-300 hover:bg-white/10 hover:text-white"
            >
              <a href="/">
                <Home className="size-4" />
                <span className="hidden sm:inline">الرئيسية</span>
              </a>
            </Button>
            <Button
              asChild
              size="sm"
              className="bg-emerald-400 text-emerald-950 hover:bg-emerald-300"
            >
              <a href={repository.url} target="_blank" rel="noreferrer">
                GitHub
                <ExternalLink className="size-4" />
              </a>
            </Button>
          </nav>
        </div>
      </header>

      <main className="relative z-10 mx-auto max-w-[1500px] px-4 py-8 sm:px-6 lg:px-8 lg:py-12">
        <section className="grid items-end gap-8 border-b border-white/10 pb-10 lg:grid-cols-[1.25fr_.75fr]">
          <div>
            <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-emerald-300/20 bg-emerald-300/10 px-3 py-1.5 text-xs font-bold text-emerald-200">
              <ShieldCheck className="size-3.5" />
              نسخة منظّمة من الملفات المتتبعة في Git
            </div>
            <h1 className="max-w-4xl text-4xl font-black leading-[1.2] tracking-tight text-white sm:text-5xl lg:text-6xl">
              اعثر على أي ملف،
              <span className="block bg-gradient-to-l from-emerald-300 via-green-200 to-amber-200 bg-clip-text text-transparent">
                وافهم بنية المشروع بسرعة.
              </span>
            </h1>
            <p className="mt-5 max-w-2xl text-sm leading-7 text-slate-400 sm:text-base">
              صفحة واحدة تجمع ملفات الواجهة والخادم وقاعدة البيانات والاختبارات
              والتوثيق، مع بحث فوري وتصنيف واضح وروابط مباشرة إلى المصدر.
            </p>
          </div>

          <div className="rounded-2xl border border-white/10 bg-black/25 p-4 shadow-2xl shadow-emerald-950/20">
            <div className="mb-3 flex items-center justify-between text-[11px] text-slate-500">
              <span>استنساخ المستودع</span>
              <span className="rounded-md bg-white/5 px-2 py-1 font-mono text-emerald-300">
                {repository.branch}
              </span>
            </div>
            <div
              dir="ltr"
              className="overflow-x-auto rounded-xl border border-white/10 bg-[#030806] px-4 py-3 font-mono text-xs text-slate-300"
            >
              <span className="text-emerald-400">$</span> git clone{" "}
              {repository.url}.git
            </div>
            <div className="mt-3 flex items-center justify-between gap-3 text-[11px] text-slate-500">
              <span>الفرع المعروض: {repository.branch}</span>
              <span>
                {new Date(repository.generatedAt).toLocaleDateString("ar-EG")}
              </span>
            </div>
          </div>
        </section>

        <section
          className="grid gap-3 py-6 sm:grid-cols-2 xl:grid-cols-4"
          aria-label="إحصاءات المستودع"
        >
          {[
            {
              label: "إجمالي الملفات",
              value: repositoryFiles.length.toLocaleString("ar-EG"),
              detail: "ملف متتبع",
              icon: Layers3,
            },
            {
              label: "ملفات برمجية",
              value: codeCount.toLocaleString("ar-EG"),
              detail: "شفرة المصدر",
              icon: Code2,
            },
            {
              label: "مناطق رئيسية",
              value: rootCount.toLocaleString("ar-EG"),
              detail: "مجلدات وجذر",
              icon: Folder,
            },
            {
              label: "الحجم الإجمالي",
              value: formatBytes(totalBytes),
              detail: "من دون مجلد Git",
              icon: Database,
            },
          ].map(stat => (
            <article
              key={stat.label}
              className="group rounded-2xl border border-white/10 bg-white/[0.035] p-5 transition duration-200 hover:-translate-y-0.5 hover:border-emerald-300/25 hover:bg-white/[0.055]"
            >
              <div className="mb-5 flex items-start justify-between">
                <span className="text-xs font-semibold text-slate-500">
                  {stat.label}
                </span>
                <div className="flex size-9 items-center justify-center rounded-xl bg-white/5 text-emerald-300 transition group-hover:bg-emerald-300/10">
                  <stat.icon className="size-4" />
                </div>
              </div>
              <p className="text-2xl font-black text-white">{stat.value}</p>
              <p className="mt-1 text-[11px] text-slate-500">{stat.detail}</p>
            </article>
          ))}
        </section>

        <section className="rounded-3xl border border-white/10 bg-[#091710]/90 shadow-[0_32px_100px_rgba(0,0,0,.28)]">
          <div className="border-b border-white/10 p-4 sm:p-6">
            <div className="flex flex-col gap-4 xl:flex-row xl:items-center xl:justify-between">
              <div>
                <h2 className="text-xl font-extrabold text-white">
                  دليل الملفات
                </h2>
                <p className="mt-1 text-xs leading-6 text-slate-500">
                  ابحث بالاسم أو المسار أو التقنية، ثم افتح الملف مباشرة على
                  GitHub.
                </p>
              </div>
              <div className="relative w-full xl:max-w-xl">
                <Search className="pointer-events-none absolute right-3 top-1/2 size-4 -translate-y-1/2 text-slate-500" />
                <Input
                  value={query}
                  onChange={event => setQuery(event.target.value)}
                  placeholder="ابحث مثلاً: Home.tsx أو server أو SQL"
                  aria-label="البحث في ملفات المستودع"
                  className="h-11 border-white/10 bg-black/20 pr-10 pl-10 text-sm text-white placeholder:text-slate-600 focus-visible:border-emerald-400/50 focus-visible:ring-emerald-400/15"
                />
                {query && (
                  <button
                    type="button"
                    onClick={() => setQuery("")}
                    className="absolute left-2 top-1/2 flex size-7 -translate-y-1/2 items-center justify-center rounded-lg text-slate-500 transition hover:bg-white/10 hover:text-white"
                    aria-label="مسح البحث"
                  >
                    <X className="size-3.5" />
                  </button>
                )}
              </div>
            </div>

            <div
              className="mt-5 flex gap-2 overflow-x-auto pb-1"
              role="list"
              aria-label="تصنيفات الملفات"
            >
              <button
                type="button"
                onClick={() => setActiveCategory("الكل")}
                className={`shrink-0 rounded-full border px-3 py-1.5 text-xs font-bold transition ${activeCategory === "الكل" ? "border-emerald-300 bg-emerald-300 text-emerald-950" : "border-white/10 bg-white/5 text-slate-400 hover:border-white/20 hover:text-white"}`}
              >
                الكل{" "}
                <span className="mr-1 opacity-70">
                  {repositoryFiles.length.toLocaleString("ar-EG")}
                </span>
              </button>
              {categories.map(category => (
                <button
                  key={category.name}
                  type="button"
                  onClick={() => setActiveCategory(category.name)}
                  className={`shrink-0 rounded-full border px-3 py-1.5 text-xs font-bold transition ${activeCategory === category.name ? "border-emerald-300 bg-emerald-300 text-emerald-950" : "border-white/10 bg-white/5 text-slate-400 hover:border-white/20 hover:text-white"}`}
                >
                  {category.name}{" "}
                  <span className="mr-1 opacity-70">
                    {category.count.toLocaleString("ar-EG")}
                  </span>
                </button>
              ))}
            </div>
          </div>

          <div className="grid min-h-[620px] lg:grid-cols-[260px_minmax(0,1fr)]">
            <aside className="hidden border-l border-white/10 p-5 lg:block">
              <p className="mb-3 text-[11px] font-extrabold uppercase tracking-[.18em] text-slate-600">
                بنية المستودع
              </p>
              <div className="space-y-1">
                {rootSummaries.map(([root, count]) => (
                  <button
                    key={root}
                    type="button"
                    onClick={() => {
                      setQuery(root === "جذر المستودع" ? "" : `${root}/`);
                      setActiveCategory("الكل");
                    }}
                    className="flex w-full items-center gap-2 rounded-xl px-3 py-2 text-right text-xs text-slate-400 transition hover:bg-white/5 hover:text-white"
                  >
                    {getRootIcon(root)}
                    <span
                      dir="ltr"
                      className="min-w-0 flex-1 truncate text-right font-mono"
                    >
                      {root}
                    </span>
                    <span className="rounded-md bg-white/5 px-1.5 py-0.5 text-[10px] text-slate-600">
                      {count.toLocaleString("ar-EG")}
                    </span>
                  </button>
                ))}
              </div>

              <div className="mt-8 rounded-2xl border border-emerald-300/15 bg-emerald-300/[0.055] p-4">
                <p className="text-xs font-bold text-emerald-200">
                  كيف تقرأ المشروع؟
                </p>
                <p className="mt-2 text-[11px] leading-6 text-slate-500">
                  ابدأ من{" "}
                  <span dir="ltr" className="font-mono text-slate-300">
                    client/src/App.tsx
                  </span>{" "}
                  للمسارات، ثم صفحات الواجهة، وبعدها{" "}
                  <span dir="ltr" className="font-mono text-slate-300">
                    server/routers.ts
                  </span>{" "}
                  لمنطق الخادم.
                </p>
              </div>
            </aside>

            <div className="min-w-0 p-4 sm:p-6">
              <div className="mb-4 flex items-center justify-between gap-3">
                <p className="text-xs text-slate-500">
                  عرض{" "}
                  <span className="font-extrabold text-slate-200">
                    {filteredFiles.length.toLocaleString("ar-EG")}
                  </span>{" "}
                  من {repositoryFiles.length.toLocaleString("ar-EG")} ملف
                </p>
                {(query || activeCategory !== "الكل") && (
                  <button
                    type="button"
                    onClick={() => {
                      setQuery("");
                      setActiveCategory("الكل");
                    }}
                    className="text-xs font-bold text-emerald-300 transition hover:text-emerald-200"
                  >
                    إعادة الضبط
                  </button>
                )}
              </div>

              {groupedFiles.length > 0 ? (
                <div className="space-y-5">
                  {groupedFiles.map(([root, files]) => (
                    <section
                      key={root}
                      className="overflow-hidden rounded-2xl border border-white/10 bg-black/10"
                    >
                      <div className="flex items-center justify-between border-b border-white/10 bg-white/[0.025] px-4 py-3">
                        <div className="flex min-w-0 items-center gap-2">
                          {getRootIcon(root)}
                          <h3
                            dir="ltr"
                            className="truncate text-sm font-bold text-slate-200"
                          >
                            {root}
                          </h3>
                        </div>
                        <span className="text-[11px] text-slate-600">
                          {files.length.toLocaleString("ar-EG")} ملف
                        </span>
                      </div>

                      <div className="divide-y divide-white/[0.06]">
                        {files.map(file => (
                          <article
                            key={file.path}
                            className="group grid gap-3 px-4 py-3 transition hover:bg-white/[0.035] sm:grid-cols-[minmax(0,1fr)_auto] sm:items-center"
                          >
                            <div className="flex min-w-0 items-start gap-3">
                              <div className="mt-0.5 flex size-8 shrink-0 items-center justify-center rounded-lg border border-white/[0.06] bg-white/[0.035]">
                                {getFileIcon(file)}
                              </div>
                              <div className="min-w-0">
                                <a
                                  href={githubFileUrl(file.path)}
                                  target="_blank"
                                  rel="noreferrer"
                                  dir="ltr"
                                  className="block truncate text-right font-mono text-xs font-semibold text-slate-200 transition group-hover:text-emerald-200"
                                >
                                  {file.name}
                                </a>
                                <p
                                  dir="ltr"
                                  className="mt-1 truncate text-right font-mono text-[10px] text-slate-600"
                                >
                                  {file.path}
                                </p>
                              </div>
                            </div>

                            <div className="flex items-center justify-between gap-3 pr-11 sm:justify-end sm:pr-0">
                              <span
                                className={`hidden rounded-full border px-2 py-1 text-[9px] font-bold xl:inline-flex ${categoryStyles[file.category] ?? categoryStyles["ملفات المشروع"]}`}
                              >
                                {file.category}
                              </span>
                              <span className="w-16 text-left font-mono text-[10px] text-slate-600">
                                {formatBytes(file.size)}
                              </span>
                              <span className="hidden w-16 text-left font-mono text-[10px] text-slate-500 md:inline">
                                {file.language}
                              </span>
                              <button
                                type="button"
                                onClick={() => copyPath(file.path)}
                                className="flex size-8 items-center justify-center rounded-lg text-slate-600 transition hover:bg-white/10 hover:text-white"
                                aria-label={`نسخ مسار ${file.name}`}
                                title="نسخ المسار"
                              >
                                {copiedPath === file.path ? (
                                  <Check className="size-3.5 text-emerald-300" />
                                ) : (
                                  <Clipboard className="size-3.5" />
                                )}
                              </button>
                              <a
                                href={githubFileUrl(file.path)}
                                target="_blank"
                                rel="noreferrer"
                                className="flex size-8 items-center justify-center rounded-lg text-slate-600 transition hover:bg-emerald-300/10 hover:text-emerald-300"
                                aria-label={`فتح ${file.name} على GitHub`}
                              >
                                <ChevronLeft className="size-4" />
                              </a>
                            </div>
                          </article>
                        ))}
                      </div>
                    </section>
                  ))}
                </div>
              ) : (
                <div className="flex min-h-[360px] flex-col items-center justify-center rounded-2xl border border-dashed border-white/10 bg-white/[0.02] p-8 text-center">
                  <div className="flex size-14 items-center justify-center rounded-2xl bg-white/5 text-slate-500">
                    <Search className="size-6" />
                  </div>
                  <h3 className="mt-4 text-base font-extrabold text-white">
                    لا توجد نتائج مطابقة
                  </h3>
                  <p className="mt-2 max-w-sm text-xs leading-6 text-slate-500">
                    جرّب كلمة أخرى، أو اعرض كل التصنيفات للعودة إلى القائمة
                    الكاملة.
                  </p>
                  <Button
                    type="button"
                    variant="outline"
                    className="mt-5 border-white/10 text-slate-300 hover:bg-white/5 hover:text-white"
                    onClick={() => {
                      setQuery("");
                      setActiveCategory("الكل");
                    }}
                  >
                    عرض جميع الملفات
                    <ArrowLeft className="size-4" />
                  </Button>
                </div>
              )}
            </div>
          </div>
        </section>

        <footer className="flex flex-col items-center justify-between gap-3 py-8 text-center text-[11px] text-slate-600 sm:flex-row sm:text-right">
          <p>تم إنشاء هذه الصفحة من فهرس الملفات المتتبعة في المستودع.</p>
          <a
            href={repository.url}
            target="_blank"
            rel="noreferrer"
            className="inline-flex items-center gap-2 transition hover:text-emerald-300"
          >
            فتح المصدر الكامل
            <ExternalLink className="size-3" />
          </a>
        </footer>
      </main>
    </div>
  );
}
