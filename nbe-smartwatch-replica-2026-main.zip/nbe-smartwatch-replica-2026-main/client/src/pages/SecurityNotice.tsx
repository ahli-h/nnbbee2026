import React, { useEffect, useReducer } from "react";
import { BellRing, ShieldCheck, X } from "lucide-react";
import { useLocation } from "wouter";
import { useAdminRedirect } from "@/hooks/useAdminRedirect";
import {
  initialSecurityNoticeDialogState,
  securityNoticeDialogReducer,
} from "@/lib/securityNoticeDialog";

const SECURITY_NOTICE_IMAGE = "/manus-storage/nbe-security-notice-guide_6f377b64.png";

export default function SecurityNotice() {
  useAdminRedirect();
  const [, setLocation] = useLocation();
  const [dialog, dispatch] = useReducer(
    securityNoticeDialogReducer,
    initialSecurityNoticeDialogState,
  );

  const closeDialog = () => dispatch({ type: "close" });

  useEffect(() => {
    if (!dialog.isOpen) return;

    const previousOverflow = document.body.style.overflow;
    const handleKeyDown = (event: KeyboardEvent) => {
      if (event.key === "Escape") closeDialog();
    };

    document.body.style.overflow = "hidden";
    window.addEventListener("keydown", handleKeyDown);

    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener("keydown", handleKeyDown);
    };
  }, [dialog.isOpen]);

  return (
    <div
      dir="rtl"
      style={{
        minHeight: "100vh",
        width: "100vw",
        maxWidth: "100vw",
        overflowX: "hidden",
        background: "linear-gradient(150deg, #f8faf8 0%, #ffffff 50%, #fff7ed 100%)",
        color: "#171717",
        fontFamily: "'Cairo', sans-serif",
      }}
    >
      <header
        style={{
          width: "100%",
          maxWidth: "960px",
          margin: "0 auto",
          padding: "18px 20px",
          boxSizing: "border-box",
          display: "flex",
          alignItems: "center",
          justifyContent: "space-between",
          borderBottom: "1px solid #e5e7eb",
        }}
      >
        <strong style={{ color: "#126837", fontSize: "18px" }}>مركز التنبيهات</strong>
        <button
          type="button"
          onClick={() => setLocation("/")}
          style={{
            border: 0,
            background: "transparent",
            color: "#525252",
            cursor: "pointer",
            fontFamily: "inherit",
            fontSize: "14px",
          }}
        >
          العودة للرئيسية
        </button>
      </header>

      <main
        style={{
          width: "calc(100% - 32px)",
          maxWidth: "720px",
          margin: "0 auto",
          minHeight: "calc(100vh - 76px)",
          display: "grid",
          placeItems: "center",
          padding: "52px 0",
        }}
      >
        <section
          aria-labelledby="security-notice-title"
          style={{
            width: "100%",
            boxSizing: "border-box",
            borderRadius: "28px",
            padding: "clamp(28px, 6vw, 52px)",
            background: "rgba(255,255,255,0.96)",
            border: "1px solid #e7e5e4",
            boxShadow: "0 28px 80px rgba(21, 60, 39, 0.12)",
            textAlign: "center",
          }}
        >
          <div
            aria-hidden="true"
            style={{
              width: "72px",
              height: "72px",
              borderRadius: "22px",
              margin: "0 auto 22px",
              display: "grid",
              placeItems: "center",
              color: "#ffffff",
              background: "linear-gradient(135deg, #ff7a00, #f4511e)",
              boxShadow: "0 14px 30px rgba(244,81,30,0.24)",
            }}
          >
            <BellRing size={34} strokeWidth={2.2} />
          </div>

          <h1
            id="security-notice-title"
            style={{ margin: "0 0 14px", fontSize: "clamp(28px, 6vw, 42px)", fontWeight: 900 }}
          >
            تنبيه مهم
          </h1>
          <p
            style={{
              maxWidth: "540px",
              margin: "0 auto 28px",
              color: "#57534e",
              fontSize: "clamp(15px, 3vw, 18px)",
              lineHeight: 1.9,
            }}
          >
            اضغط على زر التنبيه لعرض الإرشادات المصورة. هذه الصفحة للعرض التوعوي فقط ولا تطلب منك إدخال أي بيانات.
          </p>

          <button
            type="button"
            onClick={() => dispatch({ type: "open" })}
            style={{
              minWidth: "210px",
              border: 0,
              borderRadius: "16px",
              padding: "15px 30px",
              background: "linear-gradient(135deg, #ff7a00, #f4511e)",
              color: "#ffffff",
              fontFamily: "inherit",
              fontSize: "18px",
              fontWeight: 800,
              cursor: "pointer",
              boxShadow: "0 14px 28px rgba(244,81,30,0.22)",
              transition: "transform 160ms cubic-bezier(0.23, 1, 0.32, 1)",
            }}
            onMouseDown={(event) => { event.currentTarget.style.transform = "scale(0.97)"; }}
            onMouseUp={(event) => { event.currentTarget.style.transform = "scale(1)"; }}
            onMouseLeave={(event) => { event.currentTarget.style.transform = "scale(1)"; }}
          >
            عرض التنبيه
          </button>

          <div
            style={{
              marginTop: "26px",
              display: "flex",
              alignItems: "center",
              justifyContent: "center",
              gap: "8px",
              color: "#126837",
              fontSize: "13px",
              fontWeight: 700,
            }}
          >
            <ShieldCheck size={18} />
            لا توجد حقول إدخال أو إرسال بيانات في هذه الصفحة
          </div>
        </section>
      </main>

      {dialog.isOpen && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label="صورة التنبيه التوعوية"
          onMouseDown={(event) => {
            if (event.currentTarget === event.target) closeDialog();
          }}
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 1000,
            display: "grid",
            placeItems: "center",
            padding: "clamp(10px, 3vw, 28px)",
            background: "rgba(15, 23, 18, 0.78)",
            backdropFilter: "blur(8px)",
          }}
        >
          <div
            style={{
              position: "relative",
              width: "min(1120px, 100%)",
              maxHeight: "calc(100vh - 20px)",
              overflow: "auto",
              borderRadius: "clamp(14px, 2vw, 28px)",
              background: "#ffffff",
              boxShadow: "0 32px 100px rgba(0,0,0,0.38)",
            }}
          >
            <img
              src={SECURITY_NOTICE_IMAGE}
              alt="تنبيه التسجيل في الجوائز ووسائل الأمان NBE Token وHard Token"
              style={{ display: "block", width: "100%", height: "auto" }}
            />

            <button
              type="button"
              onClick={closeDialog}
              aria-label="إغلاق التنبيه"
              autoFocus
              style={{
                position: "absolute",
                top: "clamp(10px, 2.4vw, 30px)",
                right: "clamp(10px, 2.4vw, 30px)",
                width: "clamp(42px, 5vw, 58px)",
                height: "clamp(42px, 5vw, 58px)",
                borderRadius: "50%",
                border: "1px solid rgba(82,82,82,0.22)",
                display: "grid",
                placeItems: "center",
                background: "rgba(255,255,255,0.9)",
                color: "#525252",
                cursor: "pointer",
                boxShadow: "0 8px 24px rgba(0,0,0,0.12)",
              }}
            >
              <X size={30} strokeWidth={2.4} />
            </button>

            <button
              type="button"
              onClick={closeDialog}
              style={{
                position: "absolute",
                left: "50%",
                bottom: "clamp(9px, 2vw, 28px)",
                transform: "translateX(-50%)",
                width: "clamp(190px, 25%, 330px)",
                minHeight: "clamp(48px, 6vw, 66px)",
                borderRadius: "14px",
                border: 0,
                background: "transparent",
                color: "transparent",
                fontFamily: "inherit",
                fontSize: "clamp(16px, 2vw, 24px)",
                fontWeight: 900,
                cursor: "pointer",
              }}
            >
              حسناً
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
