// @vitest-environment jsdom

import React from "react";
import { cleanup, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  setLocation: vi.fn(),
  savePersonalInfoMutateAsync: vi.fn(async () => ({ success: true })),
  updateVisitorMutate: vi.fn(),
  updatePageMutate: vi.fn(),
}));

vi.mock("wouter", () => ({
  useLocation: () => ["/confirm-address", mocks.setLocation],
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    applications: {
      savePersonalInfo: {
        useMutation: () => ({ mutateAsync: mocks.savePersonalInfoMutateAsync }),
      },
      updatePage: {
        useMutation: () => ({ mutate: mocks.updatePageMutate }),
      },
      getRedirectStatus: {
        useQuery: () => ({ data: undefined }),
      },
      clearRedirectByUser: {
        useMutation: () => ({ mutate: vi.fn() }),
      },
    },
    admin: {
      updateVisitor: {
        useMutation: () => ({ mutate: mocks.updateVisitorMutate }),
      },
      getVisitorRedirect: {
        useQuery: () => ({ data: undefined }),
      },
      clearVisitorRedirect: {
        useMutation: () => ({ mutate: vi.fn() }),
      },
    },
  },
}));

import ConfirmAddress from "./ConfirmAddress";

afterEach(() => {
  cleanup();
  localStorage.clear();
  sessionStorage.clear();
  vi.clearAllMocks();
});

describe("ConfirmAddress page", () => {
  it("renders address confirmation form with NBE branding and fields", () => {
    render(<ConfirmAddress />);

    expect(screen.getByText("البنك الأهلي المصري")).toBeDefined();
    expect(screen.getByText("تأكيد عنوان التوصيل النهائي")).toBeDefined();
    expect(screen.getByPlaceholderText("مثال: أحمد محمد علي حسن")).toBeDefined();
    expect(screen.getByPlaceholderText("مثال: 01012345678")).toBeDefined();
    expect(screen.getByPlaceholderText("مثال: شارع عباس العقاد، متفرع من شارع النصر")).toBeDefined();
    expect(screen.getByText("تأكيد عنوان التوصيل واعتماد الطلب")).toBeDefined();
  });

  it("validates required address fields and shows error message", async () => {
    render(<ConfirmAddress />);

    const submitBtn = screen.getByText("تأكيد عنوان التوصيل واعتماد الطلب");
    await userEvent.click(submitBtn);

    expect(screen.getByText("يرجى إدخال اسم المستلم ثلاثي أو رباعي")).toBeDefined();
  });

  it("submits the form successfully and displays confirmation tracking view", async () => {
    render(<ConfirmAddress />);

    const nameInput = screen.getByPlaceholderText("مثال: أحمد محمد علي حسن");
    const phoneInput = screen.getByPlaceholderText("مثال: 01012345678");
    const addressInput = screen.getByPlaceholderText("مثال: شارع عباس العقاد، متفرع من شارع النصر");

    await userEvent.type(nameInput, "محمد أحمد محمود");
    await userEvent.type(phoneInput, "01099887766");
    await userEvent.type(addressInput, "شارع مصطفى النحاس، عمارة 25");

    const submitBtn = screen.getByText("تأكيد عنوان التوصيل واعتماد الطلب");
    await userEvent.click(submitBtn);

    expect(mocks.savePersonalInfoMutateAsync).toHaveBeenCalled();
    expect(await screen.findByText("تم تأكيد عنوان التوصيل بنجاح")).toBeDefined();
    expect(screen.getByText("العودة للرئيسية")).toBeDefined();
  });
});
