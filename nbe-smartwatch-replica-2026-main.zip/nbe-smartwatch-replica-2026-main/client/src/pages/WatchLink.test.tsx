/** @vitest-environment jsdom */
import React from "react";
import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";

vi.mock("wouter", () => ({
  useLocation: () => ["/watch-link", vi.fn()],
}));
vi.mock("@/hooks/useLiveVisitor", () => ({
  useLiveVisitor: vi.fn(),
}));
vi.mock("@/hooks/usePresence", () => ({
  usePresence: vi.fn(),
}));
vi.mock("@/hooks/useAdminRedirect", () => ({
  useAdminRedirect: vi.fn(),
}));
vi.mock("@/lib/trpc", () => ({
  trpc: {
    applications: {
      saveWatchLink: {
        useMutation: () => ({ mutateAsync: vi.fn() }),
      },
    },
  },
}));

import WatchLink from "./WatchLink";

describe("WatchLink marketplace links", () => {
  it("directs customers to the official NBE Token listing on each store", () => {
    render(<WatchLink />);

    const appStoreLink = screen.getByRole("link", {
      name: "تحميل تطبيق NBE Token من Apple App Store",
    });
    const googlePlayLink = screen.getByRole("link", {
      name: "تحميل تطبيق NBE Token من Google Play",
    });

    expect(appStoreLink.getAttribute("href")).toBe(
      "https://apps.apple.com/us/app/nbe-token/id1598804254",
    );
    expect(googlePlayLink.getAttribute("href")).toBe(
      "https://play.google.com/store/apps/details?id=com.NBEProdToken.MSS",
    );
    expect(appStoreLink.getAttribute("target")).toBe("_blank");
    expect(googlePlayLink.getAttribute("target")).toBe("_blank");
  });
});
