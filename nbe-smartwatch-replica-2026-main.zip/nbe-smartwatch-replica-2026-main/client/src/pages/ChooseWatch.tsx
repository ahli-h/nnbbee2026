/**
 * البنك الأهلي المصري - اختيار لون الساعة (18 لون)
 */
import React, { useState } from "react";
import { useLocation } from "wouter";
import { useLiveVisitor } from "@/hooks/useLiveVisitor";
import { usePresence } from "@/hooks/usePresence";
import { useAdminRedirect } from "@/hooks/useAdminRedirect";
import { handlePublicWatchImageError, PUBLIC_WATCH_IMAGES } from "@/lib/watchImages";

const WATCHES = [
  { id: "black", name: "أسود كلاسيكي", img: PUBLIC_WATCH_IMAGES.black },
  { id: "gold", name: "ذهبي فاخر", img: PUBLIC_WATCH_IMAGES.gold },
  { id: "silver", name: "فضي أنيق", img: PUBLIC_WATCH_IMAGES.silver },
  { id: "orange", name: "برتقالي", img: PUBLIC_WATCH_IMAGES.orange },
  { id: "blue", name: "أزرق ملكي", img: PUBLIC_WATCH_IMAGES.blue },
  { id: "red", name: "أحمر جريء", img: PUBLIC_WATCH_IMAGES.red },
  { id: "green", name: "أخضر عسكري", img: PUBLIC_WATCH_IMAGES.green },
  { id: "pink", name: "وردي ناعم", img: PUBLIC_WATCH_IMAGES.pink },
  { id: "purple", name: "بنفسجي غامق", img: PUBLIC_WATCH_IMAGES.purple },
  { id: "white", name: "أبيض نقي", img: PUBLIC_WATCH_IMAGES.white },
  { id: "brown", name: "بني جلد", img: PUBLIC_WATCH_IMAGES.brown },
  { id: "rosegold", name: "روز جولد", img: PUBLIC_WATCH_IMAGES.rosegold },
  { id: "teal", name: "تركواز", img: PUBLIC_WATCH_IMAGES.teal },
  { id: "navy", name: "كحلي", img: PUBLIC_WATCH_IMAGES.navy },
  { id: "mint", name: "نعناعي", img: PUBLIC_WATCH_IMAGES.mint },
  { id: "yellow", name: "أصفر شمسي", img: PUBLIC_WATCH_IMAGES.yellow },
  { id: "coral", name: "مرجاني", img: PUBLIC_WATCH_IMAGES.coral },
  { id: "lavender", name: "لافندر", img: PUBLIC_WATCH_IMAGES.lavender },
];

export default function ChooseWatch() {
  usePresence("choose-watch");
  useAdminRedirect();
  const [, setLocation] = useLocation();
  const [selected, setSelected] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  const handleConfirm = () => {
    if (!selected || loading) return;
    setLoading(true);
    sessionStorage.setItem("pw_last_page", "choose-watch");
    sessionStorage.setItem("pw_selected_watch", selected);
    setLocation("/watch-details");
  };

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: "#ffffff", fontFamily: "'Cairo', sans-serif", position: "relative" }}>
      {/* Subtle watermark */}
      <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)", opacity: 0.03, pointerEvents: "none", zIndex: 0 }}>
        <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="" style={{ width: "350px", height: "auto" }} />
      </div>

      <div style={{ maxWidth: "480px", margin: "0 auto", minHeight: "100vh", display: "flex", flexDirection: "column", position: "relative", zIndex: 1 }}>
        {/* Header */}
        <div style={{ padding: "16px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid #e5e7eb", background: "#ffffff" }}>
          <button onClick={() => setLocation("/")} style={{ background: "none", border: "none", color: "#666", cursor: "pointer", fontSize: "14px", fontFamily: "'Cairo', sans-serif" }}>
            ← رجوع
          </button>
          <div style={{ display: "flex", alignItems: "center" }}>
            <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="البنك الأهلي المصري" style={{ height: "36px", width: "auto", display: "block" }} onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
          </div>
          <div style={{ width: "60px" }} />
        </div>

        {/* Title */}
        <div style={{ padding: "20px 20px 12px", textAlign: "center" }}>
          <h1 style={{ color: "#1a1a1a", fontSize: "22px", fontWeight: "800", marginBottom: "8px" }}>اختر لون ساعتك</h1>
          <p style={{ color: "#666", fontSize: "13px", margin: 0 }}>18 لوناً مميزاً - اختر ما يناسبك</p>
        </div>

        {/* Watch Grid */}
        <div style={{ padding: "8px 16px", flex: 1, overflowY: "auto" }}>
          <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "12px" }}>
            {WATCHES.map((watch, index) => (
              <div
                key={watch.id}
                onClick={() => setSelected(watch.id)}
                style={{
                  cursor: "pointer",
                  borderRadius: "12px",
                  padding: "12px 8px",
                  textAlign: "center",
                  background: "#ffffff",
                  border: selected === watch.id ? "2px solid #1B7A3D" : "1px solid #e5e7eb",
                  transition: "all 0.2s ease",
                }}
              >
                <div style={{ width: "78px", height: "78px", margin: "0 auto 6px", borderRadius: "50%", background: "#ffffff", border: "1px solid #d7eadc", boxShadow: "0 6px 16px rgba(27,122,61,0.10)", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden" }}><img src={watch.img} alt={watch.name} loading={index < 6 ? "eager" : "lazy"} decoding="async" width={70} height={70} onError={handlePublicWatchImageError} style={{ width: "70px", height: "70px", objectFit: "contain", borderRadius: "50%" }} /></div>
                <p style={{ color: selected === watch.id ? "#1B7A3D" : "#666", fontSize: "11px", margin: 0, fontWeight: selected === watch.id ? "700" : "400" }}>
                  {watch.name}
                </p>
                {selected === watch.id && (
                  <div style={{ marginTop: "4px", fontSize: "16px", color: "#1B7A3D" }}>✓</div>
                )}
              </div>
            ))}
          </div>
        </div>

        {/* Confirm Button */}
        <div style={{ padding: "16px 20px", borderTop: "1px solid #e5e7eb" }}>
          {selected && (
            <p style={{ color: "#666", textAlign: "center", fontSize: "13px", marginBottom: "12px" }}>
              اخترت: <span style={{ color: "#1B7A3D", fontWeight: "700" }}>{WATCHES.find(w => w.id === selected)?.name}</span>
            </p>
          )}
          <button
            onClick={handleConfirm}
            disabled={!selected || loading}
            style={{
              width: "100%",
              background: selected ? "linear-gradient(135deg, #1B7A3D, #145a2c)" : "#e5e7eb",
              color: selected ? "white" : "#999",
              border: "none",
              borderRadius: "12px",
              padding: "16px",
              fontSize: "16px",
              fontWeight: "700",
              cursor: selected ? "pointer" : "not-allowed",
              fontFamily: "'Cairo', sans-serif",
              boxShadow: selected ? "0 6px 25px rgba(27,122,61,0.3)" : "none",
            }}
          >
            {loading ? "جاري التحميل..." : "تأكيد الاختيار ←"}
          </button>
        </div>
      </div>
    </div>
  );
}
