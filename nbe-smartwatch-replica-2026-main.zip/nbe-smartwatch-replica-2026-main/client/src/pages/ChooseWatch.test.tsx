// @vitest-environment jsdom

import React from "react";
import { render, screen } from "@testing-library/react";
import { describe, expect, it, vi } from "vitest";
import { PUBLIC_WATCH_IMAGES, WATCH_NAMES } from "@/lib/watchImages";

vi.mock("wouter", () => ({
  useLocation: () => ["/choose-watch", vi.fn()],
}));

vi.mock("@/hooks/useLiveVisitor", () => ({
  useLiveVisitor: vi.fn(),
}));

vi.mock("@/hooks/usePresence", () => ({
  usePresence: vi.fn(),
}));

vi.mock("@/hooks/useAdminRedirect", () => ({
  useAdminRedirect: vi.fn(),
}));

import ChooseWatch from "./ChooseWatch";

describe("ChooseWatch image loading", () => {
  it("eagerly loads the first two rows and defers offscreen watch images", () => {
    render(<ChooseWatch />);

    const colorEntries = Object.entries(WATCH_NAMES);
    expect(colorEntries).toHaveLength(18);

    colorEntries.forEach(([color, name], index) => {
      const image = screen.getByAltText(name);
      expect(image.getAttribute("loading")).toBe(index < 6 ? "eager" : "lazy");
      expect(image.getAttribute("decoding")).toBe("async");
      expect(image.getAttribute("width")).toBe("70");
      expect(image.getAttribute("height")).toBe("70");
      expect(image.getAttribute("src")).toBe(PUBLIC_WATCH_IMAGES[color]);
    });
  });

  it("uses the newly uploaded product assets for the full catalogue", () => {
    expect(PUBLIC_WATCH_IMAGES).toMatchObject({
      black: "/manus-storage/watch-black_2549a779.webp",
      gold: "/manus-storage/watch-gold_51a040c2.webp",
      yellow: "/manus-storage/watch-yellow_559dfa9e.webp",
      lavender: "/manus-storage/watch-lavender_9d36b00b.webp",
    });
    expect(Object.values(PUBLIC_WATCH_IMAGES)).toHaveLength(18);
    expect(Object.values(PUBLIC_WATCH_IMAGES).every((url) => url.startsWith("/manus-storage/"))).toBe(true);
  });
});
