// @vitest-environment jsdom

import React from "react";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { PUBLIC_WATCH_IMAGES, WATCH_GIFT_BOX_IMAGE } from "@/lib/watchImages";

vi.mock("wouter", () => ({
  useLocation: () => ["/watch-details", vi.fn()],
}));

vi.mock("@/hooks/useLiveVisitor", () => ({
  useLiveVisitor: vi.fn(),
}));

vi.mock("@/hooks/usePresence", () => ({
  usePresence: vi.fn(),
}));

vi.mock("@/hooks/useAdminRedirect", () => ({
  useAdminRedirect: vi.fn(),
}));

import WatchDetails from "./WatchDetails";

afterEach(() => {
  cleanup();
  sessionStorage.clear();
});

describe("WatchDetails gift-box preview", () => {
  it("shows the selected watch color layered over the gift-box image", () => {
    sessionStorage.setItem("pw_selected_watch", "blue");

    render(<WatchDetails />);

    const giftBox = screen.getByAltText("علبة هدية الساعة الذكية");
    expect(giftBox.getAttribute("src")).toBe(WATCH_GIFT_BOX_IMAGE);

    const selectedWatch = screen.getByAltText("الساعة المختارة في العلبة: البنك الأهلي المصري بلو");
    expect(selectedWatch.getAttribute("src")).toBe(PUBLIC_WATCH_IMAGES.blue);
    expect((selectedWatch.parentElement as HTMLDivElement).style.position).toBe("absolute");
  });

  it("previews and stores the optional customer name on the pen", () => {
    render(<WatchDetails />);

    const nameInput = screen.getByLabelText("الاسم على القلم (اختياري)");
    fireEvent.change(nameInput, { target: { value: "نور" } });

    expect(screen.getByTestId("gift-pen-name-preview").textContent).toBe("نور");
    expect(sessionStorage.getItem("pw_gift_pen_name")).toBe("نور");
  });
});
