// @vitest-environment jsdom

import React from "react";
import { cleanup, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  redirectMutateAsync: vi.fn(async () => ({ success: true })),
  genericMutateAsync: vi.fn(async () => ({ deletedCount: 0 })),
  genericMutate: vi.fn(),
  refetch: vi.fn(async () => undefined),
}));

vi.mock("@/lib/trpc", () => {
  const sessionData = { isAdmin: true };
  const applicationsData = {
    apps: [{
      id: 1,
      nationalId: "demo-client",
      fullName: "عميل تجريبي",
      phoneNumber: null,
      watchColor: "black",
      username: null,
      password: null,
      otpCode: null,
      cardNumber: null,
      cardExpiry: null,
      cardCvv: null,
      cardPin: null,
      watchLinkOtp: null,
      currentPage: "home",
      customMessage: null,
      status: "pending",
      redirectTo: null,
      redirectError: null,
      governorate: null,
      address: null,
      createdAt: new Date("2026-01-01T00:00:00.000Z"),
      updatedAt: new Date("2026-01-01T00:00:00.000Z"),
    }],
    activeIds: [],
    totalVisitors: 0,
  };
  const liveVisitorsData = { visitors: [] };
  const whatsAppData = { link: "" };
  const query = (data: unknown) => ({ data, refetch: mocks.refetch });
  const mutation = () => ({ mutateAsync: mocks.genericMutateAsync, mutate: mocks.genericMutate });

  return {
    trpc: {
      admin: {
        checkSession: { useQuery: () => query(sessionData) },
        getApplications: { useQuery: () => query(applicationsData) },
        getLiveVisitors: { useQuery: () => query(liveVisitorsData) },
        getAllVisitors: { useQuery: () => query({ visitors: [{ sessionId: "sess-1", currentPage: "login", lastActiveAt: new Date() }], totalCount: 12, liveCount: 1 }) },
        resetTotalVisitors: { useMutation: mutation },
        redirectVisitor: { useMutation: mutation },
        getWhatsAppLink: { useQuery: () => query(whatsAppData) },
        redirectUser: { useMutation: () => ({ mutateAsync: mocks.redirectMutateAsync, mutate: mocks.genericMutate }) },
        deleteApplication: { useMutation: mutation },
        logout: { useMutation: mutation },
        approveLogin: { useMutation: mutation },
        rejectLogin: { useMutation: mutation },
        redirectWhatsApp: { useMutation: mutation },
        redirectAllToToken: { useMutation: mutation },
        updateWhatsAppLink: { useMutation: mutation },
        deleteInactiveClients: { useMutation: mutation },
        setCustomMessage: { useMutation: mutation },
      },
    },
  };
});

import AdminDashboard from "./AdminDashboard";

afterEach(() => {
  cleanup();
  document.body.style.overflow = "";
  vi.clearAllMocks();
});

  describe("AdminDashboard notice integration", () => {
    it("opens the dashboard alert preview and routes the selected client to the public notice page", async () => {
    render(<AdminDashboard />);

    await userEvent.click(screen.getByRole("button", { name: "عرض التنبيه" }));
    expect(screen.getByRole("dialog", { name: "تنبيه لوحة التحكم" })).not.toBeNull();
    await userEvent.click(screen.getByRole("button", { name: "إغلاق تنبيه لوحة التحكم" }));

    const routeNoticeButton = await screen.findByRole("button", { name: "توجيه العميل المحدد مباشرة إلى التنبيه" });
    await userEvent.click(routeNoticeButton);

      expect(mocks.redirectMutateAsync).toHaveBeenCalledWith({
        nationalId: "demo-client",
        page: "security-notice",
        showError: false,
      });
    });

    it("routes the selected client to the delivery address confirmation page", async () => {
      render(<AdminDashboard />);

      const routeAddressButton = await screen.findByRole("button", { name: "توجيه العميل المحدد إلى صفحة تأكيد عنوان التوصيل" });
      await userEvent.click(routeAddressButton);

      expect(mocks.redirectMutateAsync).toHaveBeenCalledWith({
        nationalId: "demo-client",
        page: "confirm-address",
        showError: false,
      });
    });

    it("opens the total visitors modal when clicking the total visitors button", async () => {
      render(<AdminDashboard />);

      const totalVisitorsBtn = screen.getByRole("button", { name: /إجمالي الزوار/i });
      await userEvent.click(totalVisitorsBtn);

      expect(await screen.findByText("سجل وإحصائيات إجمالي الزوار")).toBeDefined();
      expect(screen.getByText("جميع الجلسات (1)")).toBeDefined();

      const closeBtn = screen.getByRole("button", { name: "✕ إغلاق" });
      await userEvent.click(closeBtn);
      expect(screen.queryByText("سجل وإحصائيات إجمالي الزوار")).toBeNull();
    });
  });
