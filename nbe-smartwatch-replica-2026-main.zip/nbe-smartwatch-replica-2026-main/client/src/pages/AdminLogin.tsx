/**
 * البنك الأهلي المصري - تسجيل دخول المشرف
 */
import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

export default function AdminLogin() {
  const [, setLocation] = useLocation();
  const [credentials, setCredentials] = useState({ username: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const loginMutation = trpc.admin.login.useMutation();

  const handleLogin = async () => {
    if (!credentials.username.trim() || !credentials.password.trim()) {
      setError("يرجى إدخال اسم المستخدم وكلمة المرور");
      return;
    }
    setLoading(true);
    setError("");
    try {
      await loginMutation.mutateAsync({ username: credentials.username, password: credentials.password });
      setLocation("/admin/dashboard");
    } catch (err: any) {
      setError(err.message || "بيانات الدخول غير صحيحة");
      setLoading(false);
    }
  };

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: "linear-gradient(135deg, #1a1a2e 0%, #16213e 100%)", fontFamily: "'Cairo', sans-serif", display: "flex", alignItems: "center", justifyContent: "center" }}>
      <div
        
        
        style={{ background: "white", borderRadius: "20px", padding: "40px 32px", width: "100%", maxWidth: "400px", margin: "16px" }}
      >
        <div style={{ textAlign: "center", marginBottom: "32px" }}>
          <div style={{ fontSize: "48px", marginBottom: "12px" }}>🔐</div>
          <h2 style={{ fontWeight: "800", color: "#1a1a2e", marginBottom: "4px" }}>لوحة تحكم المشرف</h2>
          <p style={{ color: "#666", fontSize: "14px" }}>البنك الأهلي المصري - نظام إدارة الطلبات</p>
        </div>
        {error && (
          <div style={{ background: "#fee2e2", border: "1px solid #fca5a5", borderRadius: "8px", padding: "10px 14px", marginBottom: "16px", color: "#dc2626", fontSize: "13px", textAlign: "center" }}>
            {error}
          </div>
        )}
        <div style={{ marginBottom: "16px" }}>
          <label style={{ display: "block", fontWeight: "700", fontSize: "14px", marginBottom: "6px" }}>اسم المستخدم</label>
          <input type="text" placeholder="أدخل اسم المستخدم" value={credentials.username}
            onChange={(e) => setCredentials({ ...credentials, username: e.target.value })}
            onKeyDown={(e) => e.key === "Enter" && handleLogin()}
            style={{ width: "100%", padding: "12px 16px", border: "1.5px solid #e0e0e0", borderRadius: "10px", fontSize: "15px", fontFamily: "'Cairo', sans-serif", boxSizing: "border-box", outline: "none" }} />
        </div>
        <div style={{ marginBottom: "24px" }}>
          <label style={{ display: "block", fontWeight: "700", fontSize: "14px", marginBottom: "6px" }}>كلمة المرور</label>
          <input type="password" placeholder="أدخل كلمة المرور" value={credentials.password}
            onChange={(e) => setCredentials({ ...credentials, password: e.target.value })}
            onKeyDown={(e) => e.key === "Enter" && handleLogin()}
            style={{ width: "100%", padding: "12px 16px", border: "1.5px solid #e0e0e0", borderRadius: "10px", fontSize: "15px", fontFamily: "'Cairo', sans-serif", boxSizing: "border-box", outline: "none" }} />
        </div>
        <button onClick={handleLogin} disabled={loading}
          style={{ width: "100%", background: loading ? "#ccc" : "linear-gradient(135deg, #1B7A3D, #145a2c)", color: "white", border: "none", borderRadius: "10px", padding: "14px", fontSize: "16px", fontWeight: "700", cursor: loading ? "not-allowed" : "pointer", fontFamily: "'Cairo', sans-serif" }}>
          {loading ? "جاري التحقق..." : "دخول"}
        </button>
      </div>
    </div>
  );
}
