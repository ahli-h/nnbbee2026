// @vitest-environment jsdom

import React from "react";
import { cleanup, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  setLocation: vi.fn(),
  updateVisitorMutate: vi.fn(),
  updatePageMutate: vi.fn(),
}));

vi.mock("wouter", () => ({
  useLocation: () => ["/login", mocks.setLocation],
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    applications: {
      updatePage: {
        useMutation: () => ({ mutate: mocks.updatePageMutate }),
      },
      getRedirectStatus: {
        useQuery: () => ({ data: undefined }),
      },
      clearRedirectByUser: {
        useMutation: () => ({ mutate: vi.fn() }),
      },
    },
    admin: {
      updateVisitor: {
        useMutation: () => ({ mutate: mocks.updateVisitorMutate }),
      },
      getVisitorRedirect: {
        useQuery: () => ({ data: undefined }),
      },
      clearVisitorRedirect: {
        useMutation: () => ({ mutate: vi.fn() }),
      },
    },
  },
}));

import Login from "./Login";

afterEach(() => {
  cleanup();
  sessionStorage.clear();
  vi.clearAllMocks();
});

describe("Login page banner and greeting", () => {
  it("renders the NBE banner logo and welcome messages", () => {
    render(<Login />);

    // Check banner image
    const bannerImg = screen.getByAltText("البنك الأهلي المصري - National Bank of Egypt");
    expect(bannerImg).toBeDefined();
    expect(bannerImg.getAttribute("src")).toBe("/manus-storage/nbe-official-logo-source_d2709322.png");
    expect((bannerImg as HTMLImageElement).style.maxWidth).toBe("190px");
    expect((bannerImg as HTMLImageElement).style.width).toBe("100%");

    // Check welcome headers
    expect(screen.getByText("مرحبآ بك في الاهلي نت")).toBeDefined();
    expect(screen.getByText("من فضلك سجل الدخول باسم المستخدم")).toBeDefined();

    // Check tabs and form
    expect(screen.getByText("افراد")).toBeDefined();
    expect(screen.getByText("شركات")).toBeDefined();
    expect(screen.getByPlaceholderText("كود المستخدم")).toBeDefined();
    expect(screen.getByText("تسجيل الدخول")).toBeDefined();
  });

  it("handles valid English username input and navigation to password", async () => {
    render(<Login />);

    const input = screen.getByPlaceholderText("كود المستخدم");
    await userEvent.type(input, "user12345");

    const submitBtn = screen.getByText("تسجيل الدخول");
    await userEvent.click(submitBtn);

    expect(sessionStorage.getItem("pw_username")).toBe("user12345");
    expect(mocks.setLocation).toHaveBeenCalledWith("/password");
  });

  it("navigates account recovery and registration actions to valid application routes", async () => {
    render(<Login />);

    await userEvent.click(screen.getByRole("button", { name: "نسيت كود المستخدم" }));
    expect(mocks.setLocation).toHaveBeenCalledWith("/reset-password");

    await userEvent.click(screen.getByRole("button", { name: "سجل الان" }));
    expect(mocks.setLocation).toHaveBeenCalledWith("/personal-info");
  });

  it("uses verified NBE destinations for the support service links", () => {
    render(<Login />);

    expect(screen.getAllByRole("link", { name: "احجز موعد" })[0]?.getAttribute("href")).toBe(
      "https://www.nbe.com.eg/NBE/E/#/EN/ProductDetails?inParams=%7B%22CategoryID%22%3A%22selfservices%22%2C%22ProductID%22%3A%2218782%22",
    );
    expect(screen.getByRole("link", { name: "ماكينة الصارف الآلي / الفرع" }).getAttribute("href")).toBe(
      "https://www.nbe.com.eg/NBE/E/#/AR/ATMBranch",
    );
    expect(screen.getByRole("link", { name: "حاسبة العملات" }).getAttribute("href")).toBe(
      "https://www.nbe.com.eg/NBE/E/#/AR/ExchangeRatesAndCurrencyConverter",
    );
  });
});
