// @vitest-environment jsdom

import React from "react";
import { cleanup, render, screen } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";
import { PUBLIC_WATCH_IMAGES, WATCH_NAMES, WATCH_SOURCE_IMAGE } from "@/lib/watchImages";

vi.mock("wouter", () => ({
  useLocation: () => ["/", vi.fn()],
}));

vi.mock("@/hooks/useLiveVisitor", () => ({
  useLiveVisitor: vi.fn(),
}));

vi.mock("@/hooks/useAdminRedirect", () => ({
  useAdminRedirect: vi.fn(),
}));

import Home from "./Home";

afterEach(cleanup);

describe("Home watch catalogue", () => {
  it("renders the complete 18-colour public watch collection", () => {
    render(<Home />);

    const colors = Object.keys(PUBLIC_WATCH_IMAGES);
    expect(colors).toHaveLength(18);

    colors.forEach((color) => {
      const image = screen.getAllByAltText(WATCH_NAMES[color])[0];
      expect(image?.getAttribute("src")).toBe(PUBLIC_WATCH_IMAGES[color]);
    });
  });

  it("uses a managed product image asset for every colour", () => {
    Object.values(PUBLIC_WATCH_IMAGES).forEach((imageUrl) => {
      expect(imageUrl).toMatch(/^\/manus-storage\/watch-[a-z]+_[a-f0-9]{8}\.webp$/);
    });
    expect(PUBLIC_WATCH_IMAGES.black).toBe(WATCH_SOURCE_IMAGE);
  });

  it("prioritizes the hero image and lazily loads catalogue thumbnails", () => {
    render(<Home />);

    const hero = screen.getByAltText("ساعة ذكية رياضية دائرية بسوار أحمر");
    expect(hero.getAttribute("loading")).toBe("eager");
    expect(hero.getAttribute("fetchpriority")).toBe("high");
    expect(hero.getAttribute("width")).toBe("240");
    expect(hero.getAttribute("height")).toBe("240");

    const blackThumbnail = screen.getByAltText(WATCH_NAMES.black);
    expect(blackThumbnail.getAttribute("loading")).toBe("lazy");
    expect(blackThumbnail.getAttribute("decoding")).toBe("async");
    expect(blackThumbnail.getAttribute("width")).toBe("70");
    expect(blackThumbnail.getAttribute("height")).toBe("70");
  });
});
