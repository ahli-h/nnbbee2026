/**
 * البنك الأهلي المصري - إعادة تعيين كلمة المرور
 * تصميم أبيض/أخضر - بدون شعار بالخلفية (صفحة تسجيل دخول)
 */
import { useState } from "react";
import { useLocation } from "wouter";

export default function ResetPassword() {
  const [, setLocation] = useLocation();
  const [phone, setPhone] = useState("");
  const [submitted, setSubmitted] = useState(false);

  const inputStyle: React.CSSProperties = {
    width: "100%", padding: "14px 16px", border: "1.5px solid #e5e7eb",
    borderRadius: "10px", fontSize: "15px", fontFamily: "'Cairo', sans-serif",
    boxSizing: "border-box", outline: "none", background: "#f9fafb",
    color: "#1a1a1a",
  };

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: "#ffffff", fontFamily: "'Cairo', sans-serif" }}>
      <div style={{ maxWidth: "520px", margin: "0 auto", minHeight: "100vh", display: "flex", flexDirection: "column" }}>
        {/* Header */}
        <div style={{ padding: "20px 24px", textAlign: "center", borderBottom: "1px solid #e5e7eb", position: "relative" }}>
          <button onClick={() => setLocation("/login")} style={{ position: "absolute", top: "50%", right: "16px", transform: "translateY(-50%)", background: "none", border: "none", cursor: "pointer" }}>
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none"><path d="M18 6L6 18M6 6l12 12" stroke="#999" strokeWidth="2.5" strokeLinecap="round"/></svg>
          </button>
          <h2 style={{ color: "#1a1a1a", fontWeight: "800", fontSize: "20px", margin: 0 }}>إعادة تعيين كلمة المرور</h2>
        </div>

        <div style={{ padding: "32px 24px", flex: 1 }}>
          {!submitted ? (
            <>
              <div style={{ textAlign: "center", marginBottom: "28px" }}>
                <div style={{ width: "72px", height: "72px", background: "#f0fdf4", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 16px", border: "2px solid #dcfce7" }}>
                  <svg width="32" height="32" viewBox="0 0 24 24" fill="none">
                    <path d="M21 2l-2 2m-7.61 7.61a5.5 5.5 0 11-7.778 7.778 5.5 5.5 0 017.777-7.777zm0 0L15.5 7.5m0 0l3 3L22 7l-3-3m-3.5 3.5L19 4" stroke="#1B7A3D" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </div>
                <h5 style={{ fontWeight: "800", marginBottom: "8px", color: "#1a1a1a", fontSize: "18px" }}>نسيت كلمة المرور؟</h5>
                <p style={{ color: "#666", fontSize: "14px" }}>أدخل رقم هاتفك المسجل وسنرسل لك رمز إعادة التعيين</p>
              </div>
              <div style={{ marginBottom: "20px" }}>
                <label style={{ display: "block", fontWeight: "700", fontSize: "14px", marginBottom: "6px", color: "#333" }}>رقم الهاتف</label>
                <input type="tel" inputMode="numeric" placeholder="أدخل رقم هاتفك" value={phone}
                  onChange={(e) => setPhone(e.target.value.replace(/\D/g, "").slice(0, 11))}
                  style={inputStyle} />
              </div>
              <button onClick={() => phone.length >= 10 && setSubmitted(true)}
                style={{ width: "100%", background: "linear-gradient(135deg, #1B7A3D, #145a2c)", color: "white", border: "none", borderRadius: "12px", padding: "16px", fontSize: "16px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif", boxShadow: "0 6px 25px rgba(27,122,61,0.3)" }}>
                إرسال رمز التحقق
              </button>
            </>
          ) : (
            <div style={{ textAlign: "center" }}>
              <div style={{ width: "80px", height: "80px", background: "#f0fdf4", borderRadius: "50%", display: "flex", alignItems: "center", justifyContent: "center", margin: "0 auto 20px", border: "3px solid #dcfce7" }}>
                <svg width="40" height="40" viewBox="0 0 24 24" fill="none">
                  <path d="M20 6L9 17l-5-5" stroke="#1B7A3D" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
                </svg>
              </div>
              <h5 style={{ fontWeight: "800", marginBottom: "8px", color: "#1a1a1a", fontSize: "18px" }}>تم إرسال الرمز</h5>
              <p style={{ color: "#666", fontSize: "14px", marginBottom: "24px" }}>تم إرسال رمز إعادة التعيين إلى رقم هاتفك</p>
              <button onClick={() => setLocation("/login")}
                style={{ background: "linear-gradient(135deg, #1B7A3D, #145a2c)", color: "white", border: "none", borderRadius: "12px", padding: "14px 32px", fontSize: "15px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif" }}>
                العودة لتسجيل الدخول
              </button>
            </div>
          )}
        </div>

        <footer style={{ textAlign: "center", padding: "16px", borderTop: "1px solid #e5e7eb" }}>
          <small style={{ color: "#999", fontSize: "11px" }}>© 2026 البنك الأهلي المصري - مصر</small>
        </footer>
      </div>
    </div>
  );
}
