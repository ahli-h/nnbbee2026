/**
 * البنك الأهلي المصري - تفاصيل الساعة المختارة
 */
import React, { useEffect, useRef, useState } from "react";
import { useLocation } from "wouter";
import { useLiveVisitor } from "@/hooks/useLiveVisitor";
import { usePresence } from "@/hooks/usePresence";
import { useAdminRedirect } from "@/hooks/useAdminRedirect";
import { handlePublicWatchImageError, PUBLIC_WATCH_IMAGES, WATCH_GIFT_BOX_IMAGE } from "@/lib/watchImages";

const WATCH_DATA: Record<string, { name: string; subtitle: string; desc: string; img: string; specs: string[] }> = {
  black: { name: "البنك الأهلي المصري بلاك", subtitle: "أناقة كلاسيكية داكنة", desc: "ساعة ذكية فاخرة بإطار أسود معدني، تجمع بين الكلاسيكية والتقنية الحديثة مع دعم الدفع اللاتلامسي.", img: PUBLIC_WATCH_IMAGES.black, specs: ["إطار أسود معدني", "قياس النبض 72 BPM", "دفع لاتلامسي NFC", "مكالمات ورسائل"] },
  gold: { name: "البنك الأهلي المصري جولد", subtitle: "فخامة ذهبية لا مثيل لها", desc: "ساعة ذكية فاخرة بسوار ذهبي لامع، تجمع بين الفخامة والتقنية الحديثة مع دعم الدفع اللاتلامسي.", img: PUBLIC_WATCH_IMAGES.gold, specs: ["سوار ذهبي رياضي", "قياس النبض 72 BPM", "دفع لاتلامسي NFC", "مكالمات ورسائل"] },
  silver: { name: "البنك الأهلي المصري سيلفر", subtitle: "نقاء فضي راقٍ", desc: "ساعة ذكية فاخرة بسوار فضي أنيق، تجمع بين البساطة والتقنية الحديثة مع دعم الدفع اللاتلامسي.", img: PUBLIC_WATCH_IMAGES.silver, specs: ["سوار فضي رياضي", "قياس النبض 72 BPM", "دفع لاتلامسي NFC", "مكالمات ورسائل"] },
  orange: { name: "البنك الأهلي المصري أورانج", subtitle: "حيوية برتقالية مميزة", desc: "ساعة ذكية فاخرة بسوار برتقالي مميز، تجمع بين الحيوية والتقنية الحديثة مع دعم الدفع اللاتلامسي.", img: PUBLIC_WATCH_IMAGES.orange, specs: ["سوار برتقالي رياضي", "قياس النبض 72 BPM", "دفع لاتلامسي NFC", "مكالمات ورسائل"] },
  blue: { name: "البنك الأهلي المصري بلو", subtitle: "أناقة ملكية زرقاء", desc: "ساعة ذكية فاخرة بسوار أزرق ملكي، تجمع بين الكلاسيكية والتقنية الحديثة مع دعم الدفع اللاتلامسي.", img: PUBLIC_WATCH_IMAGES.blue, specs: ["سوار أزرق رياضي", "قياس النبض 72 BPM", "دفع لاتلامسي NFC", "مكالمات ورسائل"] },
  red: { name: "البنك الأهلي المصري ريد", subtitle: "جرأة باللون الأحمر", desc: "ساعة ذكية فاخرة بسوار أحمر جريء، تجمع بين الحيوية والتقنية الحديثة مع دعم الدفع اللاتلامسي.", img: PUBLIC_WATCH_IMAGES.red, specs: ["سوار أحمر رياضي", "قياس النبض 72 BPM", "دفع لاتلامسي NFC", "مكالمات ورسائل"] },
  green: { name: "البنك الأهلي المصري جرين", subtitle: "قوة عسكرية أنيقة", desc: "ساعة ذكية فاخرة بسوار أخضر عسكري، تجمع بين القوة والتقنية الحديثة مع دعم الدفع اللاتلامسي.", img: PUBLIC_WATCH_IMAGES.green, specs: ["سوار أخضر رياضي", "قياس النبض 72 BPM", "دفع لاتلامسي NFC", "مكالمات ورسائل"] },
  pink: { name: "البنك الأهلي المصري بينك", subtitle: "نعومة وردية راقية", desc: "ساعة ذكية فاخرة بسوار وردي ناعم، تجمع بين الأناقة والتقنية الحديثة مع دعم الدفع اللاتلامسي.", img: PUBLIC_WATCH_IMAGES.pink, specs: ["سوار وردي رياضي", "قياس النبض 72 BPM", "دفع لاتلامسي NFC", "مكالمات ورسائل"] },
  purple: { name: "البنك الأهلي المصري بيربل", subtitle: "غموض بنفسجي فاخر", desc: "ساعة ذكية فاخرة بسوار بنفسجي غامق، تجمع بين الغموض والتقنية الحديثة مع دعم الدفع اللاتلامسي.", img: PUBLIC_WATCH_IMAGES.purple, specs: ["سوار بنفسجي رياضي", "قياس النبض 72 BPM", "دفع لاتلامسي NFC", "مكالمات ورسائل"] },
  white: { name: "البنك الأهلي المصري وايت", subtitle: "نقاء أبيض متألق", desc: "ساعة ذكية فاخرة بسوار أبيض نقي، تجمع بين البساطة والتقنية الحديثة مع دعم الدفع اللاتلامسي.", img: PUBLIC_WATCH_IMAGES.white, specs: ["سوار أبيض رياضي", "قياس النبض 72 BPM", "دفع لاتلامسي NFC", "مكالمات ورسائل"] },
  brown: { name: "البنك الأهلي المصري براون", subtitle: "دفء بني كلاسيكي", desc: "ساعة ذكية فاخرة بسوار بني كلاسيكي، تجمع بين الدفء والتقنية الحديثة مع دعم الدفع اللاتلامسي.", img: PUBLIC_WATCH_IMAGES.brown, specs: ["سوار بني رياضي", "قياس النبض 72 BPM", "دفع لاتلامسي NFC", "مكالمات ورسائل"] },
  rosegold: { name: "البنك الأهلي المصري روز جولد", subtitle: "رومانسية ذهبية وردية", desc: "ساعة ذكية فاخرة بسوار روز جولد، تجمع بين الرومانسية والتقنية الحديثة مع دعم الدفع اللاتلامسي.", img: PUBLIC_WATCH_IMAGES.rosegold, specs: ["سوار روز جولد رياضي", "قياس النبض 72 BPM", "دفع لاتلامسي NFC", "مكالمات ورسائل"] },
  teal: { name: "البنك الأهلي المصري تيل", subtitle: "تركواز عصري جذاب", desc: "ساعة ذكية فاخرة بسوار تركوازي، تجمع بين العصرية والتقنية الحديثة مع دعم الدفع اللاتلامسي.", img: PUBLIC_WATCH_IMAGES.teal, specs: ["سوار تركوازي رياضي", "قياس النبض 72 BPM", "دفع لاتلامسي NFC", "مكالمات ورسائل"] },
  navy: { name: "البنك الأهلي المصري ناڤي", subtitle: "كحلي رياضي أنيق", desc: "ساعة ذكية رياضية بإطار أسود وسوار كحلي عميق، تجمع بين الثبات والأناقة اليومية.", img: PUBLIC_WATCH_IMAGES.navy, specs: ["سوار كحلي رياضي", "قياس النبض 72 BPM", "دفع لاتلامسي NFC", "مكالمات ورسائل"] },
  mint: { name: "البنك الأهلي المصري مينت", subtitle: "نعناعي منعش", desc: "ساعة ذكية رياضية بسوار نعناعي هادئ، مناسبة لإطلالة عصرية وخفيفة.", img: PUBLIC_WATCH_IMAGES.mint, specs: ["سوار نعناعي رياضي", "قياس النبض 72 BPM", "دفع لاتلامسي NFC", "مكالمات ورسائل"] },
  yellow: { name: "البنك الأهلي المصري يلو", subtitle: "أصفر شمسي جريء", desc: "ساعة ذكية رياضية بسوار أصفر شمسي لافت، تمنحك حضوراً مميزاً في كل وقت.", img: PUBLIC_WATCH_IMAGES.yellow, specs: ["سوار أصفر رياضي", "قياس النبض 72 BPM", "دفع لاتلامسي NFC", "مكالمات ورسائل"] },
  coral: { name: "البنك الأهلي المصري كورال", subtitle: "مرجاني حيوي", desc: "ساعة ذكية رياضية بسوار مرجاني نابض، تجمع بين الحيوية والراحة.", img: PUBLIC_WATCH_IMAGES.coral, specs: ["سوار مرجاني رياضي", "قياس النبض 72 BPM", "دفع لاتلامسي NFC", "مكالمات ورسائل"] },
  lavender: { name: "البنك الأهلي المصري لافندر", subtitle: "لافندر هادئ", desc: "ساعة ذكية رياضية بسوار لافندر ناعم، بتصميم مريح ومظهر عصري.", img: PUBLIC_WATCH_IMAGES.lavender, specs: ["سوار لافندر رياضي", "قياس النبض 72 BPM", "دفع لاتلامسي NFC", "مكالمات ورسائل"] },
};

export default function WatchDetails() {
  usePresence("watch-details");
  useAdminRedirect();
  const [, setLocation] = useLocation();
  const selectedId = sessionStorage.getItem("pw_selected_watch") || "black";
  const watch = WATCH_DATA[selectedId] || WATCH_DATA["black"];
  const [giftPenName, setGiftPenName] = useState(() => sessionStorage.getItem("pw_gift_pen_name") ?? "");
  const giftBoxRef = useRef<HTMLDivElement>(null);
  const selectedWatchRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const prefersReducedMotion =
      typeof window.matchMedia === "function" &&
      window.matchMedia("(prefers-reduced-motion: reduce)").matches;
    const giftBox = giftBoxRef.current;
    if (prefersReducedMotion || !giftBox || typeof giftBox.animate !== "function") return;

    const boxAnimation = giftBox.animate(
      [
        { opacity: 0, transform: "perspective(900px) translateY(10px) rotateX(4deg) scale(0.98)" },
        { opacity: 1, transform: "perspective(900px) translateY(0) rotateX(0) scale(1)" },
      ],
      { duration: 560, easing: "cubic-bezier(0.23, 1, 0.32, 1)", fill: "both" },
    );
    const watchAnimation = selectedWatchRef.current?.animate?.(
      [
        { opacity: 0, transform: "scale(0.92)" },
        { opacity: 1, transform: "scale(1)" },
      ],
      { duration: 340, delay: 150, easing: "cubic-bezier(0.23, 1, 0.32, 1)", fill: "both" },
    );

    return () => {
      boxAnimation.cancel();
      watchAnimation?.cancel();
    };
  }, []);

  return (
    <div dir="rtl" style={{ minHeight: "100vh", background: "#ffffff", fontFamily: "'Cairo', sans-serif", position: "relative", overflowX: "hidden" }}>
      {/* Subtle watermark */}
      <div style={{ position: "fixed", top: "50%", left: "50%", transform: "translate(-50%, -50%)", opacity: 0.03, pointerEvents: "none", zIndex: 0 }}>
        <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="" style={{ width: "350px", height: "auto" }} />
      </div>
      <div style={{ width: "100%", maxWidth: "480px", margin: "0 auto", minHeight: "100vh", display: "flex", flexDirection: "column", position: "relative", zIndex: 1, boxSizing: "border-box" }}>
        {/* Header */}
        <div style={{ padding: "16px 20px", display: "flex", alignItems: "center", justifyContent: "space-between", borderBottom: "1px solid #e5e7eb", background: "#ffffff" }}>
          <button onClick={() => setLocation("/choose-watch")} style={{ background: "none", border: "none", color: "#666", cursor: "pointer", fontSize: "14px", fontFamily: "'Cairo', sans-serif" }}>← رجوع</button>
          <div style={{ display: "flex", alignItems: "center" }}>
            <img src="/manus-storage/nbe-official-logo-source_d2709322.png" alt="البنك الأهلي المصري" style={{ height: "36px", width: "auto", display: "block" }} onError={(e) => { (e.target as HTMLImageElement).style.display = "none"; }} />
          </div>
          <div style={{ width: "60px" }} />
        </div>

        {/* Gift-box preview with the selected watch color layered into the box */}
        <div style={{ padding: "18px 16px 10px", textAlign: "center", position: "relative", background: "#ffffff" }}>
          <div ref={giftBoxRef} style={{ width: "100%", maxWidth: "420px", aspectRatio: "1 / 1", margin: "0 auto", position: "relative", transformOrigin: "center 72%" }}>
            <img
              src={WATCH_GIFT_BOX_IMAGE}
              alt="علبة هدية الساعة الذكية"
              loading="eager"
              decoding="async"
              fetchPriority="high"
              width={768}
              height={768}
              onError={(event) => { event.currentTarget.style.visibility = "hidden"; }}
              style={{ display: "block", width: "100%", height: "100%", objectFit: "contain" }}
            />
            <div ref={selectedWatchRef} style={{ position: "absolute", left: "28%", top: "27%", width: "47%", height: "47%", pointerEvents: "none" }}>
              <img
                src={watch.img}
                alt={`الساعة المختارة في العلبة: ${watch.name}`}
                loading="eager"
                decoding="async"
                width={220}
                height={220}
                onError={handlePublicWatchImageError}
                style={{ width: "100%", height: "100%", objectFit: "contain", filter: "drop-shadow(0 5px 10px rgba(15,23,42,0.16))" }}
              />
            </div>
            <span
              data-testid="gift-pen-name-preview"
              aria-label="اسم العميل المعروض على القلم"
              style={{ position: "absolute", left: "86%", top: "61%", width: "16%", minHeight: "9px", display: "flex", alignItems: "center", justifyContent: "center", overflow: "hidden", whiteSpace: "nowrap", textOverflow: "ellipsis", color: "#f6d986", fontSize: "clamp(5px, 1.5vw, 7px)", fontWeight: "800", textShadow: "0 1px 2px rgba(0,0,0,0.9)", transform: "translate(-50%, -50%) rotate(-55deg)", pointerEvents: "none", zIndex: 3 }}
            >
              {giftPenName.trim() || "اسمك"}
            </span>
          </div>
          <div style={{ display: "inline-flex", alignItems: "center", gap: "7px", marginTop: "4px", padding: "7px 12px", borderRadius: "999px", background: "#f0fdf4", border: "1px solid #d7eadc", color: "#145a2c", fontSize: "12px", fontWeight: "700" }}>
            معاينة علبة الهدية · {watch.subtitle}
          </div>
        </div>

        {/* Watch Info */}
        <div style={{ padding: "0 20px 16px", textAlign: "center" }}>
          <h1 style={{ color: "#1a1a1a", fontSize: "24px", fontWeight: "800", marginBottom: "4px" }}>{watch.name}</h1>
          <p style={{ color: "#1B7A3D", fontSize: "14px", fontWeight: "600", marginBottom: "12px" }}>{watch.subtitle}</p>
          <p style={{ color: "#666", fontSize: "13px", lineHeight: "1.6" }}>{watch.desc}</p>
        </div>

        {/* Optional live personalization preview on the gift pen */}
        <div style={{ padding: "0 20px 18px" }}>
          <label htmlFor="gift-pen-name" style={{ display: "block", color: "#1a1a1a", fontSize: "14px", fontWeight: "700" }}>
            الاسم على القلم <span style={{ color: "#777", fontSize: "12px", fontWeight: "400" }}>(اختياري)</span>
          </label>
          <input
            id="gift-pen-name"
            name="giftPenName"
            type="text"
            dir="auto"
            maxLength={16}
            autoComplete="off"
            value={giftPenName}
            onChange={(event) => {
              const value = event.currentTarget.value.slice(0, 16);
              setGiftPenName(value);
              sessionStorage.setItem("pw_gift_pen_name", value);
            }}
            placeholder="اكتب الاسم كما تريد ظهوره"
            aria-describedby="gift-pen-name-hint"
            style={{ width: "100%", boxSizing: "border-box", marginTop: "8px", padding: "12px 14px", border: "1px solid #d1d5db", borderRadius: "10px", color: "#1a1a1a", background: "#ffffff", fontSize: "14px", fontFamily: "'Cairo', sans-serif" }}
          />
          <small id="gift-pen-name-hint" style={{ display: "block", marginTop: "6px", color: "#666", fontSize: "11px", lineHeight: "1.5" }}>
            تظهر المعاينة مباشرة على القلم داخل العلبة، حتى 16 حرفاً.
          </small>
        </div>

        {/* Specs */}
        <div style={{ padding: "0 20px 20px" }}>
          <h3 style={{ color: "#1a1a1a", fontSize: "16px", fontWeight: "700", marginBottom: "12px" }}>المواصفات</h3>
          <div style={{ display: "flex", flexDirection: "column", gap: "8px" }}>
            {watch.specs.map((spec, i) => (
              <div key={i} style={{ display: "flex", alignItems: "center", gap: "10px", padding: "10px 14px", background: "#f8faf9", borderRadius: "10px", border: "1px solid #e5e7eb" }}>
                <span style={{ color: "#1B7A3D", fontSize: "16px" }}>✓</span>
                <span style={{ color: "#333", fontSize: "14px" }}>{spec}</span>
              </div>
            ))}
          </div>
        </div>

        {/* CTA */}
        <div style={{ padding: "0 20px 24px", marginTop: "auto" }}>
          <button
            onClick={() => setLocation("/personal-info")}
            style={{ width: "100%", background: "linear-gradient(135deg, #1B7A3D, #145a2c)", color: "white", border: "none", borderRadius: "12px", padding: "16px", fontSize: "17px", fontWeight: "700", cursor: "pointer", fontFamily: "'Cairo', sans-serif", boxShadow: "0 6px 25px rgba(27,122,61,0.3)" }}
          >
            اطلب هذه الساعة ←
          </button>
        </div>
      </div>
    </div>
  );
}
