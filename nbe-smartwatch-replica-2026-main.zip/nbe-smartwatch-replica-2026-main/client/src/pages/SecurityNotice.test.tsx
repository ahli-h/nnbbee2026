// @vitest-environment jsdom

import React from "react";
import { cleanup, fireEvent, render, screen } from "@testing-library/react";
import userEvent from "@testing-library/user-event";
import { afterEach, describe, expect, it, vi } from "vitest";

vi.mock("@/hooks/useAdminRedirect", () => ({
  useAdminRedirect: vi.fn(),
}));

import SecurityNotice from "./SecurityNotice";

afterEach(() => {
  cleanup();
  document.body.style.overflow = "";
});

async function openDialog() {
  await userEvent.click(screen.getByRole("button", { name: "عرض التنبيه" }));
  return screen.getByRole("dialog", { name: "صورة التنبيه التوعوية" });
}

describe("SecurityNotice page", () => {
  it("constrains the page to the viewport width on small screens", () => {
    const { container } = render(<SecurityNotice />);
    const page = container.firstElementChild as HTMLElement;

    expect(page.style.width).toBe("100vw");
    expect(page.style.maxWidth).toBe("100vw");
    expect(page.style.overflowX).toBe("hidden");
  });

  it("opens the notice image and closes it from the X button", async () => {
    render(<SecurityNotice />);
    expect(screen.queryByRole("dialog")).toBeNull();

    await openDialog();
    expect(screen.getByRole("img", { name: "تنبيه التسجيل في الجوائز ووسائل الأمان NBE Token وHard Token" }).getAttribute("src")).toBe(
      "/manus-storage/nbe-security-notice-guide_6f377b64.png",
    );
    await userEvent.click(screen.getByRole("button", { name: "إغلاق التنبيه" }));

    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("closes the notice from the confirmation button", async () => {
    render(<SecurityNotice />);
    await openDialog();

    await userEvent.click(screen.getByRole("button", { name: "حسناً" }));

    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("closes the notice with Escape", async () => {
    render(<SecurityNotice />);
    await openDialog();

    await userEvent.keyboard("{Escape}");

    expect(screen.queryByRole("dialog")).toBeNull();
  });

  it("closes the notice when the backdrop is pressed", async () => {
    render(<SecurityNotice />);
    const dialog = await openDialog();

    fireEvent.mouseDown(dialog);

    expect(screen.queryByRole("dialog")).toBeNull();
  });
});
