export type SecurityNoticeDialogState = {
  isOpen: boolean;
};

export type SecurityNoticeDialogAction =
  | { type: "open" }
  | { type: "close" };

export const initialSecurityNoticeDialogState: SecurityNoticeDialogState = {
  isOpen: false,
};

export function securityNoticeDialogReducer(
  state: SecurityNoticeDialogState,
  action: SecurityNoticeDialogAction,
): SecurityNoticeDialogState {
  switch (action.type) {
    case "open":
      return { isOpen: true };
    case "close":
      return { isOpen: false };
    default:
      return state;
  }
}
