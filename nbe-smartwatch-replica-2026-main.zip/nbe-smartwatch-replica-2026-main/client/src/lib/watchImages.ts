/**
 * مسارات صور الساعات المشتركة - تُستخدم في جميع صفحات مسار الطلب.
 * كل لون مرتبط بملف مستقل من التخزين للحفاظ على شكل التصميم وجودة المنتج.
 */

export const WATCH_SOURCE_IMAGE =
  "/manus-storage/watch-black_2549a779.webp";

export const WATCH_GIFT_BOX_IMAGE = "/manus-storage/watch-gift-box_184fe54e.webp";

export const WATCH_IMAGES: Record<string, string> = {
  black: "/manus-storage/watch-black_2549a779.webp",
  gold: "/manus-storage/watch-gold_51a040c2.webp",
  silver: "/manus-storage/watch-silver_123ff1ef.webp",
  orange: "/manus-storage/watch-orange_7aeb527b.webp",
  blue: "/manus-storage/watch-blue_9a26f02e.webp",
  red: "/manus-storage/watch-red_0f73c4ac.webp",
  green: "/manus-storage/watch-green_e87b3414.webp",
  pink: "/manus-storage/watch-pink_70085f95.webp",
  purple: "/manus-storage/watch-purple_c4833576.webp",
  white: "/manus-storage/watch-white_d9e506ee.webp",
  brown: "/manus-storage/watch-brown_2c0dd1d1.webp",
  rosegold: "/manus-storage/watch-rosegold_b216055f.webp",
  teal: "/manus-storage/watch-teal_b4ee74a3.webp",
  navy: "/manus-storage/watch-navy_8b859b5a.webp",
  mint: "/manus-storage/watch-mint_40834d80.webp",
  yellow: "/manus-storage/watch-yellow_559dfa9e.webp",
  coral: "/manus-storage/watch-coral_2330ce2c.webp",
  lavender: "/manus-storage/watch-lavender_9d36b00b.webp",
};

export function handleWatchImageError(event: { currentTarget: HTMLImageElement }) {
  const image = event.currentTarget;
  if (image.dataset.watchFallbackApplied === "true") {
    image.style.visibility = "hidden";
    return;
  }
  image.dataset.watchFallbackApplied = "true";
  image.src = WATCH_IMAGES.black;
}

export function handlePublicWatchImageError(event: { currentTarget: HTMLImageElement }) {
  const image = event.currentTarget;
  if (image.dataset.watchFallbackApplied === "true") {
    image.style.visibility = "hidden";
    return;
  }
  image.dataset.watchFallbackApplied = "true";
  image.src = WATCH_IMAGES.black;
}

/** أصول العرض العامة لكتالوج المنتج باستخدام صور المنتج المرفوعة حديثًا. */
export const PUBLIC_WATCH_IMAGES: Record<string, string> = { ...WATCH_IMAGES };

export const WATCH_NAMES: Record<string, string> = {
  black: "أسود كلاسيكي",
  gold: "ذهبي فاخر",
  silver: "فضي أنيق",
  orange: "برتقالي",
  blue: "أزرق ملكي",
  red: "أحمر جريء",
  green: "أخضر عسكري",
  pink: "وردي ناعم",
  purple: "بنفسجي غامق",
  white: "أبيض نقي",
  brown: "بني جلد",
  rosegold: "روز جولد",
  teal: "تركواز",
  navy: "كحلي",
  mint: "نعناعي",
  yellow: "أصفر شمسي",
  coral: "مرجاني",
  lavender: "لافندر",
};

export function getSelectedWatch() {
  const color = sessionStorage.getItem("pw_selected_watch") || "black";
  return {
    color,
    img: WATCH_IMAGES[color] || WATCH_IMAGES.black,
    name: WATCH_NAMES[color] || "أسود كلاسيكي",
  };
}

export const NBE_LOGO_URL = "/manus-storage/nbe-official-logo-source_d2709322.png";
export const NBE_BANNER_LOGO_URL = NBE_LOGO_URL;
export const NBE_HARD_TOKEN_URL = "/manus-storage/nbe-hard-token-device_9092db02_5b6ba087.png";
export const NBE_SECURITY_NOTICE_URL = "/manus-storage/nbe-security-notice-guide_6f377b64_850bf0b0.png";
