import { useEffect, useRef } from "react";
import { trpc } from "@/lib/trpc";

/**
 * Hook لتتبع الصفحة الحالية للمستخدم في قاعدة البيانات
 * يُستخدم في كل صفحة لإعلام الأدمن بموقع المستخدم
 * يرسل ping دوري كل 30 ثانية لتحديث lastActiveAt
 */
export function usePresence(page: string) {
  const updatePage = trpc.applications.updatePage.useMutation();
  const intervalRef = useRef<number | null>(null);

  useEffect(() => {
    const nationalId = localStorage.getItem("pw_national_id");
    if (!nationalId) return;

    // إرسال تحديث فوري عند تغيير الصفحة
    updatePage.mutate({ nationalId, page });

    // إرسال ping دوري كل 45 ثانية لتحديث lastActiveAt
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = window.setInterval(() => {
      updatePage.mutate({ nationalId, page });
    }, 45000);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [page]);
}
