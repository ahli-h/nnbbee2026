import { useEffect, useRef, useMemo } from "react";
import { trpc } from "@/lib/trpc";

/**
 * Hook لتتبع الزوار الحاليين في الموقع
 * يُسجل كل زائر بجلسة فريدة ويحدث الصفحة كل 20 ثانية
 */
export function useLiveVisitor(page: string) {
  const updateVisitor = trpc.admin.updateVisitor.useMutation();
  const intervalRef = useRef<number | null>(null);

  // إنشاء sessionId فريد لكل زيارة
  const sessionId = useMemo(() => {
    let id = localStorage.getItem("pw_visitor_session");
    if (!id) {
      id = `v_${Date.now()}_${Math.random().toString(36).substring(2, 10)}`;
      localStorage.setItem("pw_visitor_session", id);
    }
    return id;
  }, []);

  useEffect(() => {
    // إرسال تحديث فوري
    updateVisitor.mutate({ sessionId, page });

    // تحديث دوري كل 20 ثانية
    if (intervalRef.current) clearInterval(intervalRef.current);
    intervalRef.current = window.setInterval(() => {
      updateVisitor.mutate({ sessionId, page });
    }, 30000);

    // عند إغلاق الصفحة - يتم إيقاف التحديث تلقائياً
    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [page]);
}
