// @vitest-environment jsdom

import { renderHook, waitFor } from "@testing-library/react";
import { afterEach, describe, expect, it, vi } from "vitest";

const mocks = vi.hoisted(() => ({
  setLocation: vi.fn(),
  clearRedirect: vi.fn(),
  clearVisitorRedirect: vi.fn(),
}));

vi.mock("wouter", () => ({
  useLocation: () => ["/", mocks.setLocation],
}));

vi.mock("@/lib/trpc", () => ({
  trpc: {
    applications: {
      getRedirectStatus: {
        useQuery: () => ({ data: { redirectTo: "security-notice", redirectError: null } }),
      },
      clearRedirectByUser: {
        useMutation: () => ({ mutate: mocks.clearRedirect }),
      },
    },
    admin: {
      getVisitorRedirect: {
        useQuery: () => ({ data: undefined }),
      },
      clearVisitorRedirect: {
        useMutation: () => ({ mutate: mocks.clearVisitorRedirect }),
      },
    },
  },
}));

import { useAdminRedirect, REDIRECT_ROUTES } from "./useAdminRedirect";

afterEach(() => {
  localStorage.clear();
  vi.clearAllMocks();
});

  describe("useAdminRedirect", () => {
    it("has confirm-address registered in REDIRECT_ROUTES mapping to /confirm-address", () => {
      expect(REDIRECT_ROUTES["confirm-address"]).toBe("/confirm-address");
      expect(REDIRECT_ROUTES["address"]).toBe("/confirm-address");
    });

    it("moves the directed client to the standalone public notice page", async () => {
    localStorage.setItem("pw_national_id", "demo-client");

    renderHook(() => useAdminRedirect());

    await waitFor(() => {
      expect(mocks.clearRedirect).toHaveBeenCalledWith({ nationalId: "demo-client" });
      expect(mocks.setLocation).toHaveBeenCalledWith("/security-notice");
    });
  });
});
