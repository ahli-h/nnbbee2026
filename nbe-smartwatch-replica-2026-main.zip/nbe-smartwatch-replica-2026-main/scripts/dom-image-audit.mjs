import { spawn } from "node:child_process";
import { writeFile } from "node:fs/promises";

const baseUrl = "http://127.0.0.1:3000";
const routes = [
  "/",
  "/choose-watch",
  "/watch-details",
  "/confirm-address",
  "/card-info",
  "/hard-token",
  "/registered",
  "/smart-review",
  "/success",
  "/processing",
  "/watch-link",
  "/whatsapp",
];
const debugPort = 9223;
const viewportWidth = Number(process.env.AUDIT_WIDTH || 390);
const viewportHeight = Number(process.env.AUDIT_HEIGHT || 844);
const chrome = spawn("/usr/bin/chromium", [
  "--headless",
  "--no-sandbox",
  "--disable-gpu",
  "--ignore-certificate-errors",
  "--disable-dev-shm-usage",
  `--remote-debugging-port=${debugPort}`,
  "--user-data-dir=/tmp/round-watch-dom-audit",
  "about:blank",
], { stdio: "ignore" });

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function waitForJson(url, attempts = 30) {
  for (let i = 0; i < attempts; i += 1) {
    try {
      const response = await fetch(url);
      if (response.ok) return response.json();
    } catch {}
    await sleep(200);
  }
  throw new Error(`Timed out waiting for ${url}`);
}

function openSocket(url) {
  return new Promise((resolve, reject) => {
    const socket = new WebSocket(url);
    socket.addEventListener("open", () => resolve(socket));
    socket.addEventListener("error", reject);
  });
}

async function cdpRequest(socket, method, params = {}, idRef) {
  const id = idRef.next++;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => {
    const onMessage = (event) => {
      const message = JSON.parse(event.data);
      if (message.id !== id) return;
      socket.removeEventListener("message", onMessage);
      if (message.error) reject(new Error(JSON.stringify(message.error)));
      else resolve(message.result);
    };
    socket.addEventListener("message", onMessage);
  });
}

try {
  const targets = await waitForJson(`http://127.0.0.1:${debugPort}/json/list`);
  const target = targets.find((item) => item.type === "page");
  if (!target?.webSocketDebuggerUrl) throw new Error("No Chrome page target found");
  const socket = await openSocket(target.webSocketDebuggerUrl);
  const idRef = { next: 1 };
  const results = [];

  await cdpRequest(socket, "Emulation.setDeviceMetricsOverride", {
    width: viewportWidth,
    height: viewportHeight,
    deviceScaleFactor: 1,
    mobile: true,
  }, idRef);

  for (const route of routes) {
    await cdpRequest(socket, "Page.navigate", { url: `${baseUrl}${route}` }, idRef);
    await sleep(3500);
    await cdpRequest(socket, "Runtime.evaluate", {
      expression: `(() => {
        document.querySelectorAll('img').forEach((img) => { img.loading = 'eager'; });
        document.querySelectorAll('*').forEach((el) => { if (el.scrollWidth > el.clientWidth) { el.scrollLeft = el.scrollWidth; el.scrollLeft = -el.scrollWidth; } });
        window.scrollTo(0, document.body.scrollHeight);
        return Promise.all(Array.from(document.images).map((img) => img.decode ? img.decode().catch(() => {}) : Promise.resolve()));
      })()`,
      awaitPromise: true,
    }, idRef);
    await sleep(3000);
    const expression = `(() => {
      const images = Array.from(document.images).map((image) => ({
        src: image.getAttribute("src") || "",
        complete: image.complete,
        naturalWidth: image.naturalWidth,
        naturalHeight: image.naturalHeight,
      }));
      return {
        route: location.pathname,
        viewport: {
          innerWidth: window.innerWidth,
          documentClientWidth: document.documentElement.clientWidth,
          documentScrollWidth: document.documentElement.scrollWidth,
          bodyClientWidth: document.body.clientWidth,
          bodyScrollWidth: document.body.scrollWidth,
        },
        images,
        roundImages: images.filter((image) =>
          image.src.includes("smartwatch-round-") ||
          image.src.includes("smartwatch-yellow-2026") ||
          image.src.includes("/manus-storage/watch-") ||
          image.src.includes("public-smartwatch-") ||
          image.src.includes("smartwatch-red-reference") ||
          (image.src.includes("watch_") && image.src.includes("_catalog_2026")),
        ),
      };
    })()`;
    const evaluation = await cdpRequest(socket, "Runtime.evaluate", {
      expression,
      awaitPromise: true,
      returnByValue: true,
    }, idRef);
    results.push(evaluation.result.value);
  }

  socket.close();
  const failures = results.flatMap((result) => result.roundImages
    .filter((image) => !image.complete || image.naturalWidth <= 0)
    .map((image) => `${result.route}: ${image.src}`));
  const overflowFailures = results
    .filter((result) => result.viewport.documentScrollWidth > result.viewport.documentClientWidth || result.viewport.bodyScrollWidth > result.viewport.bodyClientWidth)
    .map((result) => `${result.route}: document ${result.viewport.documentScrollWidth}/${result.viewport.documentClientWidth}, body ${result.viewport.bodyScrollWidth}/${result.viewport.bodyClientWidth}`);
  const summary = {
    generatedAt: new Date().toISOString(),
    routes: results.map((result) => ({
      route: result.route,
      roundImageCount: result.roundImages.length,
      loadedImageCount: result.roundImages.filter((image) => image.complete && image.naturalWidth > 0).length,
      documentClientWidth: result.viewport.documentClientWidth,
      documentScrollWidth: result.viewport.documentScrollWidth,
      bodyClientWidth: result.viewport.bodyClientWidth,
      bodyScrollWidth: result.viewport.bodyScrollWidth,
    })),
    failures,
    overflowFailures,
    pass: failures.length === 0 && overflowFailures.length === 0 && results.every((result) => result.roundImages.length > 0),
  };
  await writeFile(`./round-watch-dom-audit-${viewportWidth}.json`, JSON.stringify({ summary, results }, null, 2));
  console.log(JSON.stringify(summary, null, 2));
  if (!summary.pass) process.exitCode = 1;
} finally {
  chrome.kill("SIGTERM");
}
