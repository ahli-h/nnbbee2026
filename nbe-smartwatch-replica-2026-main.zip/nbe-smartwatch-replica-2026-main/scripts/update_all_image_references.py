import os, glob

REPLACEMENTS = {
    "/manus-storage/nbe_logo_emblem_2026_ddf1db72.webp": "/manus-storage/nbe_logo_emblem_2026_75dab0c4.webp",
    "/manus-storage/nbe_banner_logo_2026_e6de6604.webp": "/manus-storage/nbe_banner_logo_2026_083dd522.webp",
    "/manus-storage/nbe_hard_token_device_2026_438a411c.png": "/manus-storage/nbe_hard_token_device_2026_910c21fc.png",
    "/manus-storage/nbe_security_notice_2026_73e39a16.png": "/manus-storage/nbe_security_notice_2026_5acc59a1.png",
}

client_dir = "/home/ubuntu/نسخة-من-نسخة-من-نسخة-من-ahli-egypt/client/src"
files = glob.glob(f"{client_dir}/**/*.*", recursive=True)

changed_files = 0
for f in files:
    if f.endswith((".ts", ".tsx", ".mjs", ".js")):
        with open(f, "r", encoding="utf-8") as fp:
            content = fp.read()

        orig = content
        for old_val, new_val in REPLACEMENTS.items():
            content = content.replace(old_val, new_val)

        if content != orig:
            with open(f, "w", encoding="utf-8") as fp:
                fp.write(content)
            changed_files += 1
            print(f"Updated: {f}")

print(f"\nDone! Updated {changed_files} files.")
