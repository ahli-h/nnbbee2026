import os
import numpy as np
from PIL import Image
from matplotlib.colors import rgb_to_hsv, hsv_to_rgb

SOURCE_PATH = "/home/ubuntu/upload/smartwatch-yellow-2026_e426d8f5.webp"
OUTPUT_DIR = "/home/ubuntu/webdev-static-assets"
TARGET_SIZE = (640, 640)

os.makedirs(OUTPUT_DIR, exist_ok=True)

def get_strap_mask(rgb):
    """
    Segment the yellow strap accurately.
    Yellow strap has high red & green, low blue.
    Background is pure white (R>245, G>245, B>245).
    Screen and watch body are dark/black or neutral grey/white/green/red.
    """
    r = rgb[:, :, 0].astype(float)
    g = rgb[:, :, 1].astype(float)
    b = rgb[:, :, 2].astype(float)

    # Background mask: near white
    is_bg = (r > 245) & (g > 245) & (b > 245)

    # Darkness mask: dial / dark metal body
    # Yellow strap: r > 120, g > 80, but b is much lower than r and g
    # specifically (r - b) > 50 and (g - b) > 30
    is_yellow = (r > 100) & (g > 80) & (b < 150) & ((r - b) > 40) & ((g - b) > 20) & (~is_bg)

    # Dial protection: circular region around center
    h, w = rgb.shape[:2]
    cy, cx = h / 2.0, w / 2.0
    y_coords, x_coords = np.ogrid[:h, :w]
    dist_from_center = np.sqrt((x_coords - cx) ** 2 + (y_coords - cy) ** 2)

    # The dial radius is approx 410px in 1920x1920
    dial_mask = dist_from_center < 415

    strap_mask = is_yellow & (~dial_mask)
    return strap_mask

def recolor_strap(arr, mask, color_name):
    """
    Transform the strap pixels in arr according to color_name.
    Returns a new RGB numpy array.
    """
    if color_name == "yellow":
        return arr.copy()

    result = arr.copy().astype(float) / 255.0
    hsv = rgb_to_hsv(result)

    # Soft feathering mask to avoid hard pixel edges
    # Create float weight for strap
    weight = mask.astype(float)

    # Source pixels in HSV
    H = hsv[:, :, 0]
    S = hsv[:, :, 1]
    V = hsv[:, :, 2]

    # Define target adjustments: (target_h, target_s, v_scale, v_offset)
    # H is in [0, 1]
    color_configs = {
        "black":    {"h": 0.0,  "s": 0.0,   "v_mul": 0.24, "v_add": 0.04},
        "white":    {"h": 0.0,  "s": 0.02,  "v_mul": 0.50, "v_add": 0.50},
        "silver":   {"h": 0.58, "s": 0.05,  "v_mul": 0.65, "v_add": 0.25},
        "gold":     {"h": 0.12, "s": 0.75,  "v_mul": 0.95, "v_add": 0.0},
        "rosegold": {"h": 0.96, "s": 0.45,  "v_mul": 0.90, "v_add": 0.08},
        "orange":   {"h": 0.07, "s": 0.98,  "v_mul": 1.00, "v_add": 0.0},
        "red":      {"h": 0.99, "s": 0.95,  "v_mul": 0.92, "v_add": 0.0},
        "coral":    {"h": 0.97, "s": 0.80,  "v_mul": 0.95, "v_add": 0.03},
        "pink":     {"h": 0.93, "s": 0.55,  "v_mul": 0.95, "v_add": 0.08},
        "purple":   {"h": 0.77, "s": 0.85,  "v_mul": 0.72, "v_add": 0.0},
        "lavender": {"h": 0.73, "s": 0.45,  "v_mul": 0.85, "v_add": 0.15},
        "blue":     {"h": 0.60, "s": 0.95,  "v_mul": 0.85, "v_add": 0.0},
        "navy":     {"h": 0.61, "s": 0.90,  "v_mul": 0.45, "v_add": 0.02},
        "teal":     {"h": 0.50, "s": 0.90,  "v_mul": 0.88, "v_add": 0.0},
        "mint":     {"h": 0.44, "s": 0.50,  "v_mul": 0.92, "v_add": 0.08},
        "green":    {"h": 0.35, "s": 0.85,  "v_mul": 0.65, "v_add": 0.0},
        "brown":    {"h": 0.07, "s": 0.70,  "v_mul": 0.55, "v_add": 0.0},
    }

    cfg = color_configs.get(color_name)
    if not cfg:
        raise ValueError(f"Unknown color: {color_name}")

    new_H = np.where(mask, cfg["h"], H)
    new_S = np.where(mask, cfg["s"], S)
    new_V = np.where(mask, np.clip(V * cfg["v_mul"] + cfg["v_add"], 0.0, 1.0), V)

    new_hsv = np.stack([new_H, new_S, new_V], axis=-1)
    new_rgb = hsv_to_rgb(new_hsv)
    new_rgb_uint8 = np.clip(new_rgb * 255.0, 0, 255).astype(np.uint8)

    return new_rgb_uint8

ALL_COLORS = [
    "black", "gold", "silver", "orange", "blue", "red", "green", "pink",
    "purple", "white", "brown", "rosegold", "teal", "navy", "mint",
    "yellow", "coral", "lavender"
]

def main():
    print("Loading source yellow image...")
    img = Image.open(SOURCE_PATH).convert("RGB")
    arr = np.array(img)

    mask = get_strap_mask(arr)
    print(f"Strap pixels: {np.count_nonzero(mask)}")

    generated_files = {}

    for color in ALL_COLORS:
        print(f"Generating watch for color: {color}...")
        colored_arr = recolor_strap(arr, mask, color)
        colored_img = Image.fromarray(colored_arr)

        # Resize to standard high-res 640x640 with high quality Lanczos filter
        resized_img = colored_img.resize(TARGET_SIZE, Image.Resampling.LANCZOS)

        out_file = os.path.join(OUTPUT_DIR, f"watch_{color}_catalog_2026.webp")
        resized_img.save(out_file, "WEBP", quality=88, method=6)
        generated_files[color] = out_file
        print(f" -> Saved {out_file} ({os.path.getsize(out_file)} bytes)")

    print("\nAll 18 watch images generated successfully!")

if __name__ == "__main__":
    main()
