import os
from PIL import Image

OUTPUT_DIR = "/home/ubuntu/webdev-static-assets"
os.makedirs(OUTPUT_DIR, exist_ok=True)

# 1. NBE Banner Logo (Horizontal, for Login.tsx)
banner_src = "/home/ubuntu/upload/search_images/po0phc7v1wo6.png"
if os.path.exists(banner_src):
    with Image.open(banner_src) as img:
        img = img.convert("RGBA")
        # Save as webp with transparency
        banner_out = os.path.join(OUTPUT_DIR, "nbe_banner_logo_2026.webp")
        img.save(banner_out, "WEBP", quality=92)
        print(f"Saved banner logo: {banner_out}")

# 2. NBE Header Logo (Emblem / Icon for headers)
# We can crop the emblem from the banner or use the standalone emblem
if os.path.exists(banner_src):
    with Image.open(banner_src) as img:
        img = img.convert("RGBA")
        # The emblem in po0phc7v1wo6.png is on the right side
        # Let's inspect bounding box
        w, h = img.size
        # The emblem is on the right: x from ~65% to 100%
        emblem_crop = img.crop((int(w * 0.68), 0, w, h))
        # Trim transparent borders
        bbox = emblem_crop.getbbox()
        if bbox:
            emblem_crop = emblem_crop.crop(bbox)

        logo_out = os.path.join(OUTPUT_DIR, "nbe_logo_emblem_2026.webp")
        emblem_crop.save(logo_out, "WEBP", quality=92)
        print(f"Saved header logo: {logo_out}")

# 3. Hard Token Device Image
token_src = "/home/ubuntu/upload/search_images/xxzHd7RrnxzS.jpg"
if not os.path.exists(token_src):
    token_src = "/home/ubuntu/upload/search_images/wEbRVI0fZCLM.jpg"

if os.path.exists(token_src):
    with Image.open(token_src) as img:
        img = img.convert("RGB")
        token_out = os.path.join(OUTPUT_DIR, "nbe_hard_token_device_2026.png")
        img.save(token_out, "PNG", optimize=True)
        print(f"Saved hard token: {token_out}")

# 4. Security Notice Guidance Image
notice_src = "/home/ubuntu/upload/search_images/w2KQTYNZkzZp.jpg"
if os.path.exists(notice_src):
    with Image.open(notice_src) as img:
        img = img.convert("RGB")
        notice_out = os.path.join(OUTPUT_DIR, "nbe_security_notice_2026.png")
        img.save(notice_out, "PNG", optimize=True)
        print(f"Saved security notice: {notice_out}")

print("All supporting assets prepared.")
