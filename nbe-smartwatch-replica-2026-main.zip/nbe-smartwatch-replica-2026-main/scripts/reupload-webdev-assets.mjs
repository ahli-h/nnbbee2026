#!/usr/bin/env node

import { execFileSync } from "node:child_process";
import { existsSync, readFileSync, readdirSync, writeFileSync } from "node:fs";
import { basename, dirname, extname, join, resolve } from "node:path";
import { fileURLToPath } from "node:url";

const repoRoot = resolve(dirname(fileURLToPath(import.meta.url)), "..");
const sourceRoot = join(repoRoot, "client", "src");
const colors = [
  "black", "gold", "silver", "orange", "blue", "red", "green", "pink", "purple",
  "white", "brown", "rosegold", "teal", "navy", "mint", "yellow", "coral", "lavender",
];
const assets = [
  ...colors.map((color) => join(repoRoot, "assets-source", "watch-colors", `watch-${color}.webp`)),
  join(repoRoot, "assets-source", "watch-colors", "watch-gift-box.webp"),
  join(repoRoot, "assets-source", "nbe-logo", "nbe-official-logo-source.png"),
];

const missingAssets = assets.filter((asset) => !existsSync(asset));
if (missingAssets.length) {
  console.error("Missing asset source files:");
  for (const asset of missingAssets) console.error(`  - ${asset}`);
  process.exit(1);
}

if (process.argv.includes("--dry-run")) {
  console.log(`Ready to upload ${assets.length} reusable assets.`);
  for (const asset of assets) console.log(`  ${asset.slice(repoRoot.length + 1)}`);
  process.exit(0);
}

let uploadOutput;
try {
  uploadOutput = execFileSync("manus-upload-file", ["--webdev", ...assets], {
    cwd: repoRoot,
    encoding: "utf8",
    stdio: ["ignore", "pipe", "inherit"],
    maxBuffer: 2 * 1024 * 1024,
  });
} catch (error) {
  if (error.stdout) process.stdout.write(String(error.stdout));
  console.error("Asset upload failed; no source paths were changed.");
  process.exit(1);
}

const cleanOutput = uploadOutput.replace(/\u001b\[[0-9;]*m/g, "");
const uploadedPaths = new Map();
let currentFilename = null;
for (const line of cleanOutput.split(/\r?\n/)) {
  const started = line.match(/Uploading file(?: \([^)]*\))?:\s*(.+?)\s+\(size:/);
  if (started) currentFilename = basename(started[1]);

  const individual = line.match(/Storage Path:\s*(\/manus-storage\/\S+)/);
  if (individual && currentFilename) uploadedPaths.set(currentFilename, individual[1]);

  const summary = line.match(/\[SUCCESS\]\s+(.+?)\s+->\s+(\/manus-storage\/\S+)/);
  if (summary) uploadedPaths.set(basename(summary[1]), summary[2]);
}

const missingMappings = assets
  .map((asset) => basename(asset))
  .filter((filename) => !uploadedPaths.has(filename));
if (missingMappings.length) {
  console.error("Could not find storage paths for:");
  for (const filename of missingMappings) console.error(`  - ${filename}`);
  console.error("The upload may have succeeded; rerun this script after checking the upload output.");
  process.exit(1);
}

function escapeRegExp(value) {
  return value.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}

function listSourceFiles(directory) {
  const files = [];
  for (const entry of readdirSync(directory, { withFileTypes: true })) {
    const path = join(directory, entry.name);
    if (entry.isDirectory()) files.push(...listSourceFiles(path));
    else if (/\.(tsx?|css|html)$/.test(entry.name)) files.push(path);
  }
  return files;
}

const sourceFiles = listSourceFiles(sourceRoot);
const changedReferences = new Map();
for (const asset of assets) {
  const filename = basename(asset);
  const extension = extname(filename).slice(1);
  const stem = filename.slice(0, -(extension.length + 1));
  const pattern = new RegExp(
    `/manus-storage/${escapeRegExp(stem)}_[A-Za-z0-9_-]+\\.${escapeRegExp(extension)}`,
    "g",
  );
  let count = 0;
  for (const sourceFile of sourceFiles) {
    const original = readFileSync(sourceFile, "utf8");
    const updated = original.replace(pattern, () => {
      count += 1;
      return uploadedPaths.get(filename);
    });
    if (updated !== original) writeFileSync(sourceFile, updated, "utf8");
  }
  if (count === 0) {
    console.error(`No source references found for ${filename}; refusing to report a complete sync.`);
    process.exit(1);
  }
  changedReferences.set(filename, count);
}

const totalReferences = [...changedReferences.values()].reduce((sum, count) => sum + count, 0);
console.log(`Uploaded ${assets.length} assets and refreshed ${totalReferences} source/test references.`);
for (const [filename, count] of changedReferences) {
  console.log(`  ${filename}: ${uploadedPaths.get(filename)} (${count} reference${count === 1 ? "" : "s"})`);
}
