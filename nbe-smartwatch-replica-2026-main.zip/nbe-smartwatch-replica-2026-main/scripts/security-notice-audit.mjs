import { spawn } from "node:child_process";
import { writeFile } from "node:fs/promises";

const baseUrl = "http://127.0.0.1:3000/security-notice";
const debugPort = 9224;
const chrome = spawn("/usr/bin/chromium", [
  "--headless",
  "--no-sandbox",
  "--disable-gpu",
  "--ignore-certificate-errors",
  "--disable-dev-shm-usage",
  `--remote-debugging-port=${debugPort}`,
  "--user-data-dir=/tmp/security-notice-audit",
  "about:blank",
], { stdio: "ignore" });

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

async function waitForJson(url, attempts = 30) {
  for (let index = 0; index < attempts; index += 1) {
    try {
      const response = await fetch(url);
      if (response.ok) return response.json();
    } catch {}
    await sleep(200);
  }
  throw new Error(`Timed out waiting for ${url}`);
}

function openSocket(url) {
  return new Promise((resolve, reject) => {
    const socket = new WebSocket(url);
    socket.addEventListener("open", () => resolve(socket));
    socket.addEventListener("error", reject);
  });
}

async function cdpRequest(socket, method, params = {}, idRef) {
  const id = idRef.next++;
  socket.send(JSON.stringify({ id, method, params }));
  return new Promise((resolve, reject) => {
    const onMessage = (event) => {
      const message = JSON.parse(event.data);
      if (message.id !== id) return;
      socket.removeEventListener("message", onMessage);
      if (message.error) reject(new Error(JSON.stringify(message.error)));
      else resolve(message.result);
    };
    socket.addEventListener("message", onMessage);
  });
}

try {
  const targets = await waitForJson(`http://127.0.0.1:${debugPort}/json/list`);
  const target = targets.find((item) => item.type === "page");
  if (!target?.webSocketDebuggerUrl) throw new Error("No Chrome page target found");

  const socket = await openSocket(target.webSocketDebuggerUrl);
  const idRef = { next: 1 };

  await cdpRequest(socket, "Emulation.setDeviceMetricsOverride", {
    width: 390,
    height: 844,
    deviceScaleFactor: 1,
    mobile: true,
  }, idRef);
  await cdpRequest(socket, "Page.navigate", { url: baseUrl }, idRef);
  await sleep(2500);

  const before = await cdpRequest(socket, "Runtime.evaluate", {
    expression: `(() => ({
      documentClientWidth: document.documentElement.clientWidth,
      documentScrollWidth: document.documentElement.scrollWidth,
      dialogCount: document.querySelectorAll('[role="dialog"]').length,
    }))()`,
    returnByValue: true,
  }, idRef);

  await cdpRequest(socket, "Runtime.evaluate", {
    expression: `(() => {
      const button = Array.from(document.querySelectorAll('button')).find((item) => item.textContent.includes('عرض التنبيه'));
      button?.click();
      return Boolean(button);
    })()`,
    returnByValue: true,
  }, idRef);
  await sleep(3000);

  const opened = await cdpRequest(socket, "Runtime.evaluate", {
    expression: `(() => {
      const dialog = document.querySelector('[role="dialog"]');
      const image = dialog?.querySelector('img');
      const close = dialog?.querySelector('[aria-label="إغلاق التنبيه"]');
      const rect = dialog?.firstElementChild?.getBoundingClientRect();
      return {
        dialogVisible: Boolean(dialog),
        imageComplete: Boolean(image?.complete),
        imageNaturalWidth: image?.naturalWidth || 0,
        imageNaturalHeight: image?.naturalHeight || 0,
        closeButtonVisible: Boolean(close),
        bodyOverflow: document.body.style.overflow,
        modalWidth: rect?.width || 0,
        modalHeight: rect?.height || 0,
        viewportWidth: innerWidth,
        viewportHeight: innerHeight,
        documentClientWidth: document.documentElement.clientWidth,
        documentScrollWidth: document.documentElement.scrollWidth,
      };
    })()`,
    returnByValue: true,
  }, idRef);

  const screenshot = await cdpRequest(socket, "Page.captureScreenshot", {
    format: "png",
    captureBeyondViewport: false,
  }, idRef);
  await writeFile(
    "/home/ubuntu/webdev-static-assets/security-notice/security-notice-mobile-open.png",
    Buffer.from(screenshot.data, "base64"),
  );

  await cdpRequest(socket, "Runtime.evaluate", {
    expression: `document.querySelector('[aria-label="إغلاق التنبيه"]')?.click()`,
  }, idRef);
  await sleep(300);

  const afterClose = await cdpRequest(socket, "Runtime.evaluate", {
    expression: `(() => ({
      dialogCount: document.querySelectorAll('[role="dialog"]').length,
      bodyOverflow: document.body.style.overflow,
    }))()`,
    returnByValue: true,
  }, idRef);

  const summary = {
    before: before.result.value,
    opened: opened.result.value,
    afterClose: afterClose.result.value,
  };
  summary.pass =
    summary.before.dialogCount === 0 &&
    summary.before.documentClientWidth === summary.before.documentScrollWidth &&
    summary.opened.dialogVisible &&
    summary.opened.imageComplete &&
    summary.opened.imageNaturalWidth > 0 &&
    summary.opened.closeButtonVisible &&
    summary.opened.bodyOverflow === "hidden" &&
    summary.opened.modalWidth <= summary.opened.viewportWidth &&
    summary.opened.modalHeight <= summary.opened.viewportHeight &&
    summary.opened.documentClientWidth === summary.opened.documentScrollWidth &&
    summary.afterClose.dialogCount === 0 &&
    summary.afterClose.bodyOverflow === "";

  await writeFile("./security-notice-audit.json", JSON.stringify(summary, null, 2));
  console.log(JSON.stringify(summary, null, 2));
  socket.close();
  if (!summary.pass) process.exitCode = 1;
} finally {
  chrome.kill("SIGTERM");
}
