from pathlib import Path
from PIL import Image


ASSET_DIR = Path("/home/ubuntu/webdev-static-assets")
YELLOW_SOURCE = Path("/home/ubuntu/upload/smartwatch-yellow-2026_e426d8f5.webp")
TARGET_SIZE = (640, 640)
QUALITY = 78

SOURCES = {
    "black": ASSET_DIR / "smartwatch-black-2026-v4.png",
    "gold": ASSET_DIR / "smartwatch-gold-2026-v4.png",
    "silver": ASSET_DIR / "smartwatch-silver-2026-v4.png",
    "orange": ASSET_DIR / "smartwatch-orange-2026-v4.png",
    "blue": ASSET_DIR / "smartwatch-blue-2026-v4.png",
    "red": ASSET_DIR / "smartwatch-red-2026-v4.png",
    "green": ASSET_DIR / "smartwatch-green-2026-v4.png",
    "pink": ASSET_DIR / "smartwatch-pink-2026-v4.png",
    "purple": ASSET_DIR / "smartwatch-purple-2026-v4.png",
    "white": ASSET_DIR / "smartwatch-white-2026-v4.png",
    "brown": ASSET_DIR / "smartwatch-brown-2026-v5.png",
    "rosegold": ASSET_DIR / "smartwatch-rosegold-2026-v4.png",
    "teal": ASSET_DIR / "smartwatch-teal-2026-v4.png",
    "navy": ASSET_DIR / "smartwatch-navy-2026-v4.png",
    "mint": ASSET_DIR / "smartwatch-mint-2026-v4.png",
    "yellow": YELLOW_SOURCE,
    "coral": ASSET_DIR / "smartwatch-coral-2026-v4.png",
    "lavender": ASSET_DIR / "smartwatch-lavender-2026-v4.png",
}


def optimize(color: str, source: Path) -> tuple[int, int, Path]:
    output = ASSET_DIR / f"smartwatch-{color}-catalog-640-2026.webp"
    with Image.open(source) as image:
        rgb_image = image.convert("RGB")
        resized = rgb_image.resize(TARGET_SIZE, Image.Resampling.LANCZOS)
        resized.save(output, "WEBP", quality=QUALITY, method=6, optimize=True)
    return source.stat().st_size, output.stat().st_size, output


def main() -> None:
    original_total = 0
    optimized_total = 0
    print("color,original_bytes,optimized_bytes,reduction_percent,output")
    for color, source in SOURCES.items():
        if not source.exists():
            raise FileNotFoundError(f"Missing source for {color}: {source}")
        original_size, optimized_size, output = optimize(color, source)
        original_total += original_size
        optimized_total += optimized_size
        reduction = (1 - optimized_size / original_size) * 100
        print(f"{color},{original_size},{optimized_size},{reduction:.2f},{output}")

    total_reduction = (1 - optimized_total / original_total) * 100
    print(f"TOTAL,{original_total},{optimized_total},{total_reduction:.2f},")


if __name__ == "__main__":
    main()
